# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

"""Module to handle logging in Blender scripts"""

import os
import traceback
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from pathlib import Path

from .exceptions import LoggerNotFound


class BColors(Enum):
    """Enum that represents the colors for the terminal"""

    HEADER = "\033[95m"
    OKBLUE = "\033[94m"
    OKCYAN = "\033[96m"
    OKGREEN = "\033[92m"
    WARNING = "\033[93m"
    FAIL = "\033[91m"
    ENDC = "\033[0m"
    BOLD = "\033[1m"
    UNDERLINE = "\033[4m"
    BRIGHT = "\033[1m"
    WHITE = "\033[97m"


@dataclass
class LogLevel:
    """Class to represent the log level data

    Attributes:
        name (str): The log level name
        color (str): The color to use for the log level
        right_fill (int): The number of characters to use for the right fill,
            It keeps the log text aligned when using different log types.

    """

    name: str
    color: str
    right_fill: int
    severity: int


DEBUG = LogLevel(
    name="DEBUG", color=BColors.OKBLUE.value, right_fill=1, severity=1
)
INFO = LogLevel(
    name="INFO", color=BColors.OKGREEN.value, right_fill=6, severity=2
)
WARNING = LogLevel(
    name="WARNING", color=BColors.WARNING.value, right_fill=3, severity=3
)
ERROR = LogLevel(
    name="ERROR", color=BColors.FAIL.value, right_fill=5, severity=4
)
CRITICAL = LogLevel(
    name="CRITICAL", color=BColors.FAIL.value, right_fill=1, severity=5
)

EXCEPTION = LogLevel(
    name="EXCEPTION", color=BColors.FAIL.value, right_fill=1, severity=6
)


def is_log_file(file_path: Path) -> bool:
    """Check if a file is a text file"""

    text_file_extensions = [".txt", ".log"]
    return file_path.suffix in text_file_extensions


@dataclass
class LogConfig:
    """Class to represent the log configuration

    Attributes:
        write (Path): The path to write the log file
        console_output (bool): If the log should be output to the console

        header_char (str): The character to use for the header

        auto_indent (bool): If the log should be auto indented by the stack level
        start_indent (int): The start indentation level
        indent_char (str): The character to use for indentation
        indent_char_count (int): The number of characters to use for indentation

        time_info (bool): If the time info should be included in the log
        time_format (str): The time format to use for the log

        module_info (bool): If the module info should be included in the log

        level_info (bool): If the log level info should be included in the log
        use_color (bool): If the log text should use color
        use_type_fill (bool): If the log should use the right fill after the level name.
            It keeps the log text aligned when using different log types.

    """

    write: Path | None = field(default=None)
    console_output: bool = field(default=True)

    header_char: str = field(default="-")

    auto_indent: bool = field(default=False)
    start_indent: int = field(default=0)
    indent_char: str = field(default=" ")
    indent_char_count: int = field(default=4)

    time_info: bool = field(default=False)
    time_format: str = field(default="%Y-%m-%d %H:%M:%S.%f")

    module_info: bool = field(default=False)

    level_info: bool = field(default=False)
    use_color: bool = field(default=True)
    use_type_fill: bool = field(default=True)


class LogLine:
    """Class to represent a log line"""

    logger_name: str
    text: str
    level: LogLevel
    date: datetime
    indent: int
    log_config: LogConfig

    def __init__(
        self,
        log_config: LogConfig,
        logger_name: str,
        text: str,
        level: LogLevel = INFO,
        text_color: BColors | None = None,
        show_info: bool = True,
        indent: int = 0,
    ):

        self.log_config = log_config
        self._logger_name = logger_name
        self.text = text
        self.level = level
        self.indent = indent
        self.text_color = text_color
        self.date = datetime.now()
        self.show_info = show_info

    def _get_indent(self, indent: int) -> str:
        """Get the indentation string"""

        return (
            " " * self.log_config.start_indent
            + (self.log_config.indent_char * self.log_config.indent_char_count)
            * indent
        )

    def _get_log_info_text(self, use_color: bool) -> str:

        info_text = ""

        if self.log_config.time_info:
            info_text += f"[{self.date.strftime(self.log_config.time_format)}]"

        if self.log_config.module_info:

            if use_color and not self.text_color:
                info_text += f"{BColors.OKCYAN.value}"

            info_text += f"[{self._logger_name}]"

            if use_color and not self.text_color:
                info_text += f"{BColors.ENDC.value}"

        if self.log_config.level_info:

            if use_color and not self.text_color:
                info_text += f"{self.level.color}"

            info_text += f"[{self.level.name}]"

            if use_color and not self.text_color:
                info_text += f"{BColors.ENDC.value}"

            if self.log_config.use_type_fill:
                info_text += f"{self.level.right_fill * ' '}"

        return info_text

    def as_str(self, use_color: bool = True) -> str:
        """Get the log line as a string"""

        text = ""
        if self.text_color and use_color:
            text += f"{self.text_color.value}"

        if self.show_info:
            text += f"{self._get_log_info_text(use_color=use_color)}{self._get_indent(self.indent)}"

        text += f"{self.text}"

        if self.text_color and use_color:
            text += f"{BColors.ENDC.value}"

        return text


class WriteManager:
    """Class to manage log files"""

    filepath: Path

    def __init__(self, filepath: Path, logger_name: str):

        self.filepath = filepath
        self._logger_name = logger_name

    def delete_all_logs(self) -> None:
        """Delete all log files in the log directory"""

        # check if is dir
        if not self.filepath.is_dir():
            return

        for file in self.filepath.iterdir():

            if not is_log_file(file):
                continue

            file.unlink()

    def delete_logs_older_than(self, seconds: int):
        """Delete log files older than a certain amount of seconds"""

        # check if is dir
        if not self.filepath.is_dir():
            return

        time_now = datetime.now()

        for file in self.filepath.iterdir():

            if not is_log_file(file):
                continue

            file_log_date = datetime.fromtimestamp(os.path.getctime(file))

            if time_now - timedelta(seconds=seconds) > file_log_date:
                file.unlink()

    def get_log_filepath(self, msg_id: str = "") -> Path:
        """Get the log file path for the logger instance"""

        if is_log_file(self.filepath):
            if msg_id:
                raise ValueError("Log file path is a file, cannot use msg_id")

            return self.filepath
        else:
            if msg_id:
                return self.filepath / f"{msg_id}.log"
            else:
                return self.filepath / f"{self._logger_name}.log"

    def write_to_file(self, line: LogLine, msg_id: str):
        """Write a line to the log file"""

        log_filepath = self.get_log_filepath(msg_id)

        try:
            with open(
                log_filepath,
                "a+" if log_filepath.exists() else "w+",
                encoding="utf-8",
            ) as f:
                f.write(f"{line.as_str(use_color=False)}\n")
        except PermissionError:
            pass


class Logger:
    """Class to handle logging"""

    _config: LogConfig
    _id: str
    _write_manager: WriteManager | None = None
    _logger_name: str
    _level: LogLevel

    def __init__(
        self,
        level: LogLevel = INFO,
        logger_name: str = "",
    ):

        self._id = uuid.uuid4().hex
        self._config = LogConfig()
        self._level = level

        self._logger_name = logger_name
        self.indent_level = 0

    def setLevel(self, level: LogLevel) -> None:
        """Set the logger level"""
        self._level = level

    def setLoggerName(self, logger_name: str) -> None:
        """Set the logger name"""
        self._logger_name = logger_name

    def setConfig(self, config: LogConfig) -> None:
        """Set the logger configuration"""
        self._config = config
        self._apply_config()

    @property
    def logger_name(self):
        """Get the logger name"""
        return self._logger_name

    @property
    def id(self):
        """Get the logger ID"""
        return self._id

    @property
    def config(self):
        """Get the logger configuration"""
        return self._config

    def _apply_config(self):
        """Apply the logger configuration"""

        if self._config.write:
            self._write_manager = WriteManager(
                self._config.write, self._logger_name
            )

    def info(self, message: str, msg_id: str = "", indent: int = 0):
        """Log an info message"""

        line = LogLine(
            self._config,
            self._logger_name,
            message,
            INFO,
            indent=indent,
        )
        self._handle_log(line, msg_id)

    def warning(self, message: str, msg_id: str = "", indent: int = 0):
        """Log a warning message"""

        line = LogLine(
            self._config,
            self._logger_name,
            message,
            WARNING,
            indent=indent,
        )
        self._handle_log(line, msg_id)

    def error(self, message: str, msg_id: str = "", indent: int = 0):
        """Log an error message"""

        line = LogLine(
            self._config,
            self._logger_name,
            message,
            ERROR,
            indent=indent,
        )
        self._handle_log(line, msg_id)

    def critical(self, message: str, msg_id: str = "", indent: int = 0):
        """Log a critical message"""

        line = LogLine(
            self._config,
            self._logger_name,
            message,
            CRITICAL,
            text_color=BColors.FAIL,
            indent=indent,
        )
        self._handle_log(line, msg_id)

    def exception(self, message: str, msg_id: str = "", indent: int = 0):
        """Log an exception message"""

        line = LogLine(
            self._config,
            self._logger_name,
            message,
            EXCEPTION,
            text_color=BColors.FAIL,
            indent=indent,
        )
        self._handle_log(line, msg_id)

    def debug(self, message: str, msg_id: str = "", indent: int = 0):
        """Log a debug message"""

        line = LogLine(
            self._config,
            self._logger_name,
            message,
            DEBUG,
            indent=indent,
        )
        self._handle_log(line, msg_id)

    def header(self, message: str, msg_id: str = ""):
        """Log a header message"""

        line = LogLine(
            self._config,
            self._logger_name,
            "\n"
            + (f" {message} ".center(100, self._config.header_char))
            + "\n",
            INFO,
            text_color=BColors.OKCYAN,
            show_info=False,
        )
        self._handle_log(line, msg_id)

    def _handle_log(self, line: LogLine, msg_id: str):
        """Handle the log message"""

        if not line.level.severity >= self._level.severity:
            return

        if self._config.auto_indent:

            stack = traceback.extract_stack()
            current_indent_level = (
                len(stack) - 4
            )  # 4 is the number of stack frames before the log call
            line.indent += current_indent_level - self.indent_level

        if self._write_manager:
            self._write_manager.write_to_file(line, msg_id)

        if self._config.console_output:
            print(line.as_str(use_color=self._config.use_color))

    def write_batch_to_file(self, lines: list[str], msg_id: str = ""):
        """Write a batch of lines to the log file"""

        if not self._write_manager:
            raise ValueError("No write manager set")

        filepath = self._write_manager.get_log_filepath(msg_id)

        try:
            with open(
                filepath, "a+" if filepath.exists() else "w+", encoding="utf-8"
            ) as f:
                f.writelines("\n".join(lines))
        except PermissionError:
            pass

    def delete_all_logs(self):
        """Delete all log files in the log directory"""

        if not self._write_manager:
            raise ValueError("No write manager set")

        self._write_manager.delete_all_logs()

    def delete_logs_older_than(self, seconds: int):
        """Delete log files older than a certain amount of seconds"""

        if not self._write_manager:
            raise ValueError("No write manager set")

        self._write_manager.delete_logs_older_than(seconds)


class Manager:
    """Class to manage loggers instances"""

    loggers: dict[str, "Logger"] = {}

    def __init__(self):
        self.loggers = {}

    def get_logger(self, logger_name: str, create: bool = True) -> Logger:
        """Get a logger instance by module name"""

        for logger in self.loggers.values():
            if logger.logger_name == logger_name:
                return logger

        if create:
            return self._create_logger(logger_name)

        raise LoggerNotFound(f"Logger {logger_name} not found")

    def get_loggers(self) -> dict[str, "Logger"]:
        """Get all loggers instances"""
        return self.loggers

    def delete_logger(self, logger_name: str) -> bool:
        """Delete a logger instance by module name"""

        if logger_name in self.loggers:
            del self.loggers[logger_name]
            return True

        return False

    def _create_logger(self, logger_name: str) -> Logger:
        """Create a new logger instance"""

        logger = Logger(logger_name=logger_name)
        self.loggers[logger.id] = logger
        return logger

    def clear_loggers(self):
        """Clear all loggers instances"""
        self.loggers.clear()


manager = Manager()


def getLogger(name: str = "", create: bool = True) -> Logger:
    """Get a logger instance by module name"""

    if not name:
        return root

    return manager.get_logger(name, create)


def get_loggers() -> dict[str, "Logger"]:
    """Get all loggers instances"""
    return manager.get_loggers()


def delete_logger(logger_name: str) -> bool:
    """Delete a logger instance by module name"""
    return manager.delete_logger(logger_name)


def clear_loggers():
    """Clear all loggers instances"""
    return manager.clear_loggers()


root = Logger(logger_name="root")


def basicConfig(
    level: LogLevel = INFO,
    config: LogConfig | None = None,
    logger_name: str = "root",
) -> None:
    """Set the basic configuration for the root logger"""

    root.setLoggerName(logger_name)
    root.setLevel(level)
    root.setConfig(config if config else LogConfig())


def setLevel(level: LogLevel) -> None:
    """Set the log level for the root logger"""
    root.setLevel(level)


def info(message: str, msg_id: str = "", indent: int = 0):
    """Log an info message"""
    root.info(message, msg_id, indent)


def warning(message: str, msg_id: str = "", indent: int = 0):
    """Log a warning message"""
    root.warning(message, msg_id, indent)


def error(message: str, msg_id: str = "", indent: int = 0):
    """Log an error message"""
    root.error(message, msg_id, indent)


def critical(message: str, msg_id: str = "", indent: int = 0):
    """Log a critical message"""
    root.critical(message, msg_id, indent)


def exception(message: str, msg_id: str = "", indent: int = 0):
    """Log an exception message"""
    root.exception(message, msg_id, indent)


def debug(message: str, msg_id: str = "", indent: int = 0):
    """Log a debug message"""
    root.debug(message, msg_id, indent)


def header(message: str, msg_id: str = ""):
    """Log a header message"""
    root.header(message, msg_id)
