import time

import bpy

from ...libs import neologging
from ...manager.props import EZS_SceneStates, get_scene_state_manager
from ...utils import get_prefs
from ..props import get_render_props


class WM_OT_refresh_render_process(bpy.types.Operator):
    """Refresh Render Process"""

    bl_idname = "wm.refresh_render_process"
    bl_label = "Refresh Render Process"

    _timer: bpy.types.Timer

    def modal(self, context, event):  # type: ignore
        render_props = get_wm_render_props(context)
        if render_props.cancelled:
            self.report({"WARNING"}, "EasyStates Render Cancelled")
            context.window_manager.event_timer_remove(self._timer)
            return {"CANCELLED"}
        if render_props.finished:
            self.report({"INFO"}, "EasyStates Render Finished")
            context.window_manager.event_timer_remove(self._timer)
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        bpy.ops.render.easystates_render_macro("INVOKE_DEFAULT")
        wm = context.window_manager
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class EASYSTATES_OT_setup_render_state(bpy.types.Operator):
    """Setup Render State"""

    bl_idname = "easystates.setup_render_state"
    bl_label = "Setup Pre Render"

    id: bpy.props.StringProperty()  # type: ignore

    def _update_render_slot(self, idx: int):
        """Update render slot."""

        render_result: list[bpy.types.Image] = [
            i for i in bpy.data.images if i.type == "RENDER_RESULT"
        ]  # type:ignore

        if not render_result:
            neologging.warning("No render result found")
            return

        if idx < 0 or idx > 8:
            neologging.warning("Invalid render slot index")
            return

        render_result[0].render_slots.active_index = idx

    def modal(self, context, event):
        elapsed_time = time.time() - self._start_time
        if elapsed_time >= self._cooldown_time:
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        wm_render_props = get_wm_render_props(context)
        render_props = get_render_props(context.scene)

        if wm_render_props.cancelled:
            neologging.debug("Render Cancelled, Skipping Setup Render State")
            return {"FINISHED"}

        wm_render_props.rendering_idx += 1
        if render_props.use_render_slots:
            self._update_render_slot(wm_render_props.rendering_idx)

        scene = context.scene
        scene_state_manager = get_scene_state_manager(scene)
        global_properties = scene_state_manager.global_properties

        scene_state = scene_state_manager.get_by_id(self.id)
        if not scene_state:
            raise ValueError(f"Scene state not found: {self.id}")

        scene_state.apply(scene, global_properties)
        output_filepath = scene_state.get_output_filepath(
            scene_state_manager.render_output, global_properties
        ).as_posix()
        
        scene_state.last_render_path = output_filepath
        scene.render.filepath = output_filepath
        
        prefs = get_prefs()

        # Cooldown to avoid write context issues
        if prefs.render.advanced_use_setup_cooldown:
            self._start_time = time.time()
            self._cooldown_time = prefs.render.advanced_setup_cooldown
            context.window_manager.modal_handler_add(self)
            return {"RUNNING_MODAL"}
        else:
            return {"FINISHED"}


def handle_render_cancel(dummy):
    """Handle Render Cancel"""
    render_props = get_wm_render_props(bpy.context)
    render_props.cancelled = True


class EASYSTATES_OT_pre_render(bpy.types.Operator):
    """Pre Render"""

    bl_idname = "easystates.pre_render"
    bl_label = "Pre Render"

    def execute(self, context):

        wm_render_props = get_wm_render_props(context)
        prefs = get_prefs()

        wm_render_props.cancelled = False
        wm_render_props.finished = False
        wm_render_props.rendering_idx = -1

        if prefs.auto_lock_interface:
            neologging.info("Locking interface for rendering")
            context.scene.render.use_lock_interface = True

        neologging.debug("Registering Render Cancel")
        bpy.app.handlers.render_cancel.append(handle_render_cancel)
        return {"FINISHED"}


class EASYSTATES_OT_post_render(bpy.types.Operator):
    """Post Render"""

    bl_idname = "easystates.post_render"
    bl_label = "Post Render"

    def _trigger_poweroff(self, context):

        props = get_render_props(context.scene)
        if props.auto_poweroff:
            if bpy.data.filepath:
                bpy.ops.wm.save_as_mainfile()

            bpy.ops.easystates.poweroff(action="SHUTDOWN")
            self.report(
                {"INFO"},
                "Powering off the computer after rendering is complete",
            )

        return

    def execute(self, context):

        self._trigger_poweroff(context)

        prefs = get_prefs()
        if prefs.auto_lock_interface:
            neologging.info("Unlocking interface after rendering")
            context.scene.render.use_lock_interface = False

        wm_render_props = get_wm_render_props(context)
        wm_render_props.rendering_idx = -1
        wm_render_props.finished = True

        neologging.debug("Unregistering Render Cancel")
        bpy.app.handlers.render_cancel.remove(handle_render_cancel)
        return {"FINISHED"}


class EASYSTATES_OT_render_wrapper(bpy.types.Operator):
    """Render Wrapper"""

    bl_idname = "easystates.render_wrapper"
    bl_label = "Render Wrapper"

    animation: bpy.props.BoolProperty(default=False)  # type: ignore
    write_still: bpy.props.BoolProperty(default=True)  # type: ignore

    def modal(self, context, event):
        if not bpy.app.is_job_running("RENDER"):
            return {"FINISHED"}
        return {"RUNNING_MODAL"}

    def invoke(self, context, event):
        render_props = context.window_manager.render_props
        if render_props.cancelled:
            neologging.debug("Cancelled, Skipping Render")
            return {"FINISHED"}

        bpy.ops.render.render(
            "INVOKE_DEFAULT",  # type:ignore
            use_viewport=False,
            write_still=self.write_still,
            animation=self.animation,
        )
        context.window_manager.modal_handler_add(self)
        return {"RUNNING_MODAL"}


class EZS_OT_MacroRender(bpy.types.Operator):
    """Render Scene States"""

    bl_idname = "easystates.macro_render"
    bl_label = "Macro Render"
    bl_options = {"REGISTER", "UNDO"}

    @staticmethod
    def _register_macro() -> type[bpy.types.Macro]:
        """Register Render Macro Operator."""

        class RENDER_OT_easystates_render_macro(bpy.types.Macro):
            """EasyStates Render Macro"""

            bl_idname = "render.easystates_render_macro"
            bl_label = "EasyStates Render Macro"

            @classmethod
            def define(cls, idname, **kwargs):
                """Define operator."""
                op = super().define(idname).properties
                for key, val in kwargs.items():
                    setattr(op, key, val)

        old = getattr(bpy.types, "RENDER_OT_easystates_render_macro", False)
        if old:
            bpy.utils.unregister_class(old)
        bpy.utils.register_class(RENDER_OT_easystates_render_macro)
        return RENDER_OT_easystates_render_macro

    def execute(self, context: bpy.types.Context):
        """Execute operator."""

        scene = context.scene

        render_props = get_render_props(scene)
        scene_state_manager = get_scene_state_manager(scene)

        scene_states: list[EZS_SceneStates] = scene_state_manager.scene_states

        macro = self._register_macro()
        macro.define("EASYSTATES_OT_pre_render")

        for scene_state in scene_states:
            if not scene_state.render:
                continue

            macro.define(
                "EASYSTATES_OT_setup_render_state",
                id=scene_state.id,
            )
            macro.define(
                # "RENDER_OT_render",
                "EASYSTATES_OT_render_wrapper",
                animation=scene_state.render_as_animation(scene),
                write_still=render_props.save_output,
            )

        macro.define("EASYSTATES_OT_post_render")
        bpy.ops.wm.refresh_render_process("INVOKE_DEFAULT")
        return {"FINISHED"}


class EZS_WM_RenderProps(bpy.types.PropertyGroup):
    """Render Properties"""

    finished: bpy.props.BoolProperty(
        default=False, description="Mark process as finished"
    )  # type: ignore
    cancelled: bpy.props.BoolProperty(
        default=False, description="Mark process as cancelled"
    )  # type: ignore
    rendering_idx: bpy.props.IntProperty(
        default=-1, description="Keeps track of the current render index"
    )  # type: ignore


classes = (
    EZS_WM_RenderProps,
    EASYSTATES_OT_pre_render,
    EASYSTATES_OT_setup_render_state,
    EASYSTATES_OT_post_render,
    WM_OT_refresh_render_process,
    EZS_OT_MacroRender,
    EASYSTATES_OT_render_wrapper,
)


def _append_render_cancel_label(self, context: bpy.types.Context):
    """Append cancel render button to image editor header."""

    wm_render_props = get_wm_render_props(context)
    if wm_render_props.rendering_idx == -1:
        return

    sima = context.space_data
    ima = sima.image

    if not ima:
        return
    if not ima.type == "RENDER_RESULT":
        return

    layout = self.layout

    box = layout.box()
    box.alert = True
    box.label(text="[EasyStates] Press [ESC] To Cancel", icon="RENDER_RESULT")


def get_wm_render_props(context: bpy.types.Context) -> EZS_WM_RenderProps:
    """Get WindowManager render properties.(Not Persistent)"""
    return context.window_manager.render_props


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    # register window prop
    bpy.types.WindowManager.render_props = bpy.props.PointerProperty(
        type=EZS_WM_RenderProps
    )

    # Register cancel render button
    bpy.types.IMAGE_HT_header.append(_append_render_cancel_label)


def unregister():
    for cls in classes:
        bpy.utils.unregister_class(cls)

    del bpy.types.WindowManager.render_props

    bpy.types.IMAGE_HT_header.remove(_append_render_cancel_label)
