import bpy

from ...manager.props import get_scene_state_manager


class EZS_OT_SingleRender(bpy.types.Operator):
    """Render Scene States"""

    bl_idname = "easystates.single_render"
    bl_label = "Single Render"
    bl_options = {"REGISTER", "UNDO"}

    id: bpy.props.StringProperty()  # type: ignore

    def execute(self, context: bpy.types.Context):
        """Execute operator."""

        scene = context.scene
        scene_state_manager = get_scene_state_manager(scene)
        global_properties = scene_state_manager.global_properties

        scene_state = scene_state_manager.get_by_id(self.id)
        if not scene_state:
            self.report({"ERROR"}, f"Scene state with id {self.id} not found")
            return {"CANCELLED"}

        scene_state.apply(scene, global_properties)
        output_filepath = scene_state.get_output_filepath(
            scene_state_manager.render_output, global_properties
        ).as_posix()
        
        scene_state.last_render_path = output_filepath
        scene.render.filepath = output_filepath
        
        bpy.ops.render.render(
            "INVOKE_DEFAULT",  # type:ignore
            animation=scene_state.render_as_animation(scene),
            write_still=True,
        )

        return {"FINISHED"}


def register():
    bpy.utils.register_class(EZS_OT_SingleRender)


def unregister():
    bpy.utils.unregister_class(EZS_OT_SingleRender)
