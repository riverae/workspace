from . import (  # modal_render,; legacy_render,
    background_render,
    macro_render,
    render_utils,
    single_render,
)


def register():

    render_utils.register()
    background_render.register()
    macro_render.register()
    single_render.register()
    # modal_render.register()
    # legacy_render.register()


def unregister():

    single_render.unregister()
    macro_render.unregister()
    background_render.unregister()
    render_utils.unregister()
    # legacy_render.unregister()
    # modal_render.unregister()
