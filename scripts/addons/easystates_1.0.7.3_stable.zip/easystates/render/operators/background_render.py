import traceback

import bpy
from bpy.types import Context

from ...libs import neologging
from ...manager.props import EZS_SceneStates, get_scene_state_manager


class EZS_OT_BackgroundRender(bpy.types.Operator):
    """Render Scene States"""

    bl_idname = "easystates.background_render"
    bl_label = "Background Render"
    bl_options = {"REGISTER", "UNDO"}

    scene_state_id: bpy.props.StringProperty()  # type:ignore

    def execute(self, context: Context):
        """Execute operator."""

        scene = context.scene
        scene_state_manager = get_scene_state_manager(scene)
        global_properties = scene_state_manager.global_properties
        scene_states: list[EZS_SceneStates] = scene_state_manager.scene_states

        original_output = scene.render.filepath
        for scene_state in scene_states:
            if not scene_state.render:
                continue
            scene_state.apply(scene, global_properties)
            scene.render.filepath = scene_state.get_output_filepath(
                scene_state_manager.render_output, global_properties
            ).as_posix()
            try:
                bpy.ops.render.render(
                    write_still=True,
                    animation=scene_state.render_as_animation(scene),
                )
            except Exception:  # pylint: disable=broad-except
                neologging.exception(traceback.format_exc())
                return {"CANCELLED"}
            finally:
                scene.render.filepath = original_output

        return {"FINISHED"}


def register():
    bpy.utils.register_class(EZS_OT_BackgroundRender)


def unregister():
    bpy.utils.unregister_class(EZS_OT_BackgroundRender)
