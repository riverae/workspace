import os

import bpy
from bpy.types import Context

from ..props import get_render_props


class EZS_OT_PowerOff(bpy.types.Operator):
    """Power off the computer after rendering."""

    bl_idname = "easystates.poweroff"
    bl_label = "Render"
    bl_options = {"REGISTER", "UNDO"}

    power_off_time: bpy.props.IntProperty(
        name="Time",
        description="Time in seconds before powering off the computer",
        default=60,
    )  # type:ignore

    action: bpy.props.EnumProperty(
        items=[
            ("SHUTDOWN", "Shutdown", "Shutdown the computer"),
            ("ABORT", "Suspend", "Suspend the computer"),
        ],
        name="Action",
        description="Action to perform",
        default="SHUTDOWN",
    )  # type:ignore

    def execute(self, context: Context):

        render_props = get_render_props(context.scene)

        if self.action == "SHUTDOWN":
            self.report(
                {"INFO"},
                f"Powering off the computer in {self.power_off_time} seconds...",
            )
            render_props.poweroff_requested = True
            os.system(f"shutdown /s /t {self.power_off_time}")

        elif self.action == "ABORT":
            render_props.poweroff_requested = False
            self.report({"INFO"}, "Aborting the computer shutdown...")
            os.system("shutdown /a")

        return {"FINISHED"}


def register():
    bpy.utils.register_class(EZS_OT_PowerOff)


def unregister():
    bpy.utils.unregister_class(EZS_OT_PowerOff)
