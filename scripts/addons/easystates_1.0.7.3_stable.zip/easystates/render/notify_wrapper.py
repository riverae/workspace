# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

# pylint: disable=unused-import;
import functools
import shutil
from pathlib import Path

import addon_utils
import bpy
from bpy.types import Scene

from ..libs import neologging

notify_import_error = False


def is_notify_active() -> bool:
    """Check if notify is active."""

    if notify_import_error:
        return False
    if not addon_utils.check("future_module")[0]:  # type:ignore
        return False
    return True


if is_notify_active():
    # Import notify props class only for type hints
    try:
        from future_module.addon.props import NOTIFY_AddonMainProps
    except ImportError:
        notify_import_error = True
        neologging.error("Error importing notify props")


class EZS_NotifyWrapper(bpy.types.PropertyGroup):
    """Notify Wrapper."""

    def _get_notify_props(
        self, scene: Scene
    ) -> "NOTIFY_AddonMainProps | None":
        """Get notify props."""

        if not is_notify_active():
            return None

        from future_module.addon.props import get_props as get_notify_props

        return get_notify_props(scene)

    def _get_notify_task(self, scene: Scene, notify_id: str):
        """Get notify task."""

        notify_props = self._get_notify_props(scene)
        if notify_props:
            return notify_props.get_task_by_id(notify_id)

        return None

    def render_task(self, scene: Scene, notify_id: str):
        """Notify render task."""
        notify_task = self._get_notify_task(scene, notify_id)
        if notify_task:
            notify_task.render_task()

    def end_task(self, scene: Scene, notify_id: str):
        """Notify end task."""
        notify_task = self._get_notify_task(scene, notify_id)
        if notify_task:
            notify_task.end_task()

    def add_task(self, scene: Scene, name: str):
        """Add task."""
        notify_props = self._get_notify_props(scene)
        if notify_props:
            return notify_props.add_task(scene, name=name)
        return None

    def clear_tasks(self, scene: Scene):
        """Clear tasks."""
        notify_props = self._get_notify_props(scene)
        if notify_props:
            notify_props.clear_tasks()

    def toggle_default_render_handles(
        self, value: bool, scene: Scene, timer: int = 0
    ):
        """EasyStates and EasyStates Notify works
        based on handles, so when EasyStates is rendering
        we need to disable the notify rendering handles.

        Args:
            value (bool): Value to set
            scene (Scene): Scene
            timer (int, optional): Timer. Defaults to 0,
            use timer to make sure it's done after render complete.
        """
        notify_props = self._get_notify_props(scene)
        if notify_props:
            if timer:
                bpy.app.timers.register(
                    functools.partial(
                        notify_props.toggle_default_render_handles, value
                    ),
                    first_interval=timer,
                )
            else:
                notify_props.toggle_default_render_handles(value)

    def cancel_running_tasks(self, scene: Scene):
        """Cancel tasks."""

        notify_props = self._get_notify_props(scene)
        if notify_props:
            for task in notify_props.tasks:
                if not task.status in ("COMPLETE", "ERROR"):
                    task.end_task(status="CANCELLED")

    def save_task_output(self, scene: Scene, notify_id: str, image: Path):
        """Save task output."""

        task = self._get_notify_task(scene, notify_id)
        if not task:
            return

        if not image.exists():
            neologging.warning(f"NOTIFY OUTPUT: Image not found: {image}")
            return

        target = Path(task.render_dir) / image.name
        shutil.copy(image, target)

        neologging.info(f"NOTIFY OUTPUT: Saved image: {target}")

    def send_pipe_data(self):
        """Send pipe data."""
        if is_notify_active():
            bpy.ops.notify.send_pipe_data()
