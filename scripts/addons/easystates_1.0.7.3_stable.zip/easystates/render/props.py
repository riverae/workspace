import bpy

# A global variable that stores a critical interal error in the rendering process
#
# usually is AttributeError: Writing to ID classes in this context is not allowed:
# Scene, Scene datablock, error setting EZS_SceneStates.last_render_path
#
# This error is still under investigation, and when it happens
# the user should restart blender, and it's possible the user will
# be able to render only in the background mode.
CRITICAL_RENDER_ERROR = []


class EZS_RenderProps(bpy.types.PropertyGroup):
    """Addon Main Properties."""

    # notify_wrapper: bpy.props.PointerProperty(
    #     type=EZS_NotifyWrapper
    # )  # type:ignore

    background_render: bpy.props.BoolProperty(
        default=False,
        name="Background Render",
        description=(
            "Completely freeze the UI during rendering. "
            "This is useful for large scenes with high memory usage. "
            "The UI unfreezes only after the rendering process is complete."
        ),
    )  # type:ignore

    auto_poweroff: bpy.props.BoolProperty(
        default=False,
        name="Auto Poweroff",
        description="Automatically power off the computer after rendering is complete",
    )  # type:ignore

    poweroff_requested: bpy.props.BoolProperty(
        default=False,
        name="Poweroff Requested",
    )  # type:ignore

    use_render_slots: bpy.props.BoolProperty(
        default=False,
        name="Use Render Slots",
        description="Use render slots to store render results",
    )  # type:ignore

    save_output: bpy.props.BoolProperty(
        default=True,
        name="Save Render Output",
        description="Save each scene state render output; disable to skip EasyState output saving. This is useful if you want to use your own compositor output node configuration.",
    )  # type:ignore


def get_render_props(scene: bpy.types.Scene) -> EZS_RenderProps:
    """Get addon properties."""
    return scene.easystates_render


classes = (EZS_RenderProps,)


def register():
    """Register properties."""

    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)

    bpy.types.Scene.easystates_render = bpy.props.PointerProperty(
        type=EZS_RenderProps
    )


def unregister():
    """Unregister properties."""

    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)

    del bpy.types.Scene.easystates_render
