# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

"""Example UI module."""

from typing import Any

import bpy
from bpy.types import Context

from ..constants import FAILED_TO_LOAD_KEY, FAILED_TO_LOAD_REASON_KEY
from ..manager.props import get_scene_state_manager
from ..manager.props.global_properties import (
    GlobalSceneStateProperties,
    SceneModifierGlobalProps,
)
from ..render.props import CRITICAL_RENDER_ERROR, get_render_props
from ..utils import get_prefs
from .props import EZS_SceneStates, EZS_SceneStatesManager


class BaseAddonPanel:
    """Base Panel."""

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "EasyStates"
    bl_label = "EasyStates"

    @classmethod
    def poll(cls, context: Context) -> bool:
        """Check if the panel should be displayed."""
        return not bpy.context.scene.get(FAILED_TO_LOAD_KEY, False)


class EZS_PT_FailedToLoadPanel(bpy.types.Panel):
    """Failed to Load Panel"""

    bl_space_type = "VIEW_3D"
    bl_region_type = "UI"
    bl_category = "EasyStates"
    bl_label = "Failed to Load"

    @classmethod
    def poll(cls, context: Context) -> bool:
        """Check if the panel should be displayed."""
        return bpy.context.scene.get(FAILED_TO_LOAD_KEY, False)  # type:ignore

    def draw(self, context: Context):
        layout = self.layout

        col = layout.column(align=True)

        box = col.box()
        box.alert = True
        box.label(text="Failed to load EasyStates properties.", icon="ERROR")

        box = col.box()
        box.label(
            text=f"Reason: {bpy.context.scene.get(FAILED_TO_LOAD_REASON_KEY, 'None')}",
            icon="INFO",
        )


class EZS_PT_SceneStateModifiers(BaseAddonPanel, bpy.types.Panel):
    """Modifiers Panel"""

    bl_label = "Scene Modifiers"
    bl_parent_id = "EZS_PT_RenderManager"

    @classmethod
    def poll(cls, context: Context) -> bool:
        """Check if the panel should be displayed."""
        return get_scene_state_manager(context.scene).get_active() is not None

    def draw_header(self, context: Context):

        layout = self.layout

        row = layout.row(align=True)
        row.separator()
        row.popover(
            "EZS_PT_SelectSceneModifiers",
            text="",
            icon="PRESET_NEW",
            # icon="DOWNARROW_HLT",
        )
        row.separator()

        # layout.operator(
        #     "easystates.select_scene_states_modifiers",
        #     text="",
        #     icon="PRESET_NEW",
        #     emboss=True,
        # )

    def draw_header_preset(self, context: Context):

        layout = self.layout
        scene_state_manager = get_scene_state_manager(context.scene)

        layout.prop(
            scene_state_manager,
            "sync_scene_values",
            icon="UV_SYNC_SELECT",
            text="",
        )

    def draw(self, context: Context):

        layout = self.layout
        scene_state_manager = get_scene_state_manager(context.scene)

        active_scene_state = scene_state_manager.get_active()
        if not active_scene_state:
            return

        active_scene_state.draw_props(
            context, layout, scene_state_manager.global_properties
        )


class EZS_PT_Render(BaseAddonPanel, bpy.types.Panel):
    """Modifiers Panel."""

    bl_label = "Render All"
    bl_parent_id = "EZS_PT_RenderManager"

    @classmethod
    def poll(cls, context: Context) -> bool:
        """Check if the panel should be displayed."""
        return len(get_scene_state_manager(context.scene).scene_states) > 0

    def _get_total_to_render(self, context: Context) -> int:

        scene_state_manager = get_scene_state_manager(context.scene)
        to_render = 0
        for scene_state in scene_state_manager.scene_states:
            if scene_state.render:
                to_render += 1

        return to_render

    def draw_header(self, context: Context):
        layout = self.layout
        layout.label(text="", icon="RENDER_RESULT")

    def draw(self, context: Context):

        layout = self.layout

        render_manager = get_scene_state_manager(context.scene)
        render_props = get_render_props(context.scene)

        col = layout.column(align=True)
        if CRITICAL_RENDER_ERROR:
            box = col.box()
            box.alert = True

            # TODO: Add documentation page explaining the bug
            box.label(
                text="Internal EasyStates Error, Blender should be restarted.",
                icon="ERROR",
            )
            box = col.box()
            box.alert = True
            box.label(
                text="If this error persists, Use 'Background Render' option (Render Utils)",
                icon="INFO",
            )
            # TODO: Add report page button
            box = col.box()
            box.alert = True
            box.label(
                text="This should not happen, please report this issue.",
                icon="INFO",
            )

            return

        box = col.box()

        row = box.row(align=True)
        row.label(
            text=f"Total Scene States: {len(render_manager.scene_states)}",
            icon="SCENE",
        )
        row.label(
            text=f"Rendering: {self._get_total_to_render(context)}",
            icon="RENDER_RESULT",
        )

        box = col.box()

        row = box.row(align=True)
        row.enabled = render_props.save_output
        row.prop(render_manager, "render_output")

        row = col.row(align=True)
        row.scale_y = 1.5

        if render_props.background_render:
            row.operator(
                "easystates.background_render",
                text="Background Render",
                icon="RENDER_RESULT",
            )
        else:
            # row.operator(
            #     "easyrender.render_all_modal", text="Render All", icon="RENDER_RESULT"
            # )

            # row.operator(
            #     "easystates.render", text="Render All", icon="RENDER_RESULT"
            # ).scene_state_id = ""

            row.operator(
                "easystates.macro_render",
                text="Render All",
                icon="RENDER_RESULT",
            )


class EZS_PT_RenderUtils(BaseAddonPanel, bpy.types.Panel):
    """Render Utils Panel."""

    bl_label = "Render Utils"
    bl_parent_id = "EZS_PT_RenderManager"

    @classmethod
    def poll(cls, context: Context) -> bool:
        """Check if the panel should be displayed."""
        return len(get_scene_state_manager(context.scene).scene_states) > 0

    def draw_header(self, context: Context):
        layout = self.layout
        layout.label(text="", icon="TOOL_SETTINGS")

    def draw(self, context: Context):

        layout = self.layout
        col = layout.column(align=True)
        box = col.box()

        render_props = get_render_props(context.scene)

        row = box.row(align=True)
        row.prop(render_props, "save_output")

        row = box.row(align=True)
        row.prop(render_props, "use_render_slots")

        if not render_props.poweroff_requested:
            row = box.row(align=True)
            row.prop(render_props, "auto_poweroff")
        else:
            box = col.box()
            row = box.row(align=True)
            row.label(text="Poweroff requested", icon="ERROR")
            row.operator(
                "easystates.poweroff", text="Cancel", icon="CANCEL"
            ).action = "ABORT"

        row = box.row(align=True)
        row.prop(render_props, "background_render")


class EZS_PT_RenderManager(BaseAddonPanel, bpy.types.Panel):
    """Example Operator Panel."""

    bl_label = " EasyStates"
    bl_options = {"DEFAULT_CLOSED"}

    def get_add_scene_state_operator_text(self, context: Context) -> str:
        """Get add scene_state operator text."""

        selected_cameras = [
            ob for ob in context.selected_objects if ob.type == "CAMERA"
        ]

        if selected_cameras:
            if len(selected_cameras) > 1:
                return f"Batch Add Scene States ({len(selected_cameras)} selected cameras)"
            return "Add Scene State from Selected Camera"

        return "Add Scene State From Current View"

    def draw(self, context: Context):

        layout = self.layout
        scene_state_manager = get_scene_state_manager(context.scene)

        row = layout.row()
        row.scale_y = 1.5

        row.operator(
            "easystates.manage",
            icon="ADD",
            text=self.get_add_scene_state_operator_text(context),
        ).action = "ADD"

        row = layout.row()
        row.template_list(
            "EZS_PT_UL_items",
            "",
            scene_state_manager,
            "scene_states",
            scene_state_manager,
            "scene_states_index",
            rows=8,
        )

        col = row.column(align=True)
        col.operator("easystates.manage", text="", icon="TRASH").action = (
            "REMOVE"
        )
        col.separator()
        col.operator("easystates.manage", text="", icon="TRIA_UP").action = (
            "UP"
        )
        col.operator("easystates.manage", text="", icon="TRIA_DOWN").action = (
            "DOWN"
        )

        col.separator()
        col.operator(
            "easystates.duplicate_scene_state", text="", icon="DUPLICATE"
        )

        col.separator()
        col.prop(
            scene_state_manager,
            "enable_selection",
            text="",
            icon="CHECKBOX_HLT",
        )

        if scene_state_manager.enable_selection:
            col.operator(
                "easystates.scene_states_selection",
                text="",
                icon="RESTRICT_SELECT_OFF",
            ).action = "SELECT"
            col.operator(
                "easystates.scene_states_selection",
                text="",
                icon="RESTRICT_SELECT_ON",
            ).action = "DESELECT"
            col.operator(
                "easystates.scene_states_selection",
                text="",
                icon="UV_SYNC_SELECT",
            ).action = "INVERT"

        if not scene_state_manager.scene_states:
            box = layout.box()
            box.label(text="No scene states created.", icon="INFO")


class EZS_MT_ColVizRestrictionToggles(bpy.types.Panel):
    """Menu for toggling collection visibility restrictions."""

    bl_idname = "EZS_PT_ColVizRestrictionTogglesMenu"
    bl_label = "Restrictions Toggles"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"

    # Drawing a nested menu with three operators(buttons)
    def draw(self, context: Context):  # type:ignore
        """Draw the menu."""

        manager = get_scene_state_manager(context.scene)
        global_properties = manager.global_properties
        col_viz_props = global_properties.collection_visibility_modifier

        layout = self.layout
        row = layout.row(align=True)
        row.prop(col_viz_props, "use_exclude", icon="CHECKBOX_HLT", text="")
        row.prop(
            col_viz_props,
            "use_hide_select",
            icon="RESTRICT_SELECT_OFF",
            text="",
        )
        row.prop(
            col_viz_props,
            "use_hide_viewport_layer",
            icon="HIDE_OFF",
            text="",
        )
        row.prop(
            col_viz_props,
            "use_hide_viewport",
            icon="RESTRICT_VIEW_OFF",
            text="",
        )

        row.prop(
            col_viz_props,
            "use_hide_render",
            icon="RESTRICT_RENDER_OFF",
            text="",
        )

        row.prop(
            col_viz_props,
            "use_holdout",
            icon="HOLDOUT_ON",
            text="",
        )

        row.prop(
            col_viz_props,
            "use_indirect_only",
            icon="INDIRECT_ONLY_ON",
            text="",
        )


class EZS_MT_ObjVizRestrictionToggles(bpy.types.Panel):
    """Menu for toggling objects visibility restrictions."""

    bl_idname = "EZS_PT_ObjVizRestrictionToggles"
    bl_label = "Restrictions Toggles"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"

    # Drawing a nested menu with three operators(buttons)
    def draw(self, context: Context):  # type:ignore
        """Draw the menu."""

        manager = get_scene_state_manager(context.scene)
        global_properties = manager.global_properties
        obj_viz_props = global_properties.objects_visibility_modifier

        layout = self.layout
        row = layout.row(align=True)

        row.prop(
            obj_viz_props,
            "use_hide_select",
            icon="RESTRICT_SELECT_OFF",
            text="",
        )
        row.prop(
            obj_viz_props,
            "use_hide_set",
            icon="HIDE_OFF",
            text="",
        )
        row.prop(
            obj_viz_props,
            "use_hide_viewport",
            icon="RESTRICT_VIEW_OFF",
            text="",
        )

        row.prop(
            obj_viz_props,
            "use_hide_render",
            icon="RESTRICT_RENDER_OFF",
            text="",
        )


class EZS_MT_SelectSceneModifiers(bpy.types.Panel):
    """Select Scene State Modifiers"""

    bl_idname = "EZS_PT_SelectSceneModifiers"
    bl_label = "Scene Modifiers"
    bl_space_type = "VIEW_3D"
    bl_region_type = "WINDOW"

    # Drawing a nested menu with three operators(buttons)
    def draw(self, context: Context):

        layout = self.layout
        layout.label(text="Manage Scene Modifiers")

        scene_state_manager = get_scene_state_manager(context.scene)
        global_properties = scene_state_manager.global_properties

        col = layout.column(align=True)

        for annotation in global_properties.__annotations__:

            if not annotation.endswith("_modifier"):
                continue

            modifier_global_props = getattr(global_properties, annotation)
            if not isinstance(modifier_global_props, SceneModifierGlobalProps):
                continue

            row = col.row(align=True)
            row.prop(
                modifier_global_props,
                "enabled",
                text=modifier_global_props.modifier_name,
                icon=modifier_global_props.icon,
            )


class EZS_PT_UL_items(bpy.types.UIList):
    """Scene State List UI."""

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: EZS_SceneStatesManager,
        item: EZS_SceneStates,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        if data.enable_selection:
            col = layout.column(align=True)
            col.prop(item, "selected", text="")

        col = layout.column(align=True)
        col.prop(
            item,
            "render",
            text="",
            icon=(
                "RESTRICT_RENDER_OFF" if item.render else "RESTRICT_RENDER_ON"
            ),
            emboss=False,
            translate=False,
        )

        col = layout.column(align=True)
        col.prop(
            item,
            "name",
            text="",
            emboss=False,
            translate=False,
        )

        # get scene camera
        col = layout.column(align=True)
        col.active = False

        global_properties = get_scene_state_manager(
            context.scene
        ).global_properties

        if (
            item.camera_modifier.camera
            and get_prefs().ui_show_scene_cameras
            and item.camera_modifier.enabled(global_properties)
        ):
            camera_label = item.camera_modifier.camera.name
            col.label(
                text=camera_label,
                icon="CAMERA_DATA",
            )

        col = layout.column(align=True)
        if index == active_data.scene_states_index:
            col.operator(
                "easystates.single_render",
                text="",
                icon="RENDER_STILL",
                emboss=False,
            ).id = item.id
        else:
            col.label(text="", icon="BLANK1")

        col = layout.column(align=True)
        col.enabled = bool(item.last_render_path)
        col.operator(
            "easystates.open_last_render",
            text="",
            icon="IMAGE_DATA",
            emboss=False,
        ).scene_state_id = item.id


class EZS_UL_CollectionVisibility(bpy.types.UIList):
    """Collection Visibility UI."""

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        manager = get_scene_state_manager(context.scene)
        global_properties = manager.global_properties
        col_viz_props = global_properties.collection_visibility_modifier

        row = layout.row(align=True)

        if item.collection:

            row.prop(
                item.collection,
                "name",
                text="",
                emboss=False,
                translate=False,
                icon="OUTLINER_COLLECTION",
            )

            if col_viz_props.use_exclude:
                row.prop(
                    item,
                    "exclude",
                    text="",
                    emboss=False,
                    icon=(
                        "CHECKBOX_HLT"
                        if not item.exclude
                        else "CHECKBOX_DEHLT"
                    ),
                )

            if col_viz_props.use_hide_select:
                row.prop(
                    item,
                    "hide_select",
                    text="",
                    emboss=False,
                    translate=False,
                    icon=(
                        "RESTRICT_SELECT_OFF"
                        if not item.hide_select
                        else "RESTRICT_SELECT_ON"
                    ),
                )

            if col_viz_props.use_hide_viewport_layer:
                row.prop(
                    item,
                    "hide_viewport_layer",
                    text="",
                    emboss=False,
                    translate=False,
                    icon=(
                        "HIDE_OFF"
                        if not item.hide_viewport_layer
                        else "HIDE_ON"
                    ),
                )

            if col_viz_props.use_hide_viewport:
                row.prop(
                    item,
                    "hide_viewport",
                    text="",
                    emboss=False,
                    icon=(
                        "RESTRICT_VIEW_OFF"
                        if not item.hide_viewport
                        else "RESTRICT_VIEW_ON"
                    ),
                )

            if col_viz_props.use_hide_render:
                row.prop(
                    item,
                    "hide_render",
                    text="",
                    emboss=False,
                    icon=(
                        "RESTRICT_RENDER_OFF"
                        if not item.hide_render
                        else "RESTRICT_RENDER_ON"
                    ),
                )

            if col_viz_props.use_holdout:
                row.prop(
                    item,
                    "holdout",
                    text="",
                    emboss=False,
                    translate=False,
                    icon=("HOLDOUT_ON" if item.holdout else "HOLDOUT_OFF"),
                )

            if col_viz_props.use_indirect_only:
                row.prop(
                    item,
                    "indirect_only",
                    text="",
                    emboss=False,
                    translate=False,
                    icon=(
                        "INDIRECT_ONLY_ON"
                        if item.indirect_only
                        else "INDIRECT_ONLY_OFF"
                    ),
                )

        else:
            row.label(text="Collection not found.", icon="ERROR")

        row.operator(
            "easystates.remove_global_collection_property_item",
            icon="X",
            text="",
            emboss=False,
        ).global_id = item.global_id


class EZS_UL_MaterialSlotsOverwrites_Object(bpy.types.UIList):
    """Material Slots Objects UI."""

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        if item.object:
            layout.prop(
                item.object,
                "name",
                text="",
                emboss=False,
                translate=False,
                icon="OBJECT_DATA",
            )

        else:
            layout.label(text="Object not found.", icon="ERROR")

        layout.operator(
            "easystates.remove_global_collection_property_item",
            icon="X",
            text="",
            emboss=False,
        ).global_id = item.global_id


class EZS_UL_MaterialSlotsOverwrites_Materials(bpy.types.UIList):
    """Material Slots Objects UI."""

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        row = layout.row(align=True)
        col = row.column(align=True)
        col.alert = not item.material
        col.prop(
            item,
            "material",
            text="",
            icon_value=layout.icon(item.material) if item.material else 0,
        )
        col = row.column(align=True)

        # check if there is more than one material slot index with same value
        col.alert = [
            i.slot_index
            for i in data.material_slots
            if i.slot_index == item.slot_index
        ].count(item.slot_index) > 1

        col.prop(item, "slot_index", text="Slot Index")

        col = row.column(align=True)
        col.operator(
            "easystates.remove_global_collection_property_item",
            emboss=True,
            icon="X",
            text="",
        ).global_id = item.global_id


class EZS_UL_ObjectVisibility(bpy.types.UIList):
    """Item Visibility UI."""

    def filter_items(  # type:ignore pylint: disable=arguments-renamed
        self, context: Context, data: Any | None, propname: str
    ) -> tuple[list[int], list[int]]:  # type:ignore

        items = getattr(data, propname)

        scene_state_manager = get_scene_state_manager(context.scene)
        global_properties = scene_state_manager.global_properties

        # Default return values.
        flt_flags = []
        flt_neworder = []

        # Initialize with all items visible
        flt_flags = [self.bitflag_filter_item] * len(items)

        if global_properties.objects_visibility_modifier.sync_selection:
            for idx, i in enumerate(items):
                if not i.object in context.selected_objects:
                    flt_flags[idx] = ~self.bitflag_filter_item

        return flt_flags, flt_neworder

    @staticmethod
    def _get_object_data_icon(obj: bpy.types.Object) -> str:
        """Get object data icon."""

        match obj.type:
            case "MESH":
                return "MESH_CUBE"
            case "CURVE":
                return "CURVE_DATA"
            case "SURFACE":
                return "SURFACE_DATA"
            case "META":
                return "META_DATA"
            case "FONT":
                return "FONT_DATA"
            case "ARMATURE":
                return "ARMATURE_DATA"
            case "LATTICE":
                return "LATTICE_DATA"
            case "EMPTY":
                return "EMPTY_DATA"
            case "CAMERA":
                return "CAMERA_DATA"
            case "LIGHT":
                return "LIGHT_DATA"
            case "SPEAKER":
                return "SPEAKER"
            case "LIGHT_PROBE":
                return "OUTLINER_DATA_LIGHTPROBE"
            case "VOLUME":
                return "VOLUME_DATA"
            case "GPENCIL":
                return "OUTLINER_OB_GREASEPENCIL"
            case _:
                return "OBJECT_DATA"

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        manager = get_scene_state_manager(context.scene)
        global_properties = manager.global_properties
        obj_viz_props = global_properties.objects_visibility_modifier

        row = layout.row(align=True)

        if item.object:

            row.prop(
                item.object,
                "name",
                text="",
                emboss=False,
                translate=False,
                icon=self._get_object_data_icon(item.object),
            )

            if obj_viz_props.use_hide_select:
                row.prop(
                    item,
                    "hide_select",
                    text="",
                    emboss=False,
                    translate=False,
                    icon=(
                        "RESTRICT_SELECT_OFF"
                        if not item.hide_select
                        else "RESTRICT_SELECT_ON"
                    ),
                )

            if obj_viz_props.use_hide_set:
                row.prop(
                    item,
                    "hide_set",
                    text="",
                    emboss=False,
                    translate=False,
                    icon=("HIDE_OFF" if not item.hide_set else "HIDE_ON"),
                )

            if obj_viz_props.use_hide_viewport:
                row.prop(
                    item,
                    "hide_viewport",
                    text="",
                    emboss=False,
                    icon=(
                        "RESTRICT_VIEW_OFF"
                        if not item.hide_viewport
                        else "RESTRICT_VIEW_ON"
                    ),
                )

            if obj_viz_props.use_hide_render:
                row.prop(
                    item,
                    "hide_render",
                    text="",
                    emboss=False,
                    icon=(
                        "RESTRICT_RENDER_OFF"
                        if not item.hide_render
                        else "RESTRICT_RENDER_ON"
                    ),
                )
        else:
            layout.label(text="Object not found.", icon="ERROR")

        row.operator(
            "easystates.remove_global_collection_property_item",
            icon="X",
            text="",
            emboss=False,
        ).global_id = item.global_id


class EZS_UL_ObjectAction(bpy.types.UIList):
    """Item Visibility UI."""

    @staticmethod
    def _get_object_data_icon(obj: bpy.types.Object) -> str:
        """Get object data icon."""

        match obj.type:
            case "MESH":
                return "MESH_CUBE"
            case "CURVE":
                return "CURVE_DATA"
            case "SURFACE":
                return "SURFACE_DATA"
            case "META":
                return "META_DATA"
            case "FONT":
                return "FONT_DATA"
            case "ARMATURE":
                return "ARMATURE_DATA"
            case "LATTICE":
                return "LATTICE_DATA"
            case "EMPTY":
                return "EMPTY_DATA"
            case "CAMERA":
                return "CAMERA_DATA"
            case "LIGHT":
                return "LIGHT_DATA"
            case "SPEAKER":
                return "SPEAKER"
            case "LIGHT_PROBE":
                return "OUTLINER_DATA_LIGHTPROBE"
            case "VOLUME":
                return "VOLUME_DATA"
            case "GPENCIL":
                return "OUTLINER_OB_GREASEPENCIL"
            case _:
                return "OBJECT_DATA"

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        if item.object:
            layout.prop(
                item.object,
                "name",
                text="",
                emboss=False,
                translate=False,
                icon=self._get_object_data_icon(item.object),
            )

            layout.prop(
                item,
                "action",
                text="",
                emboss=True,
            )

        else:
            layout.label(text="Object not found.", icon="ERROR")

        layout.operator(
            "easystates.remove_global_collection_property_item",
            icon="X",
            text="",
            emboss=False,
        ).global_id = item.global_id


class EZS_UL_ObjectTransform(bpy.types.UIList):
    """Item Visibility UI."""

    @staticmethod
    def _get_object_data_icon(obj: bpy.types.Object) -> str:
        """Get object data icon."""

        match obj.type:
            case "MESH":
                return "MESH_CUBE"
            case "CURVE":
                return "CURVE_DATA"
            case "SURFACE":
                return "SURFACE_DATA"
            case "META":
                return "META_DATA"
            case "FONT":
                return "FONT_DATA"
            case "ARMATURE":
                return "ARMATURE_DATA"
            case "LATTICE":
                return "LATTICE_DATA"
            case "EMPTY":
                return "EMPTY_DATA"
            case "CAMERA":
                return "CAMERA_DATA"
            case "LIGHT":
                return "LIGHT_DATA"
            case "SPEAKER":
                return "SPEAKER"
            case "LIGHT_PROBE":
                return "OUTLINER_DATA_LIGHTPROBE"
            case "VOLUME":
                return "VOLUME_DATA"
            case "GPENCIL":
                return "OUTLINER_OB_GREASEPENCIL"
            case _:
                return "OBJECT_DATA"

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        if item.object:
            layout.prop(
                item.object,
                "name",
                text="",
                emboss=False,
                translate=False,
                icon=self._get_object_data_icon(item.object),
            )
        else:
            layout.label(text="Object not found.", icon="ERROR")

        layout.operator(
            "easystates.remove_global_collection_property_item",
            icon="X",
            text="",
            emboss=False,
        ).global_id = item.global_id


class EZS_UL_CustomProperties(bpy.types.UIList):
    """Custom Properties UI List UI."""

    def filter_items(  # type:ignore pylint: disable=arguments-renamed
        self, context: Context, data: Any | None, propname: str
    ) -> tuple[list[int], list[int]]:  # type:ignore

        items = getattr(data, propname)

        scene_state_manager = get_scene_state_manager(context.scene)
        global_properties = scene_state_manager.global_properties
        custom_properties_global_props = (
            global_properties.custom_properties_modifier
        )

        # Default return values.
        flt_flags = []
        flt_neworder = []

        # Initialize with all items visible
        flt_flags = [self.bitflag_filter_item] * len(items)

        if (
            not custom_properties_global_props.custom_properties_categories
            == "ALL"
        ):
            for idx, item in enumerate(items):
                if (
                    not item.category_name
                    == custom_properties_global_props.custom_properties_categories
                ):

                    flt_flags[idx] = ~self.bitflag_filter_item

        return flt_flags, flt_neworder

    def draw_prop_by_value_type(
        self,
        layout: bpy.types.UILayout,
        custom_property: bpy.types.PropertyGroup,
    ):

        emboss = True

        match custom_property.value_type:
            case "FLOAT":
                layout.prop(
                    custom_property, "float_value", text="", emboss=emboss
                )
            case "INT":
                layout.prop(
                    custom_property, "int_value", text="", emboss=emboss
                )
            case "BOOL":
                layout.prop(
                    custom_property,
                    "bool_value",
                    text=(
                        "Enabled" if custom_property.bool_value else "Disabled"
                    ),
                    emboss=True,
                    icon=(
                        "CHECKBOX_HLT"
                        if custom_property.bool_value
                        else "CHECKBOX_DEHLT"
                    ),
                )
            case "STRING":
                layout.prop(
                    custom_property, "string_value", text="", emboss=emboss
                )
            case "ARRAY2":
                layout.prop(
                    custom_property, "array2_value", text="", emboss=emboss
                )
            case "ARRAY3":
                layout.prop(
                    custom_property, "array3_value", text="", emboss=emboss
                )
            case "ARRAY3COLOR":
                layout.prop(
                    custom_property,
                    "array3color_value",
                    text="",
                    emboss=emboss,
                )
            case "ARRAY4":
                layout.prop(
                    custom_property, "array4_value", text="", emboss=emboss
                )
            case "ARRAY4COLOR":
                layout.prop(
                    custom_property,
                    "array4color_value",
                    text="",
                    emboss=emboss,
                )
            case _:
                raise ValueError(
                    f"Invalid value type: {custom_property.value_type}"
                )

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        scene_state_manager = get_scene_state_manager(context.scene)
        global_properties: GlobalSceneStateProperties = (
            scene_state_manager.global_properties
        )

        custom_properties_global_props = (
            global_properties.custom_properties_modifier
        )

        global_custom_prop = (
            custom_properties_global_props.get_custom_property(item.global_id)
        )

        row = layout.row(align=True)
        row.scale_y = 1.0
        row.alert = (
            item.invalid_path or item.invalid_value or item.invalid_identifier
        )

        split = row.split(factor=0.6, align=True)
        split.prop(
            global_custom_prop,
            "name",
            text="",
            emboss=False,
            translate=False,
            icon=item.category_icon,
        )

        self.draw_prop_by_value_type(split, item)

        row.operator(
            "easystates.remove_global_collection_property_item",
            icon="ERROR" if item.invalid_path else "X",
            text="",
        ).global_id = item.global_id


classes = (
    EZS_PT_FailedToLoadPanel,
    EZS_UL_ObjectTransform,
    EZS_MT_SelectSceneModifiers,
    EZS_MT_ColVizRestrictionToggles,
    EZS_MT_ObjVizRestrictionToggles,
    EZS_UL_CollectionVisibility,
    EZS_UL_CustomProperties,
    EZS_PT_UL_items,
    EZS_UL_ObjectAction,
    EZS_UL_ObjectVisibility,
    EZS_PT_RenderManager,
    EZS_PT_SceneStateModifiers,
    EZS_PT_RenderUtils,
    EZS_PT_Render,
    EZS_UL_MaterialSlotsOverwrites_Object,
    EZS_UL_MaterialSlotsOverwrites_Materials,
)


def register():
    """Register UI classes."""
    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)


def unregister():
    """Unregister UI classes."""
    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
