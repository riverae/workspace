# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

"""Operators for the addon."""


import os
import subprocess
import traceback
from pathlib import Path
from typing import Any, Set

import bpy
from bpy.types import Context, OperatorProperties
from bpy_extras.io_utils import ExportHelper

from ..libs import neologging
from ..manager.props import EZS_SceneStatesManager, get_scene_state_manager
from ..manager.props.entity import CustomProperty, GlobalCollectionPropertyItem
from ..manager.props.scene_modifiers import SceneModifierPropertyGroup

# import faulthandler
# import tracemalloc

# faulthandler.enable()


def check_if_is_on_camera_view(context: Context) -> bool:
    """Check if the current view is on camera view."""

    for area in bpy.context.screen.areas:
        if not area.type == "VIEW_3D":
            continue
        if area.spaces[0].region_3d.view_perspective == "CAMERA":
            return True

    return False


def create_camera_from_view(context: Context) -> bpy.types.Object:
    """Create a camera from the current view."""

    scene = context.scene
    camera = bpy.data.cameras.new("Camera")
    camera_obj = bpy.data.objects.new("Camera", camera)
    context.collection.objects.link(camera_obj)
    scene.camera = camera_obj

    bpy.ops.view3d.camera_to_view()
    return camera_obj


class EZS_OT_StoreCameraLocRoc(bpy.types.Operator):
    """Store Camera Location and Rotation"""

    bl_idname = "easystates.store_camera_loc_rot"
    bl_label = "Store Camera Location and Rotation"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: Context):
        """Store Camera Location and Rotation"""

        scene_state_manager = get_scene_state_manager(context.scene)
        active_state = scene_state_manager.get_active()
        if not active_state:
            return {"CANCELLED"}

        camera_modifier = active_state.camera_modifier

        camera_modifier.location = camera_modifier.camera.location.copy()
        camera_modifier.rotation = camera_modifier.camera.rotation_euler.copy()

        self.report({"INFO"}, "Camera Location and Rotation Stored.")
        return {"FINISHED"}


class EZS_OT_SceneStatesManager(bpy.types.Operator):
    """Manage Scene States"""

    bl_idname = "easystates.manage"
    bl_label = "Manage Scene State"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items=[
            ("ADD", "Add", "Add a new scene state"),
            ("REMOVE", "Remove", "Remove a scene state"),
            ("UP", "Up", "Move up a scene state"),
            ("DOWN", "Down", "Move down a scene state"),
        ],
        name="Action",
    )  # type:ignore

    _scene_state_manager: EZS_SceneStatesManager

    @classmethod
    def description(
        cls, context: Context, properties: bpy.types.OperatorProperties
    ) -> str:

        if properties.action == "ADD":
            return "Add a new scene state."
        elif properties.action == "REMOVE":
            return "Remove a scene state."
        elif properties.action == "UP":
            return "Move up a scene state."
        elif properties.action == "DOWN":
            return "Move down a scene state."
        else:
            raise ValueError("Invalid action")

    def _add_scene_state(self, context: Context) -> bool:
        """Add a new scene state."""

        selected_cameras = [
            ob for ob in context.selected_objects if ob.type == "CAMERA"
        ]

        if selected_cameras:
            for camera in selected_cameras:
                self._scene_state_manager.add(
                    context.scene,
                    camera=camera,
                )
        else:
            if not check_if_is_on_camera_view(context):
                camera = create_camera_from_view(context)
            else:
                camera = context.scene.camera
            try:
                camera.select_set(True)
            except RuntimeError:
                return False

            context.view_layer.objects.active = camera

            self._scene_state_manager.add(
                context.scene,
                camera=camera,
            )
        return True

    def _remove(self, context: Context) -> None:

        current_idx = self._scene_state_manager.scene_states_index

        if current_idx == (len(self._scene_state_manager.scene_states) - 1):
            self._scene_state_manager.scene_states_index = current_idx - 1
            self._scene_state_manager.remove(current_idx)
            if current_idx > 0:
                self._scene_state_manager.activate_by_idx(
                    context.scene, current_idx - 1
                )
        else:
            self._scene_state_manager.remove(current_idx)
            if current_idx > 0:
                self._scene_state_manager.activate_by_idx(
                    context.scene, current_idx - 1
                )

    def _move_up(self, context: Context) -> bool:
        """Move up a scene state."""

        current_idx = self._scene_state_manager.scene_states_index
        return self._scene_state_manager.move_up(current_idx)

    def _move_down(self, context: Context) -> bool:
        """Move down a scene state."""

        current_idx = self._scene_state_manager.scene_states_index
        return self._scene_state_manager.move_down(current_idx)

    def execute(self, context: Context):

        self._scene_state_manager = get_scene_state_manager(context.scene)

        match self.action:
            case "ADD":
                if not self._add_scene_state(context):
                    self.report(
                        {"ERROR"}, "Failed to create camera scene_state"
                    )
                    return {"CANCELLED"}
            case "REMOVE":
                self._remove(context)
            case "UP":
                if not self._move_up(context):
                    return {"CANCELLED"}
            case "DOWN":
                if not self._move_down(context):
                    return {"CANCELLED"}
            case _:
                raise ValueError("Invalid action")

        self.report({"INFO"}, "FINISHED")
        return {"FINISHED"}


class EZS_OT_DuplicateSceneState(bpy.types.Operator):
    """Duplicate Scene State"""

    bl_idname = "easystates.duplicate_scene_state"
    bl_label = "Duplicate Scene State"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: bpy.types.Context):
        """Add a new collection visibility item."""

        scene_state_manager = get_scene_state_manager(context.scene)
        current_scene_state = scene_state_manager.get_active()
        if not current_scene_state:
            self.report({"ERROR"}, "No Active Scene State found.")
            return {"CANCELLED"}

        scene_state_manager.add(
            context.scene,
            name=current_scene_state.name + " [copy]",
            camera=current_scene_state.camera_modifier.camera,
        )

        self.report({"INFO"}, "Scene State Duplicated.")
        return {"FINISHED"}


class EZS_OT_OpenLastRendered(bpy.types.Operator):
    """Open Last Render From Scene State"""

    bl_idname = "easystates.open_last_render"
    bl_label = "Open Image"
    bl_options = {"REGISTER", "UNDO"}

    scene_state_id: bpy.props.StringProperty()  # type:ignore

    @staticmethod
    def _get_rendered_output_file(output_filepath: Path) -> Path | None:
        """The filepath stored in last_render_path is just the filename without extension.
        since at the time of the render, the extension is not known. This method searches
        for the image file (with extension) with the same name as the output_filepath and returns it.
        """

        image_name = output_filepath.stem
        image_file = None

        for file in Path(output_filepath).parent.iterdir():
            if file.is_dir():
                continue
            if file.stem == image_name:
                image_file = file
                break

        return image_file

    def execute(self, context: bpy.types.Context):
        """Add a new collection visibility item."""

        scene_state_manager = get_scene_state_manager(context.scene)
        scene_state = scene_state_manager.get_by_id(self.scene_state_id)
        if not scene_state:
            self.report({"ERROR"}, "Scene State not found.")
            return {"CANCELLED"}

        if not scene_state.last_render_path:
            self.report({"ERROR"}, "No render path found.")
            return {"CANCELLED"}

        real_image_file = self._get_rendered_output_file(
            Path(scene_state.last_render_path)
        )
        if not real_image_file:
            self.report({"ERROR"}, "Rendered image not found.")
            return {"CANCELLED"}

        os.startfile(real_image_file.absolute().as_posix())
        return {"FINISHED"}


class EZS_OT_AddCollectionVisibility(bpy.types.Operator):
    """Add Collection Visibility Item"""

    bl_idname = "easystates.add_collection_visibility"
    bl_label = "Add Collection Visibility Item"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: bpy.types.Context):
        """Add a new collection visibility item."""

        selected_collection = context.collection
        if not selected_collection:
            self.report({"ERROR"}, "No collection selected.")
            return {"CANCELLED"}

        if selected_collection == context.scene.collection:
            self.report({"ERROR"}, "Invalid Collection")
            return {"CANCELLED"}

        # Update Global Modifier
        scene_state_manager = get_scene_state_manager(context.scene)

        success = scene_state_manager.add_collection_visibility(
            selected_collection
        )
        if not success:
            self.report({"ERROR"}, "Collection already exists.")
            return {"CANCELLED"}

        self.report({"INFO"}, "Collection added.")
        return {"FINISHED"}


class EZS_OT_EZS_OT_AddMaterialSlotsOverwrite(bpy.types.Operator):
    """Add Material Slots Object"""

    bl_idname = "easystates.add_material_slots_overwrite"
    bl_label = "Add Material Slots Object"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: bpy.types.Context):
        """Add a new material slots object."""

        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({"ERROR"}, "No objects selected.")
            return {"CANCELLED"}

        # Update Global Modifier
        scene_state_manager = get_scene_state_manager(context.scene)

        for ob in selected_objects:
            scene_state_manager.add_material_slots_overwrite(ob)

        self.report({"INFO"}, "Objects Added.")
        return {"FINISHED"}


class EZS_OT_AddMaterialSlot(bpy.types.Operator):
    """Add Material Slot"""

    bl_idname = "easystates.add_material_slot"
    bl_label = "Add Material Slot"
    bl_options = {"REGISTER", "UNDO"}

    object_name: bpy.props.StringProperty()  # type:ignore
    material_slot: bpy.props.IntProperty(
        name="Material Slot", default=0
    )  # type:ignore

    def execute(self, context: bpy.types.Context):

        obj = bpy.data.objects.get(self.object_name)
        if not obj:
            self.report({"ERROR"}, "Object not found.")
            return {"CANCELLED"}

        scene_state_manager = get_scene_state_manager(context.scene)
        scene_state_manager.add_material_slot(obj, self.material_slot)

        self.report({"INFO"}, "Materials Added.")
        return {"FINISHED"}


class EZS_OT_UpdateCustomPropertyCategories(bpy.types.Operator):
    """Update Custom Property Categories"""

    bl_idname = "easystates.repair_custom_property_categories"
    bl_label = "Update Custom Property Categories"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def description(
        cls,
        context: bpy.types.Context,
        properties: bpy.types.OperatorProperties,
    ) -> str:
        return (
            "Categories are generated based on custom properties IDs."
            "If, for any reason, you need to change the name of an ID Data"
            "(such as Material, Object, etc.) that has custom properties,"
            "you can run this operator to update the categories, and all names"
            "will be updated accordingly."
        )

    def execute(self, context: bpy.types.Context):
        """Update Custom Property Categories"""

        # Update Global Modifier
        scene_state_manager = get_scene_state_manager(context.scene)
        scene_state_manager.update_custom_property_categories()

        return {"FINISHED"}


def get_valid_id_data(
    id_data: bpy.types.ID, path_from_id: str
) -> tuple[bpy.types.ID | None, str]:
    """Get valid ID Data and path from ID.
    Valid ID Data will persists when the file is saved and reloaded.
    """

    if hasattr(id_data, "bl_idname") and id_data.bl_idname in (
        "ShaderNodeTree",
        "CompositorNodeTree",
    ):

        # If the node tree is a node group, it will be saved and reloaded,
        # so it is valid.
        for node_group in bpy.data.node_groups:
            if node_group == id_data:
                return id_data, path_from_id

        # If is not a node group, than check all data
        # blocks that has node tree.
        has_node_tree = [
            bpy.data.materials,
            bpy.data.worlds,
            bpy.data.scenes,
            bpy.data.lights,
        ]

        valid_id_data = None
        for data_block in has_node_tree:
            for data in data_block:
                if data.node_tree == id_data:
                    valid_id_data = data
                    break

        if not valid_id_data:
            return None, ""

        if valid_id_data:
            path_from_id = "node_tree." + path_from_id
            return valid_id_data, path_from_id

    return id_data, path_from_id


def refactor_node_socket_path(path_from_id: str, socket_name: str) -> str:
    """Refactor the path from ID to include the socket name instead of the index.
    e.g.:
        "node_tree.nodes["Material Output"].inputs[28]"
        to "node_tree.nodes["Material Output"].inputs["Emission Strength"]"
    """
    last_index = path_from_id.rfind("[")
    return path_from_id[: last_index + 1] + f'"{socket_name}"]'


class EZS_OT_AddCustomPropertyContextMenu(bpy.types.Operator):
    """Add Custom Property from Context Menu"""

    bl_idname = "easystates.add_custom_property_context_menu"
    bl_label = "EasyStates: Add Custom Property"
    bl_options = {"REGISTER", "UNDO"}

    @classmethod
    def poll(cls, context: Context) -> bool:

        try:
            b_pointer = context.button_pointer
        except AttributeError:
            return False

        if isinstance(b_pointer, GlobalCollectionPropertyItem):
            return False
        if isinstance(b_pointer, SceneModifierPropertyGroup):
            return False

        return True

    def execute(self, context: Context):

        try:
            id_data: bpy.types.ID = context.button_pointer.id_data
        except AttributeError:
            self.report({"ERROR"}, "Property not supported.")
            return {"CANCELLED"}

        try:
            path_from_id: str = context.button_pointer.path_from_id()
        except ValueError:
            path_from_id = ""

        identifier: str = context.button_prop.identifier

        valid_id_data, valid_path_from_id = get_valid_id_data(
            id_data, path_from_id
        )

        if not valid_id_data:
            self.report({"ERROR"}, "Cannot find valid ID Data.")
            return {"CANCELLED"}

        # Since new sockets can be added or removed between Blender versions,
        # it is better to use the socket name instead of the socket index in the
        # path_from_id. The socket name can be changed between Blender Versions,
        # but is less likely to change than the index.
        if valid_path_from_id:
            _prop_data = valid_id_data.path_resolve(valid_path_from_id)
        else:
            _prop_data = valid_id_data
        if isinstance(_prop_data, bpy.types.NodeSocket):
            valid_path_from_id = refactor_node_socket_path(
                valid_path_from_id, _prop_data.name
            )

        scene_state_manager = get_scene_state_manager(context.scene)
        success = scene_state_manager.add_custom_property(
            valid_id_data, valid_path_from_id, identifier
        )
        if not success:
            self.report({"ERROR"}, "Custom property could not be added")
            return {"CANCELLED"}

        self.report({"INFO"}, "Custom Propert Added.")
        return {"FINISHED"}


class EZS_OT_UpdateNodeSocketsCPPathFormat(bpy.types.Operator):
    """Update Node Sockets Custom Properties Path Format
    (Only accessed from the Operator Search Menu)
    """

    bl_idname = "easystates.update_node_sockets_cp_path_format"
    bl_label = "Update Node Sockets Custom Properties Path Format"
    bl_description = "Update the path format of custom properties that are linked to node sockets."
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: Context):
        """Update Custom Properties Path Format"""

        scene_state_manager = get_scene_state_manager(context.scene)
        global_properties = scene_state_manager.global_properties

        changed = 0
        for (
            global_custom_property
        ) in global_properties.custom_properties_modifier.global_items:
            prop_data = global_custom_property.get_bl_data()
            old_path_from_id = global_custom_property.path_from_id
            if isinstance(prop_data, bpy.types.NodeSocket):
                global_custom_property.path_from_id = (
                    refactor_node_socket_path(
                        global_custom_property.path_from_id, prop_data.name
                    )
                )
            if old_path_from_id != global_custom_property.path_from_id:
                for state_set in scene_state_manager.get_all():
                    for (
                        ss_custom_property
                    ) in (
                        state_set.custom_properties_modifier.custom_properties
                    ):
                        if (
                            ss_custom_property.global_id
                            == global_custom_property.global_id
                        ):
                            ss_custom_property.path_from_id = (
                                global_custom_property.path_from_id
                            )
                neologging.info(
                    f"Updated Global Custom Property, Old Path: {old_path_from_id} New Path: {global_custom_property.path_from_id}"
                )
                changed += 1

        self.report({"INFO"}, f"Updated {changed} Custom Properties.")
        return {"FINISHED"}


class EZS_OT_RepairCustomPropertyContextMenu(bpy.types.Operator):
    """Repair Custom Property from Context Menu"""

    bl_idname = "easystates.repair_custom_property_context_menu"
    bl_label = "EasyStates: Repair Custom Property"
    bl_options = {"REGISTER", "UNDO"}

    selected_custom_property: CustomProperty

    @classmethod
    def poll(cls, context: Context) -> bool:

        try:
            b_pointer = context.button_pointer
        except AttributeError:
            return False

        if isinstance(b_pointer, GlobalCollectionPropertyItem):
            return False
        if isinstance(b_pointer, SceneModifierPropertyGroup):
            return False

        return True

    def invoke(self, context: Context, event: bpy.types.Event):

        scene_state_manager = get_scene_state_manager(context.scene)
        selected_custom_property = (
            scene_state_manager.get_selected_custom_property()
        )
        if not selected_custom_property:
            self.report({"ERROR"}, "Custom property not selected")
            return {"CANCELLED"}

        if not (
            selected_custom_property.invalid_path,
            selected_custom_property.invalid_value,
            selected_custom_property.invalid_identifier,
        ):
            self.report(
                {"WARNING"},
                "Selected custom property is valid, no need to repair.",
            )
            return {"CANCELLED"}

        self.selected_custom_property = selected_custom_property
        return self.execute(context)

    def execute(self, context: Context):

        try:
            id_data: bpy.types.ID = context.button_pointer.id_data
        except AttributeError:
            self.report({"ERROR"}, "Property not supported.")
            return {"CANCELLED"}

        try:
            path_from_id: str = context.button_pointer.path_from_id()
        except ValueError:
            path_from_id = ""

        identifier: str = context.button_prop.identifier

        valid_id_data, valid_path_from_id = get_valid_id_data(
            id_data, path_from_id
        )
        if not valid_id_data or not valid_path_from_id:
            self.report({"ERROR"}, "Property not supported.")
            return {"CANCELLED"}

        scene_state_manager = get_scene_state_manager(context.scene)
        global_id = self.selected_custom_property.global_id

        success = scene_state_manager.repair_custom_property(
            global_id, valid_id_data, valid_path_from_id, identifier
        )
        if not success:
            self.report({"ERROR"}, "Custom property could not be added")
            return {"CANCELLED"}

        self.report({"INFO"}, "Custom Propert Added.")
        return {"FINISHED"}

class EZS_OT_SceneStatesSelection(bpy.types.Operator):
    """Select Scene States"""

    bl_idname = "easystates.scene_states_selection"
    bl_label = "EasyStates: Select Scene States"
    bl_options = {"REGISTER", "UNDO"}

    action : bpy.props.EnumProperty(
        items=[
            ("SELECT", "Select", "Select scene states"),
            ("DESELECT", "Deselect", "Deselect scene states"),
            ("INVERT", "Invert", "Invert selection"),
        ],
        name="Action",
    )  # type:ignore
    
    @classmethod
    def description(cls, context: Context, properties: OperatorProperties) -> str:
        if properties.action == "SELECT":
            return "Select all scene states."
        elif properties.action == "DESELECT":
            return "Deselect all scene states."
        elif properties.action == "INVERT":
            return "Invert selection of scene states."
        else:
            raise ValueError("Invalid action")

    def execute(self, context: Context):

        scene_state_manager = get_scene_state_manager(context.scene)
        scene_states = scene_state_manager.get_all()

        if self.action == "SELECT":
            for scene_state in scene_states:
                scene_state.selected = True
        elif self.action == "DESELECT":
            for scene_state in scene_states:
                scene_state.selected = False
        elif self.action == "INVERT":
            for scene_state in scene_states:
                scene_state.selected = not scene_state.selected
        else:
            return {"CANCELLED"}

        self.report({"INFO"}, "Scene States Selected.")
        return {"FINISHED"}


class EZS_OT_ApplyToSceneStates(bpy.types.Operator):
    """Apply Modifier Property Value to All Scene State"""

    bl_idname = "easystates.apply_to_scene_states"
    bl_label = "EasyStates: Apply To All Scene States"
    bl_options = {"REGISTER", "UNDO"}

    apply_to_selected: bpy.props.BoolProperty(
        name="Apply To Selected",
        description="Apply to selected scene states only.",
        default=False,
    )  # type:ignore
    
    _applied_to : int = 0
    """Total Scene States Applied"""
    _failed_to_apply : int = 0
    """Total Scene States Failed to Apply"""
    
    @classmethod
    def poll(cls, context: Context) -> bool:

        try:
            # NOTE: Should be called from context menu, otherwise it will not work.
            b_pointer = context.button_pointer
        except AttributeError:
            return False

        # Check if the selected property is a valid scene state propery
        if isinstance(b_pointer, GlobalCollectionPropertyItem):
            return True
        if isinstance(b_pointer, SceneModifierPropertyGroup):
            return True

        return False

    def _apply_scene_state_property_group(
        self,
        context: Context,
        b_pointer: SceneModifierPropertyGroup,
        identifier: str,
        source_value: Any,
    ):
        """Get all instances of the scene state and apply the value"""
        
        self._applied_to = 0
        self._failed_to_apply = 0

        for scene_state in get_scene_state_manager(context.scene).get_all():
            if self.apply_to_selected and not scene_state.selected:
                continue

            modifier = scene_state.get_modifier_by_type(type(b_pointer))
            if modifier:
                modifier.block_update = True
                try:
                    setattr(modifier, identifier, source_value)
                    self._applied_to += 1
                except Exception as e:  # pylint: disable=broad-except
                    neologging.exception(traceback.format_exc())
                    neologging.error(f"Error setting attribute: {e}")
                    self._failed_to_apply += 1
                finally:
                    modifier.block_update = False

    def _apply_global_collection_item(
        self,
        context: Context,
        b_pointer: GlobalCollectionPropertyItem,
        identifier: str,
        source_value: Any,
    ):
        """Get all instances of the global collection item and apply the value
        for every instance of the same ID."""
        
        self._applied_to = 0
        self._failed_to_apply = 0

        scene_state_manager = get_scene_state_manager(context.scene)
        
        for scene_state in get_scene_state_manager(context.scene).get_all():            
            if self.apply_to_selected and not scene_state.selected:
                continue
            for (
                global_col_item
            ) in scene_state_manager.get_all_global_collection_property_items(scene_state.id):                
                if not global_col_item.global_id == b_pointer.global_id:
                    continue
                global_col_item.block_update = True
                try:
                    setattr(global_col_item, identifier, source_value)
                    self._applied_to += 1
                except Exception as e:  # pylint: disable=broad-except
                    neologging.exception(traceback.format_exc())
                    neologging.error(f"Error setting attribute: {e}")
                    self._failed_to_apply += 1
                finally:
                    global_col_item.block_update = False

    def execute(self, context: Context):

        identifier: str = context.button_prop.identifier
        b_pointer = context.button_pointer

        if not b_pointer:
            return {"CANCELLED"}
        if not identifier:
            return {"CANCELLED"}

        source_value = getattr(b_pointer, identifier)

        if isinstance(b_pointer, SceneModifierPropertyGroup):
            self._apply_scene_state_property_group(
                context, b_pointer, identifier, source_value
            )
        elif isinstance(b_pointer, GlobalCollectionPropertyItem):
            self._apply_global_collection_item(
                context, b_pointer, identifier, source_value
            )
        else:
            return {"CANCELLED"}
        
        if self._failed_to_apply:
            if not self._applied_to:
                self.report(
                    {"WARNING"},
                    f"Failed to apply to all Scene States. ({self._failed_to_apply} failed)",
                )
                return {"CANCELLED"}
            self.report(
                {"WARNING"},
                f"Applied to {self._applied_to} Scene States. ({self._failed_to_apply} failed)",
            )
            return {"FINISHED"}

        self.report({"INFO"}, f"Property Applied to {self._applied_to} Scene States.")
        return {"FINISHED"}


class EZS_OT_RemoveGlobalCollectionPropertyItem(bpy.types.Operator):
    """Remove Global Collection Property Item"""

    bl_idname = "easystates.remove_global_collection_property_item"
    bl_label = "Remove Global Collection Property Item"
    bl_options = {"REGISTER", "UNDO"}

    global_id: bpy.props.StringProperty()  # type:ignore

    def execute(self, context: bpy.types.Context):
        """Remove a collection visibility item."""

        scene_state_manager = get_scene_state_manager(context.scene)
        scene_state_manager.remove_global_id(self.global_id)
        return {"FINISHED"}


class EZS_OT_AddObjectVisibility(bpy.types.Operator):
    """Add Object Visibility Item"""

    bl_idname = "easystates.add_object_visibility"
    bl_label = "Add Object Visibility Item"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: bpy.types.Context):
        """Add a new collection visibility item."""

        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({"ERROR"}, "No objects selected.")
            return {"CANCELLED"}

        # Update Global Modifier
        scene_state_manager = get_scene_state_manager(context.scene)

        for ob in selected_objects:
            scene_state_manager.add_object_visibility(
                ob, ob.hide_viewport, ob.hide_render
            )

        self.report({"INFO"}, "Objects Added.")
        return {"FINISHED"}


class EZS_OT_AddObjectAction(bpy.types.Operator):
    """Add Object Action Item"""

    bl_idname = "easystates.add_object_action"
    bl_label = "Add Object Action Item"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: bpy.types.Context):
        """Add a new pbject action item."""

        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({"ERROR"}, "No objects selected.")
            return {"CANCELLED"}

        # Update Global Modifier
        scene_state_manager = get_scene_state_manager(context.scene)

        for ob in selected_objects:
            ob_action = None
            if not ob.animation_data or not ob.animation_data.action:
                ob_action = None
            else:
                ob_action = ob.animation_data.action

            scene_state_manager.add_object_action(ob, ob_action)

        self.report({"INFO"}, "Objects Added.")
        return {"FINISHED"}


class EZS_OT_AddObjectTransform(bpy.types.Operator):
    """Add Object Transform Item"""

    bl_idname = "easystates.add_object_transform"
    bl_label = "Add Object Transform Item"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: bpy.types.Context):
        """Add a new pbject action item."""

        selected_objects = context.selected_objects
        if not selected_objects:
            self.report({"ERROR"}, "No objects selected.")
            return {"CANCELLED"}

        # Update Global Modifier
        scene_state_manager = get_scene_state_manager(context.scene)

        for ob in selected_objects:
            scene_state_manager.add_object_transform(
                ob, ob.location, ob.rotation_euler, ob.scale  # type:ignore
            )

        self.report({"INFO"}, "Objects Added.")
        return {"FINISHED"}


class EZS_OT_ToggleObjectVisibilityUIList(bpy.types.Operator):
    """Toggle Object Visibility UI List"""

    bl_idname = "easystates.toggle_object_visibility_ui_list"
    bl_label = "Toggle Object Visibility UI List"
    bl_options = {"REGISTER", "UNDO"}

    action: bpy.props.EnumProperty(
        items=[
            ("HIDE_SELECT", "Hide Select", "Hide Select"),
            ("HIDE_SET", "Hide Set", "Hide Set"),
            ("HIDE_VIEWPORT", "Hide Viewport", "Hide Viewport"),
            ("HIDE_RENDER", "Hide Render", "Hide Render"),
        ],
        name="Action",
    )  # type:ignore

    def execute(self, context: Context):
        # Update Global Modifier

        scene_state_manager = get_scene_state_manager(context.scene)
        active_scene_state = scene_state_manager.get_active()
        if not active_scene_state:
            return {"CANCELLED"}

        global_properties = scene_state_manager.global_properties
        obj_viz_global_props = global_properties.objects_visibility_modifier

        for (
            obj
        ) in active_scene_state.objects_visibility_modifier.objects_visibility:
            if obj_viz_global_props.sync_selection:
                if not obj.object in context.selected_objects:
                    continue

            if (
                self.action == "HIDE_SELECT"
                and obj_viz_global_props.use_hide_select
            ):
                obj.hide_select = not obj.hide_select
            elif (
                self.action == "HIDE_SET" and obj_viz_global_props.use_hide_set
            ):
                obj.hide_set = not obj.hide_set
            elif (
                self.action == "HIDE_VIEWPORT"
                and obj_viz_global_props.use_hide_viewport
            ):
                obj.hide_viewport = not obj.hide_viewport
            elif (
                self.action == "HIDE_RENDER"
                and obj_viz_global_props.use_hide_render
            ):
                obj.hide_render = not obj.hide_render

        return {"FINISHED"}


class EZS_OT_UpdateRenderRegion(bpy.types.Operator):
    """Save Current Render Region"""

    bl_idname = "easystates.update_scene_state_render_border"
    bl_label = "Update Scene State Render Region"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: Context):

        active_scene_state = get_scene_state_manager(
            context.scene
        ).get_active()
        if not active_scene_state:
            return {"CANCELLED"}

        render_region_modifier = active_scene_state.render_region_modifier
        render_region_modifier.border_min_x = context.scene.render.border_min_x
        render_region_modifier.border_min_y = context.scene.render.border_min_y
        render_region_modifier.border_max_x = context.scene.render.border_max_x
        render_region_modifier.border_max_y = context.scene.render.border_max_y

        return {"FINISHED"}


class EZS_OT_CleanUpEasyStates(bpy.types.Operator):
    """Keep current scene state and remove all others."""

    bl_idname = "easystates.clean_up"
    bl_label = "Clean Up EasyStates Data"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: Context):

        scene_state_manager = get_scene_state_manager(context.scene)

        # Clear up all scene state data
        for scene_state in scene_state_manager.get_all():
            scene_state.clear()

        # Remove all scene states
        scene_state_manager.clear()

        # Clear up all global properties
        global_properties = scene_state_manager.global_properties
        global_properties.clear()

        self.report({"INFO"}, "EasyStates Data Cleaned Up.")
        return {"FINISHED"}


class EZS_UL_ExportSceneStates(bpy.types.UIList):
    """Scene State List UI."""

    def draw_item(  # type:ignore
        self,
        context: Context,
        layout: bpy.types.UILayout,
        data: bpy.types.PropertyGroup,
        item: bpy.types.PropertyGroup,
        icon: int,
        active_data: bpy.types.PropertyGroup,
        active_propname: str,
        index: int,
    ):  # pylint: disable=arguments-differ

        col = layout.column(align=True)
        col.prop(
            item,
            "export",
            text="",
            # icon=(
            #     "RESTRICT_RENDER_OFF" if item.render else "RESTRICT_RENDER_ON"
            # ),
            # emboss=False,
            # translate=False,
        )

        col = layout.column(align=True)
        col.prop(
            item,
            "name",
            text="",
            emboss=False,
            translate=False,
        )


class EZS_OT_ExportSceneStates(  # type:ignore
    bpy.types.Operator, ExportHelper
):
    """Save each scene state to a different .blend file in
    the specified directory."""

    bl_idname = "easystates.export_scene_states"
    bl_label = "EasyStates Scene States (.blend)"
    bl_options = {"REGISTER", "UNDO"}

    # ExportHelper mix-in class uses this.
    # filename : bpy.props.StringProperty(subtype="DIR_PATH", default = "ola")  # type:ignore
    filepath = bpy.props.StringProperty(
        name="File Path",
        description="Filepath used for exporting the file",
        maxlen=1024,
        subtype="FILE_PATH",
    )
    # ...
    # subclasses can override with decorator
    # True == use ext, False == no ext, None == do nothing.
    check_extension = False

    export_list_index: bpy.props.IntProperty(
        name="Export List Index",
        default=0,
    )  # type:ignore

    overwrite_existing: bpy.props.BoolProperty(
        name="Overwrite Existing",
        description="Skip existing files and do not overwrite them.",
        default=True,
    )  # type:ignore

    clean_up_exported: bpy.props.BoolProperty(
        name="Clean Up Exported",
        description=(
            "This process launches a new background instance of Blender "
            "for each exported file and executes the EasyStates cleanup operator. "
            "It removes all scene states and global properties, leaving only the "
            "active scene state of the exported file."
        ),
        default=True,
    )  # type:ignore

    clean_up_factory_startup: bpy.props.BoolProperty(
        name="Factory Startup Mode",
        default=True,
        description=(
            "This option enables the --factory-startup flag to speed up the cleanup process, "
            "but it disables all add-ons except EasyStates. "
            "In most cases, this is the best option. However, if you have another add-on "
            "that needs to be enabled during this process, you can disable this option."
        ),
    )  # type:ignore

    def draw(self, context: Context):
        layout = self.layout

        col = layout.column(align=True)
        box = col.box()
        box.label(text="Export Options:")
        box = col.box()
        row = box.row(align=True)
        row.prop(self, "overwrite_existing")
        row = box.row(align=True)
        row.prop(self, "clean_up_exported")
        if self.clean_up_exported:
            row = box.row(align=True)
            row.label(text="", icon="BLANK1")
            row.prop(self, "clean_up_factory_startup")

        # Draw all scene states
        scene_state_manager = get_scene_state_manager(context.scene)

        col = layout.column(align=True)
        box = col.box()
        box.label(text="Export Scene States:")

        col_ul = col.column(align=True)
        col_ul.template_list(
            "EZS_UL_ExportSceneStates",
            "",
            scene_state_manager,
            "scene_states",
            self,
            "export_list_index",
            rows=12,
        )

    def invoke(self, context, event):  # type:ignore
        self.filepath = ""
        context.window_manager.fileselect_add(self)
        return {"RUNNING_MODAL"}

    def _save_each_scene_state(
        self, context: Context, output_dir: Path, overwrite_existing: bool
    ) -> list[Path]:

        scene_state_manager = get_scene_state_manager(context.scene)
        global_properties = scene_state_manager.global_properties
        scene_states = scene_state_manager.get_all()

        saved_files = []
        for scene_state in scene_states:
            if not scene_state.export:
                continue

            scene_state_name = scene_state.name
            scene_state_file = output_dir / f"{scene_state_name}.blend"
            scene_state_file = scene_state_file.resolve()

            if not overwrite_existing and scene_state_file.exists():
                neologging.info(f"Skipping: {scene_state_file}")
                continue

            scene_state.apply(context.scene, global_properties)

            neologging.info(f"Saving: {scene_state_file}")
            bpy.ops.wm.save_as_mainfile(
                filepath=scene_state_file.as_posix(),
                check_existing=False,
                copy=True,
            )

            if self.clean_up_exported:
                neologging.info(f"Cleaning up: {scene_state_file}")
                self._clean_up_exported_file(
                    scene_state_file, self.clean_up_factory_startup
                )

            saved_files.append(scene_state_file)

        return saved_files

    def _clean_up_exported_file(self, file_path: Path, factory_startup: bool):
        """Using a subprocess to open the file and run the clean up operator."""

        addon_module = "easystates"
        python_expr_parts = [
            "import bpy;",
        ]
        # Enable EasyStates only if factory_startup is True
        # since it will not be enabled by default in the factory startup
        if factory_startup:
            python_expr_parts.append(
                f"bpy.ops.preferences.addon_enable(module='{addon_module}');"
            )
        python_expr_parts.extend(
            [
                "bpy.ops.easystates.clean_up();",
                "bpy.ops.wm.save_as_mainfile();",
            ]
        )
        python_expr = "".join(python_expr_parts)

        cmd = f'"{bpy.app.binary_path}" -b "{file_path.as_posix()}" {"--factory-startup" if factory_startup else ""} --python-expr "{python_expr}"'

        neologging.debug(cmd)
        subprocess.run(cmd, shell=True, check=True)

    def execute(self, context):

        # Make sure self.filepath is dir
        output_dir = Path(self.filepath)  # type:ignore
        if not output_dir.is_dir():
            output_dir = output_dir.parent

        saved_files = self._save_each_scene_state(
            context, output_dir, self.overwrite_existing
        )

        if not saved_files:
            self.report({"WARNING"}, "No files exported.")
            return {"CANCELLED"}

        self.report({"INFO"}, f"Exported {len(saved_files)} files.")
        return {"FINISHED"}


classes = (
    EZS_OT_CleanUpEasyStates,
    EZS_OT_SceneStatesSelection,
    EZS_UL_ExportSceneStates,
    EZS_OT_ExportSceneStates,
    EZS_OT_AddObjectAction,
    EZS_OT_AddCollectionVisibility,
    EZS_OT_StoreCameraLocRoc,
    EZS_OT_RepairCustomPropertyContextMenu,
    EZS_OT_UpdateRenderRegion,
    EZS_OT_ToggleObjectVisibilityUIList,
    EZS_OT_AddObjectVisibility,
    EZS_OT_AddObjectTransform,
    EZS_OT_EZS_OT_AddMaterialSlotsOverwrite,
    EZS_OT_AddMaterialSlot,
    EZS_OT_OpenLastRendered,
    EZS_OT_RemoveGlobalCollectionPropertyItem,
    EZS_OT_UpdateCustomPropertyCategories,
    EZS_OT_AddCustomPropertyContextMenu,
    EZS_OT_SceneStatesManager,
    EZS_OT_DuplicateSceneState,
    EZS_OT_ApplyToSceneStates,
    EZS_OT_UpdateNodeSocketsCPPathFormat,
)


def register():
    """Register operators."""

    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)


def unregister():
    """Unregister operators."""

    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
