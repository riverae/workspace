# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####


import traceback
from pathlib import Path
from typing import Any

import bpy
from bpy.types import Context, Scene

from ...constants import RENDER_ENGINES_KEY
from ...libs import neologging
from ...utils import check_blender_version
from .entity import (
    CollectionVisibility,
    CustomProperty,
    MaterialSlotsOverwrite,
    ObjectAction,
    ObjectTransform,
    ObjectVisibility,
)
from .global_properties import GlobalSceneStateProperties, SceneModifierGlobalProps
from .utils import get_viewlayer_collection


def recursive_copy_property_group(
    source: bpy.types.PropertyGroup, target: bpy.types.PropertyGroup
):
    """Copy properties from one property group to another. It also automatically
    block updates if the target property group has a block_update attribute."""

    for annotation in source.__annotations__:
        attr = getattr(source, annotation)

        if isinstance(attr, bpy.types.bpy_prop_collection):

            for item in attr:
                new_item = getattr(target, annotation).add()
                recursive_copy_property_group(item, new_item)
        else:
            if hasattr(target, "block_update"):
                target.block_update = True
            try:
                setattr(target, annotation, getattr(source, annotation))
            except Exception as e:  # pylint: disable=broad-except
                neologging.exception(traceback.format_exc())
                neologging.error(f"Error copying property {annotation}: {e}")
            finally:
                if hasattr(target, "block_update"):
                    target.block_update = False


def recursive_get_property_group_values(
    source: bpy.types.PropertyGroup,
) -> dict[str, Any]:
    """Get all properties from a property group and its children."""

    properties = {}

    for annotation in source.__annotations__:
        attr = getattr(source, annotation)
        if isinstance(attr, bpy.types.bpy_prop_collection):
            properties[annotation] = []
            for item in attr:
                properties[annotation].append(
                    recursive_get_property_group_values(item)
                )
        elif isinstance(attr, bpy.types.bpy_prop_array):
            properties[annotation] = list(getattr(source, annotation))
        else:
            properties[annotation] = getattr(source, annotation)

    return properties


class SceneModifierPropertyGroup(bpy.types.PropertyGroup):
    """Base class for scene_state property groups."""

    global_props_name: bpy.props.StringProperty(
        default="global_scene_state_properties"
    )  # type:ignore
    block_update: bpy.props.BoolProperty(default=False)  # type:ignore

    def _global_props(
        self, global_properties: GlobalSceneStateProperties
    ) -> SceneModifierGlobalProps:
        return getattr(global_properties, self.global_props_name)

    def _get_global_attr(
        self, global_properties: GlobalSceneStateProperties, attr: str
    ):
        return getattr(self._global_props(global_properties), attr)

    def get_values(self) -> dict[str, Any]:
        """Get all properties from a property group and its children."""
        return recursive_get_property_group_values(self)

    def enabled(self, global_properties: GlobalSceneStateProperties) -> bool:
        """Check if scene_state property group is enabled."""
        return self._get_global_attr(global_properties, "enabled")

    def expand(self, global_properties: GlobalSceneStateProperties) -> bool:
        """Check if scene_state property group is expanded."""
        return self._get_global_attr(global_properties, "expand")

    def modifier_name(
        self, global_properties: GlobalSceneStateProperties
    ) -> str:
        """Return the name of the scene_state property group."""
        return self._get_global_attr(global_properties, "modifier_name")

    def icon(self, global_properties: GlobalSceneStateProperties) -> str:
        """Return the icon of the scene_state property group."""
        return self._get_global_attr(global_properties, "icon")

    def apply(
        self, scene: Scene, global_properties: GlobalSceneStateProperties
    ):
        """Apply scene_state."""
        if not self.enabled(global_properties):
            return
        self._apply(scene)

    def clear(self):
        """Clear scene_state modifier."""
        self._clear()

    def draw_header(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw header of the scene_state properties."""
        return

    def draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw scene_state properties."""

        if not self.enabled(global_properties):
            return

        box = layout.box()

        row = box.row(align=True)
        row.scale_y = 1.2
        row.scale_x = 1.2

        row.separator()

        row.label(
            text=self.modifier_name(global_properties),
            icon=self.icon(global_properties),
        )

        if self.expand(global_properties):
            self.draw_header(context, row, global_properties)
            row.separator()

        row.prop(
            self._global_props(global_properties),
            "expand",
            text="",
            emboss=False,
            icon=(
                "TRIA_DOWN" if self.expand(global_properties) else "TRIA_RIGHT"
            ),
        )

        if self.expand(global_properties):
            col = box.column(align=True)
            col.enabled = self.enabled(global_properties)

            box = col.box()
            self._draw(context, box, global_properties)

    def copy_from(self, other: "SceneModifierPropertyGroup") -> None:
        """Copy properties from another scene_state."""

        # NOTE: Currently this is not used, but it may be useful in the future.
        # It was originally used to copy scene state properties from one scene state to another.
        # specifically when duplicating a scene state. But for now, it's not necessary since
        # when creating a new scene state, all properties from the current active scene state are copied
        # on the creation.

        # The copy method changed due to some stack overflow issues when copying properties that
        # was never solved. So, the copy method was changed to a recursive method that copies all properties
        raise NotImplementedError
        recursive_copy_property_group(other, self)

    def load_scene_values(
        self,
        scene: Scene,
        global_properties: GlobalSceneStateProperties,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> int:
        """Load default values.

        Returns:
            Int: Number of values that were different from the original values.
        """

        if not self.enabled(global_properties):
            return 0

        original_values = self.get_values()

        self.block_update = True
        self._load_scene_values(
            scene, current_scene_state, create_global_items
        )
        self.block_update = False

        new_values = self.get_values()

        difference_values = {}

        for key, value in original_values.items():
            if value != new_values[key]:
                # neologging.info(
                #     f"[{self.modifier_name(global_properties)} Modifier][{key}][{value} > {new_values[key]}]"
                # )
                difference_values[key] = value

        if difference_values:
            neologging.info(
                f"Changes on {self.modifier_name(global_properties)} Modifier - Total: {len(difference_values)}"
            )
            for key, value in difference_values.items():
                neologging.info(f"{key}: {value}", indent=1)

        return len(difference_values)

    def _apply(self, scene: Scene) -> None:
        """Apply scene_state."""
        raise NotImplementedError

    def _clear(self) -> None:
        """Clear scene_state."""
        raise NotImplementedError

    def _apply_update(self, scene: Scene) -> None:

        if self.block_update:
            return
        self._apply(scene)

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ) -> None:
        """Draw scene_state properties."""
        raise NotImplementedError

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load values from dictionary."""
        raise NotImplementedError


class CameraModifier(SceneModifierPropertyGroup):
    """Camera Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="camera_modifier"
    )  # type:ignore

    camera: bpy.props.PointerProperty(
        type=bpy.types.Object,
        name="Camera",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
        poll=lambda _, object: object.type == "CAMERA",  # type:ignore
    )  # type:ignore

    store_camera_loc_rot: bpy.props.BoolProperty(
        default=False,
        name="Store Location and Rotation",
        description="Store the camera location and rotation",
    )  # type:ignore

    location: bpy.props.FloatVectorProperty(
        name="Stored Location",
        size=3,
        default=(0, 0, 0),
    )  # type:ignore

    rotation: bpy.props.FloatVectorProperty(
        name="Stored Rotation",
        size=3,
        default=(0, 0, 0),
    )  # type:ignore

    type: bpy.props.EnumProperty(
        items=[
            ("PERSP", "Perspective", ""),
            ("ORTHO", "Orthographic", ""),
            ("PANO", "Panoramic", ""),
        ],
        name="Type",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    lens: bpy.props.FloatProperty(
        default=50.0,
        name="Lens",
        subtype="DISTANCE_CAMERA",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    angle: bpy.props.FloatProperty(
        default=50.0,
        name="Field of View",
        precision=3,
        subtype="ANGLE",
        min=0,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    lens_unit: bpy.props.EnumProperty(
        items=[
            ("MILLIMETERS", "Millimeters", ""),
            ("FOV", "Field of View", ""),
        ],
        name="Lens Unit",
        default="MILLIMETERS",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    shift_x: bpy.props.FloatProperty(
        default=0.0,
        name="Shift X",
        min=-2,
        max=2,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    shift_y: bpy.props.FloatProperty(
        default=0.0,
        name="Shift Y",
        min=-2,
        max=2,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    clip_start: bpy.props.FloatProperty(
        default=0.1,
        name="Clip Start",
        min=0.0,
        subtype="DISTANCE",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    clip_end: bpy.props.FloatProperty(
        default=1000.0,
        name="Clip End",
        min=0.0,
        subtype="DISTANCE",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw camera modifier properties"""

        layout.use_property_decorate = False
        layout.use_property_split = True

        layout.prop(self, "camera", text="Camera")
        layout.prop(self, "type")

        if self.lens_unit == "MILLIMETERS":
            layout.prop(self, "lens")
        else:
            layout.prop(self, "angle")

        layout.prop(self, "lens_unit")
        col = layout.column(align=True)
        col.prop(self, "shift_x")
        col.prop(self, "shift_y")
        col = layout.column(align=True)
        layout.prop(self, "clip_start")
        layout.prop(self, "clip_end")

        box = layout.box()
        box.use_property_decorate = False
        box.use_property_split = False

        row = box.row(align=True)
        row.prop(self, "store_camera_loc_rot")
        row.operator(
            "easystates.store_camera_loc_rot",
            text="",
            icon="IMPORT",
        )

    def _apply(self, scene: Scene) -> None:
        """Update camera."""

        if not self.camera:
            neologging.error("Scene state camera is not set.")
            return

        scene.camera = self.camera
        self.camera.data.type = self.type
        self.camera.data.lens_unit = self.lens_unit

        if self.lens_unit == "MILLIMETERS":
            self.camera.data.lens = self.lens
        else:
            self.camera.data.angle = self.angle

        self.camera.data.shift_x = self.shift_x
        self.camera.data.shift_y = self.shift_y
        self.camera.data.clip_start = self.clip_start
        self.camera.data.clip_end = self.clip_end

        if self.store_camera_loc_rot:
            self.camera.location = self.location
            self.camera.rotation_euler = self.rotation

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values."""

        if self.camera:
            camera_data = self.camera.data
        else:
            neologging.warning(
                "Cannot load default values for scene state camera"
            )
            if scene.camera:
                camera_data = scene.camera.data
            else:
                neologging.error("No camera found in scene.")
                return

        self.type = camera_data.type
        self.lens = camera_data.lens
        self.angle = camera_data.angle
        self.lens_unit = camera_data.lens_unit
        self.shift_x = camera_data.shift_x
        self.shift_y = camera_data.shift_y
        self.clip_start = camera_data.clip_start
        self.clip_end = camera_data.clip_end

        self.location = self.camera.location.copy()
        self.rotation = self.camera.rotation_euler.copy()

    def _clear(self) -> None:
        return


class WorldModifier(SceneModifierPropertyGroup):
    """Camera Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="world_modifier"
    )  # type:ignore

    world: bpy.props.PointerProperty(
        type=bpy.types.World,
        name="World",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw world modifier properties"""
        layout.prop(self, "world", text="World")

    def _apply(self, scene: Scene) -> None:
        """Update world modifier"""
        scene.world = self.world

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        self.world = scene.world

    def _clear(self) -> None:
        return


class ResolutionModifier(SceneModifierPropertyGroup):
    """Resolution Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="resolution_modifier"
    )  # type:ignore

    resolution_x: bpy.props.IntProperty(
        default=1920,
        name="Resolution X",
        subtype="PIXEL",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore
    resolution_y: bpy.props.IntProperty(
        default=1080,
        name="Y",
        min=1,
        subtype="PIXEL",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore
    resolution_percentage: bpy.props.IntProperty(
        default=100,
        name="%",
        min=1,
        max=200,
        subtype="PERCENTAGE",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    pixel_aspect_x: bpy.props.FloatProperty(
        default=1,
        name="Aspect X",
        precision=3,
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore
    pixel_aspect_y: bpy.props.FloatProperty(
        default=1,
        name="Y",
        precision=3,
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw output modifier properties"""

        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=True)
        col.prop(self, "resolution_x")
        col.prop(self, "resolution_y")
        col.prop(self, "resolution_percentage", slider=True)

        col = layout.column(align=True)
        col.prop(self, "pixel_aspect_x")
        col.prop(self, "pixel_aspect_y")

    def _apply(self, scene: Scene) -> None:
        """Update output modifier"""

        scene.render.resolution_x = self.resolution_x
        scene.render.resolution_y = self.resolution_y
        scene.render.resolution_percentage = self.resolution_percentage
        scene.render.pixel_aspect_x = self.pixel_aspect_x
        scene.render.pixel_aspect_y = self.pixel_aspect_y

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:

        self.resolution_x = scene.render.resolution_x
        self.resolution_y = scene.render.resolution_y
        self.resolution_percentage = scene.render.resolution_percentage
        self.pixel_aspect_x = scene.render.pixel_aspect_x
        self.pixel_aspect_y = scene.render.pixel_aspect_y

    def _clear(self) -> None:
        return


class OutputModifier(SceneModifierPropertyGroup):
    """Output Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="output_modifier"
    )  # type:ignore

    file_format: bpy.props.EnumProperty(
        items=lambda self, context: self._get_file_format_enum_values(  # type:ignore
            context
        ),  # type:ignore
        name="File Format",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    use_overwrite_output: bpy.props.BoolProperty(
        default=False,
        name="Overwrite Scene Output",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    overwrite_output: bpy.props.StringProperty(
        default="",
        subtype="DIR_PATH",
        name="Overwrite Scene Output",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    create_scene_state_subfolder: bpy.props.BoolProperty(
        default=False,
        name="Create Scene State Subfolder",
        description="Automatically create a subfolder with the name of the scene_state name (Useful for animation image sequence renders)",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore
    
    def _get_file_format_enum_values(
        self, context: Context
    ) -> list[tuple[str, str, str]]:

        # Blender 4.2 removed AVI_JPEG and AVI_RAW
        if check_blender_version((4, 2)):
            return [
                ("BMP", "BMP", ""),
                ("IRIS", "Iris", ""),
                ("PNG", "PNG", ""),
                ("JPEG", "JPEG", ""),
                ("JPEG2000", "JPEG 2000", ""),
                ("TARGA", "Targa", ""),
                ("TARGA_RAW", "Targa Raw", ""),
                ("CINEON", "Cineon", ""),
                ("DPX", "DPX", ""),
                ("OPEN_EXR_MULTILAYER", "OpenEXR MultiLayer ", ""),
                ("OPEN_EXR", "OpenEXR", ""),
                ("HDR", "Radiance HDR", ""),
                ("TIFF", "TIFF", ""),
                ("WEBP", "WebP", ""),
                ("FFMPEG", "FFmpeg Video", ""),
            ]
        else:
            return [
                ("BMP", "BMP", ""),
                ("IRIS", "Iris", ""),
                ("PNG", "PNG", ""),
                ("JPEG", "JPEG", ""),
                ("JPEG2000", "JPEG 2000", ""),
                ("TARGA", "Targa", ""),
                ("TARGA_RAW", "Targa Raw", ""),
                ("CINEON", "Cineon", ""),
                ("DPX", "DPX", ""),
                ("OPEN_EXR_MULTILAYER", "OpenEXR MultiLayer ", ""),
                ("OPEN_EXR", "OpenEXR", ""),
                ("HDR", "Radiance HDR", ""),
                ("TIFF", "TIFF", ""),
                ("WEBP", "WebP", ""),
                ("AVI_JPEG", "AVI JPEG", ""),
                ("AVI_RAW", "AVI Raw", ""),
                ("FFMPEG", "FFmpeg Video", ""),
            ]

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw output modifier properties"""

        layout.use_property_split = True
        layout.use_property_decorate = False

        row = layout.row(align=True)
        row.prop(self, "file_format")

        row = layout.row(align=True)
        row.prop(self, "create_scene_state_subfolder")

        row = layout.row(align=True)
        row.prop(self, "use_overwrite_output")

        if self.use_overwrite_output:
            box = layout.box()
            box.prop(self, "overwrite_output")

    def _apply(self, scene: Scene) -> None:
        """Update output modifier"""

        scene.render.image_settings.file_format = self.file_format

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:

        self.file_format = scene.render.image_settings.file_format

    def _clear(self) -> None:
        return


global_enum_items_available_engines: list[tuple[str, str, str]] = []


class RenderModifier(SceneModifierPropertyGroup):
    """Camera Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="render_modifier"
    )  # type:ignore

    engine: bpy.props.EnumProperty(
        items=lambda self, context: self._get_enum_items_engines(),  # type:ignore
        # default="BLENDER_EEVEE",
        name="Engine",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    # --------------------------------------------------------------
    # Global Modifier
    # --------------------------------------------------------------
    film_transparent: bpy.props.BoolProperty(
        default=False,
        name="Transparent",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    # --------------------------------------------------------------
    # Eeevee Modifier
    # --------------------------------------------------------------
    taa_render_samples: bpy.props.IntProperty(
        default=64,
        name="Render",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    taa_samples: bpy.props.IntProperty(
        default=16,
        name="Viewport",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    use_taa_reprojection: bpy.props.BoolProperty(
        default=True,
        name="Viewport Denoising",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_preview_samples: bpy.props.IntProperty(
        default=64,
        name="Preview Samples",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_preview_adaptive_min_samples: bpy.props.IntProperty(
        default=0,
        name="Min Samples",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_use_preview_denoising: bpy.props.BoolProperty(
        default=True,
        name="Preview Denoising",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_feature_set: bpy.props.EnumProperty(
        items=[
            ("SUPPORTED", "Supported", "", "", 0),
            ("EXPERIMENTAL", "Experimental", "", "ERROR", 1),
        ],  # type:ignore
        default="SUPPORTED",
        name="Feature Set",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_samples: bpy.props.IntProperty(
        default=128,
        name="Render Samples",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_adaptive_min_samples: bpy.props.IntProperty(
        default=0,
        name="Min Samples",
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    cycles_use_denoising: bpy.props.BoolProperty(
        default=True,
        name="Render Denoising",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _get_enum_items_engines(
        self,
    ) -> list[tuple[str, str, str]]:

        global_enum_items_available_engines.clear()

        available_engines_values = bpy.context.scene.get(
            RENDER_ENGINES_KEY, []
        )
        if not available_engines_values:
            available_engines_values = [
                "BLENDER_EEVEE",
                "CYCLES",
                "BLENDER_WORKBENCH",
            ]

        for i in available_engines_values:
            if i == "BLENDER_EEVEE":
                global_enum_items_available_engines.append((i, "EEVEE", ""))
            elif i == "CYCLES":
                global_enum_items_available_engines.append((i, "Cycles", ""))
            elif i == "BLENDER_WORKBENCH":
                global_enum_items_available_engines.append(
                    (i, "Workbench", "")
                )
            else:
                # Add any other engine that is not built-in
                global_enum_items_available_engines.append((i, i, ""))

        return global_enum_items_available_engines

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw output modifier properties"""

        layout.use_property_split = True
        layout.use_property_decorate = False

        col = layout.column(align=True)
        col.prop(self, "engine")

        if self.engine == "BLENDER_EEVEE":
            self._draw_eevee_modifier(layout)
        if self.engine == "CYCLES":
            self._draw_cycles_modifier(layout)

        self._draw_global_properties(layout)

    def _draw_global_properties(self, layout: bpy.types.UILayout):

        col = layout.column(align=True)
        col.prop(self, "film_transparent")

    def _draw_cycles_modifier(self, layout: bpy.types.UILayout):

        col = layout.column(align=True)
        col.prop(self, "cycles_feature_set")

        col = layout.column(align=True)
        col.prop(self, "cycles_preview_samples")
        col.prop(self, "cycles_preview_adaptive_min_samples")
        col.prop(self, "cycles_use_preview_denoising")

        col = layout.column(align=True)
        col.prop(self, "cycles_samples")
        col.prop(self, "cycles_adaptive_min_samples")
        col.prop(self, "cycles_use_denoising")

    def _draw_eevee_modifier(self, layout: bpy.types.UILayout):

        col = layout.column(align=True)
        col.prop(self, "taa_render_samples")
        col.prop(self, "taa_samples")

        col = layout.column(align=True)
        col.prop(self, "use_taa_reprojection")

    def _apply(self, scene: Scene) -> None:
        """Update output modifier"""

        scene.render.engine = self.engine
        scene.render.film_transparent = self.film_transparent
        scene.eevee.taa_render_samples = self.taa_render_samples
        scene.eevee.taa_samples = self.taa_samples
        scene.eevee.use_taa_reprojection = self.use_taa_reprojection

        scene.cycles.feature_set = self.cycles_feature_set
        scene.cycles.preview_samples = self.cycles_preview_samples
        scene.cycles.preview_adaptive_min_samples = (
            self.cycles_preview_adaptive_min_samples
        )
        scene.cycles.use_preview_denoising = self.cycles_use_preview_denoising
        scene.cycles.samples = self.cycles_samples
        scene.cycles.adaptive_min_samples = self.cycles_adaptive_min_samples
        scene.cycles.use_denoising = self.cycles_use_denoising

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:

        try:
            self.engine = scene.render.engine
        except TypeError:
            neologging.error("Cannot load default values for render engine")
            self.engine = "BLENDER_EEVEE"

        self.film_transparent = scene.render.film_transparent
        self.taa_render_samples = scene.eevee.taa_render_samples
        self.taa_samples = scene.eevee.taa_samples
        self.use_taa_reprojection = scene.eevee.use_taa_reprojection

        self.cycles_feature_set = scene.cycles.feature_set
        self.cycles_preview_samples = scene.cycles.preview_samples
        self.cycles_preview_adaptive_min_samples = (
            scene.cycles.preview_adaptive_min_samples
        )
        self.cycles_use_preview_denoising = scene.cycles.use_preview_denoising
        self.cycles_samples = scene.cycles.samples
        self.cycles_adaptive_min_samples = scene.cycles.adaptive_min_samples
        self.cycles_use_denoising = scene.cycles.use_denoising

    def _clear(self) -> None:
        return


class ColorManagementModifier(SceneModifierPropertyGroup):
    """Color Management Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="color_management_modifier"
    )  # type:ignore

    display_device: bpy.props.EnumProperty(
        items=[
            ("sRGB", "sRGB", ""),
            ("Display P3", "Display P3", ""),
            ("Rec.1886", "Rec.1886", ""),
            ("Rec.2020", "Rec.2020", ""),
        ],
        default="sRGB",
        name="Display Device",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    view_transform: bpy.props.EnumProperty(
        items=lambda self, context: self._get_view_transform_enum_values(  # type:ignore
            context
        ),  # type:ignore
        name="View Transform",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    look: bpy.props.EnumProperty(
        items=lambda self, context: self._get_look_enum_values(  # type:ignore
            context
        ),  # type:ignore
        name="Look",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    exposure: bpy.props.FloatProperty(
        default=0.0,
        precision=3,
        name="Exposure",
        max=10,
        min=-10,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    gamma: bpy.props.FloatProperty(
        default=1.0,
        precision=3,
        name="Gamma",
        min=0.0,
        max=5.0,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _get_view_transform_enum_values(
        self, context: Context
    ) -> list[tuple[str, str, str]]:

        if check_blender_version((4, 2, 0)):
            return [
                ("Standard", "Standard", ""),
                ("Khronos PBR Neutral", "Khronos PBR Neutral", ""),
                ("AgX", "Agx", ""),
                ("Filmic", "Filmic", ""),
                ("Filmic Log", "Filmic Log", ""),
                ("False Color", "False Color", ""),
                ("Raw", "Raw", ""),
            ]
        else:
            return [
                ("Standard", "Standard", ""),
                ("AgX", "Agx", ""),
                ("Filmic", "Filmic", ""),
                ("Filmic Log", "Filmic Log", ""),
                ("False Color", "False Color", ""),
                ("Raw", "Raw", ""),
            ]

    def _get_look_enum_values(
        self, context: Context
    ) -> list[tuple[str, str, str]]:

        if self.view_transform == "AgX":
            return [
                ("None", "None", ""),
                ("AgX - Punchy", "Punchy", ""),
                ("AgX - Greyscale", "Greyscale", ""),
                ("AgX - Very High Contrast", "Very High Contrast", ""),
                ("AgX - High Contrast", "High Contrast", ""),
                ("AgX - Medium High Contrast", "Medium High Contrast", ""),
                ("AgX - Medium Contrast", "Medium Contrast", ""),
                ("AgX - Low Contrast", "Low Contrast", ""),
                ("AgX - Very Low Contrast", "Very Low Contrast", ""),
            ]
        else:
            return [
                ("None", "None", ""),
                ("Very High Contrast", "Very High Contrast", ""),
                ("High Contrast", "High Contrast", ""),
                ("Medium High Contrast", "Medium High Contrast", ""),
                ("Medium Contrast", "Medium Contrast", ""),
                ("Low Contrast", "Low Contrast", ""),
                ("Very Low Contrast", "Very Low Contrast", ""),
            ]

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        layout.use_property_decorate = False
        layout.use_property_split = True

        col = layout.column(align=False)
        col.prop(self, "display_device", text="Display Device")
        col.separator()

        col.prop(self, "view_transform", text="View Transform")
        col.prop(self, "look", text="Look")
        col.prop(self, "exposure", text="Exposure", slider=True)
        col.prop(self, "gamma", text="Gamma", slider=True)

    def _apply(self, scene: Scene) -> None:

        scene.display_settings.display_device = self.display_device
        scene.view_settings.view_transform = self.view_transform
        scene.view_settings.look = self.look
        scene.view_settings.exposure = self.exposure
        scene.view_settings.gamma = self.gamma

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:

        self.display_device = scene.display_settings.display_device
        self.view_transform = scene.view_settings.view_transform
        self.look = scene.view_settings.look
        self.exposure = scene.view_settings.exposure
        self.gamma = scene.view_settings.gamma

    def _clear(self) -> None:
        return


class CollectionVisibilitysModifier(SceneModifierPropertyGroup):
    """Collection Visibility Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="collection_visibility_modifier"
    )  # type:ignore

    collections_visibility: bpy.props.CollectionProperty(
        type=CollectionVisibility,
    )  # type:ignore

    collections_index: bpy.props.IntProperty(default=0)  # type:ignore

    def draw_header(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ) -> None:
        """Draw header of the scene_state properties."""

        row = layout.row(align=True)

        row.popover(
            "EZS_PT_ColVizRestrictionTogglesMenu",
            text="",
            icon="DOWNARROW_HLT",
        )
        row.operator(
            "easystates.add_collection_visibility", icon="ADD", text=""
        )

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        col = layout.column(align=True)
        col.scale_y = 1.2

        if not self.collections_visibility:
            row = col.row(align=True)
            row.label(text="Select any collection to add", icon="INFO")
            return

        row = col.row(align=True)
        row.template_list(
            "EZS_UL_CollectionVisibility",
            "",
            self,
            "collections_visibility",
            self,
            "collections_index",
            rows=4,
        )

    def _apply(self, scene: Scene) -> None:

        for item in self.collections_visibility:
            item.apply(scene)

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections_visibility registered
        in the global scene_state properties"""

        if create_global_items and current_scene_state:
            for (
                col
            ) in (
                current_scene_state.collection_visibility_modifier.collections_visibility
            ):
                col_viz: CollectionVisibility = (
                    self.collections_visibility.add()
                )

                col_viz.block_update = True
                col_viz.copy_from(col)
                col_viz.block_update = False

        for col_item in self.collections_visibility:

            col_item.block_update = True
            collection_iddata: bpy.types.Collection = col_item.collection
            view_layer_collection = get_viewlayer_collection(
                col_item.collection
            )
            if view_layer_collection is None:
                neologging.error(
                    f"Could not find view_layer_collection for {col_item.collection.name}"
                )
                col_item.block_update = False
                continue

            col_item.exclude = view_layer_collection.exclude
            col_item.hide_select = collection_iddata.hide_select
            col_item.hide_viewport = collection_iddata.hide_viewport
            col_item.hide_viewport_layer = view_layer_collection.hide_viewport
            col_item.hide_render = collection_iddata.hide_render
            col_item.holdout = view_layer_collection.holdout
            col_item.indirect_only = view_layer_collection.indirect_only
            col_item.block_update = False

    def _clear(self) -> None:
        """Clear all items."""
        self.collections_visibility.clear()


class MaterialSlotsOverwriteModifier(SceneModifierPropertyGroup):
    """Create material slots overwrites for multiple objects"""

    global_props_name: bpy.props.StringProperty(
        default="material_slots_overwrite_modifier"
    )  # type:ignore

    overwrites: bpy.props.CollectionProperty(
        type=MaterialSlotsOverwrite,
    )  # type:ignore

    overwrites_index: bpy.props.IntProperty(default=0)  # type:ignore

    def draw_header(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ) -> None:

        row = layout.row(align=True)
        row.separator()
        row.operator(
            "easystates.add_material_slots_overwrite", icon="ADD", text=""
        )

    def get_object(
        self, obj: bpy.types.Object
    ) -> MaterialSlotsOverwrite | None:
        """Get object by global_id."""
        for item in self.overwrites:
            if item.object == obj:
                return item
        return None

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        col = layout.column(align=True)
        col.scale_y = 1.2

        if not self.overwrites:
            row = col.row(align=True)
            row.label(text="Select any object to add", icon="INFO")
            return

        row = col.row(align=True)
        row.template_list(
            "EZS_UL_MaterialSlotsOverwrites_Object",
            "",
            self,
            "overwrites",
            self,
            "overwrites_index",
            rows=4,
        )

        try:
            active_material_slot_object = self.overwrites[
                self.overwrites_index
            ]
        except IndexError:
            return

        if not active_material_slot_object.object:
            return

        row = layout.row(align=False)
        row.label(
            text=f"{active_material_slot_object.object.name} Overwrites:",
            icon="OBJECT_DATA",
        )

        row = layout.row(align=False)
        row.template_list(
            "EZS_UL_MaterialSlotsOverwrites_Materials",
            "",
            active_material_slot_object,
            "material_slots",
            active_material_slot_object,
            "material_slots_index",
            rows=4,
        )

        col = row.column(align=True)
        col.operator(
            "easystates.add_material_slot", text="", icon="ADD"
        ).object_name = active_material_slot_object.object.name

    def _apply(self, scene: Scene) -> None:
        """Apply scene_state."""

        for item in self.overwrites:
            item.apply(scene)

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections_visibility registered
        in the global scene_state properties"""

        if create_global_items and current_scene_state:
            for (
                obj
            ) in (
                current_scene_state.material_slots_overwrite_modifier.overwrites
            ):
                obj_m: MaterialSlotsOverwrite = self.overwrites.add()

                obj_m.block_update = True
                obj_m.copy_from(obj)
                obj_m.block_update = False

        # NOTE: Material slots cannot be copied from the scene and cannot
        # be synced with the scene.

        # for overwrite in self.overwrites:
        #     overwrite.block_update = True
        #     for material_slot in overwrite.material_slots:
        #         material_slot.block_update = True

        #         try:
        #             material_slot.material = (
        #                 material_slot.object.material_slots[
        #                     material_slot.slot_index
        #                 ].material
        #             )
        #         except IndexError:
        #             neologging.error(
        #                 f"Material slot {material_slot.slot_index} not found in {material_slot.object.name}"
        #             )
        #             continue

        #         material_slot.block_update = False
        #     overwrite.block_update = False

    def _clear(self) -> None:
        """Clear all items."""
        for i in self.overwrites:
            i.material_slots.clear()
        self.overwrites.clear()


class CustomPropertiesModifier(SceneModifierPropertyGroup):
    """Collection Visibility Modifier."""

    global_props_name: bpy.props.StringProperty(
        default="custom_properties_modifier"
    )  # type:ignore

    custom_properties: bpy.props.CollectionProperty(
        type=CustomProperty,
    )  # type:ignore

    custom_properties_index: bpy.props.IntProperty(default=0)  # type:ignore

    def get_custom_property(self, global_id: str) -> CustomProperty | None:
        """Get custom property by global_id."""
        for item in self.custom_properties:
            if item.global_id == global_id:
                return item
        return None

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        row = layout.row(align=False)
        row.prop(
            self._global_props(global_properties),
            "custom_properties_categories",
            text="Category",
        )

        row.operator(
            "easystates.repair_custom_property_categories",
            icon="FILE_REFRESH",
            text="",
        )

        col = layout.column(align=True)
        col.scale_y = 1.2

        if not self.custom_properties:
            row = col.row(align=True)
            row.label(text="No custom properties added", icon="INFO")
            return

        row = col.row(align=True)
        row.template_list(
            "EZS_UL_CustomProperties",
            "",
            self,
            "custom_properties",
            self,
            "custom_properties_index",
            rows=4,
        )

    def _apply(self, scene: Scene) -> None:

        for cp in self.custom_properties:
            cp.apply(scene)

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties"""

        if create_global_items and current_scene_state:
            for (
                globa_cp
            ) in (
                current_scene_state.custom_properties_modifier.custom_properties
            ):
                custom_property: CustomProperty = self.custom_properties.add()
                custom_property.block_update = True
                custom_property.copy_from(globa_cp)
                custom_property.block_update = False

        for cp in self.custom_properties:
            cp.block_update = True
            cp.set_prop_default_value()
            cp.block_update = False

    def _clear(self) -> None:
        """Clear all items."""
        self.custom_properties.clear()


class ObjectsVisibilityModifier(SceneModifierPropertyGroup):
    """Objects Visibility Snapshots."""

    global_props_name: bpy.props.StringProperty(
        default="objects_visibility_modifier"
    )  # type:ignore

    objects_visibility: bpy.props.CollectionProperty(
        type=ObjectVisibility
    )  # type:ignore
    objects_index: bpy.props.IntProperty()  # type:ignore

    def draw_header(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ) -> None:

        row = layout.row(align=True)
        row.popover(
            "EZS_PT_ObjVizRestrictionToggles",
            text="",
            icon="DOWNARROW_HLT",
        )
        row.operator("easystates.add_object_visibility", icon="ADD", text="")

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        obj_viz_global_props = global_properties.objects_visibility_modifier

        row = layout.row(align=True)
        row.prop(
            obj_viz_global_props,
            "sync_selection",
            text="Sync Selection",
            #    icon="RESTRICT_SELECT_OFF",
        )

        row.separator()

        if obj_viz_global_props.use_hide_select:
            row.operator(
                "easystates.toggle_object_visibility_ui_list",
                text="",
                icon="RESTRICT_SELECT_OFF",
            ).action = "HIDE_SELECT"

        if obj_viz_global_props.use_hide_set:
            row.operator(
                "easystates.toggle_object_visibility_ui_list",
                text="",
                icon="HIDE_OFF",
            ).action = "HIDE_SET"

        if obj_viz_global_props.use_hide_viewport:
            row.operator(
                "easystates.toggle_object_visibility_ui_list",
                text="",
                icon="RESTRICT_VIEW_OFF",
            ).action = "HIDE_VIEWPORT"

        if obj_viz_global_props.use_hide_render:
            row.operator(
                "easystates.toggle_object_visibility_ui_list",
                text="",
                icon="RESTRICT_RENDER_OFF",
            ).action = "HIDE_RENDER"

        col = layout.column(align=True)
        col.scale_y = 1.2

        if not self.objects_visibility:
            row = col.row(align=True)
            row.label(text="Select any object to add", icon="INFO")
            return

        row = col.row(align=True)
        row.template_list(
            "EZS_UL_ObjectVisibility",
            "",
            self,
            "objects_visibility",
            self,
            "objects_index",
            rows=4,
        )

    def _apply(self, scene: Scene) -> None:

        for item in self.objects_visibility:
            item.apply(scene)

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties"""

        if create_global_items and current_scene_state:
            for (
                obj
            ) in (
                current_scene_state.objects_visibility_modifier.objects_visibility
            ):
                neologging.info(f"Adding object visibility {obj.object.name}")
                obj_viz: ObjectVisibility = self.objects_visibility.add()

                obj_viz.block_update = True
                obj_viz.copy_from(obj)
                obj_viz.block_update = False

        for obj_item in self.objects_visibility:

            # Update with current scene values
            obj_item.block_update = True
            obj_item.hide_viewport = obj_item.object.hide_viewport
            obj_item.hide_render = obj_item.object.hide_render
            obj_item.hide_select = obj_item.object.hide_select
            obj_item.hide_set = obj_item.object.hide_get()
            obj_item.block_update = False

    def get_object(self, obj: bpy.types.Object) -> ObjectVisibility | None:
        """Get object visibility by object."""

        for item in self.objects_visibility:
            if item.object == obj:
                return item
        return None

    def _clear(self) -> None:
        self.objects_visibility.clear()


class ObjectsActionModifier(SceneModifierPropertyGroup):
    """Objects Visibility Snapshots."""

    global_props_name: bpy.props.StringProperty(
        default="objects_action_modifier"
    )  # type:ignore

    objects_action: bpy.props.CollectionProperty(
        type=ObjectAction
    )  # type:ignore

    objects_index: bpy.props.IntProperty()  # type:ignore

    def draw_header(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ) -> None:

        row = layout.row(align=True)
        row.operator("easystates.add_object_action", icon="ADD", text="")

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        col = layout.column(align=True)
        col.scale_y = 1.2

        if not self.objects_action:
            row = col.row(align=True)
            row.label(text="Select any object to add", icon="INFO")
            return

        row = col.row(align=True)
        row.template_list(
            "EZS_UL_ObjectAction",
            "",
            self,
            "objects_action",
            self,
            "objects_index",
            rows=4,
        )

    def _apply(self, scene: Scene) -> None:

        for item in self.objects_action:
            item.apply(scene)

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties"""

        if create_global_items and current_scene_state:
            for (
                obj
            ) in current_scene_state.objects_action_modifier.objects_action:
                neologging.info(f"Adding object visibility {obj.object.name}")
                obj_viz: ObjectAction = self.objects_action.add()

                obj_viz.block_update = True
                obj_viz.copy_from(obj)
                obj_viz.block_update = False

        for obj_item in self.objects_action:
            # Update with current scene values
            obj_item.block_update = True
            
            if obj_item.object.animation_data:
                obj_item.action = obj_item.object.animation_data.action
                
            obj_item.block_update = False

    # def get_object(self, obj: bpy.types.Object) -> ObjectAction | None:
    #     """Get object visibility by object."""

    #     for item in self.objects_visibility:
    #         if item.object == obj:
    #             return item
    #     return None

    def _clear(self) -> None:
        self.objects_action.clear()


class ObjectsTransformModifier(SceneModifierPropertyGroup):
    """Objects Transform Snapshots."""

    global_props_name: bpy.props.StringProperty(
        default="objects_transform_modifier"
    )  # type:ignore

    objects_transform: bpy.props.CollectionProperty(
        type=ObjectTransform
    )  # type:ignore

    objects_index: bpy.props.IntProperty()  # type:ignore

    def draw_header(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ) -> None:

        row = layout.row(align=True)
        row.operator("easystates.add_object_transform", icon="ADD", text="")

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        col = layout.column(align=True)
        col.scale_y = 1.2

        if not self.objects_transform:
            row = col.row(align=True)
            row.label(text="Select any object to add", icon="INFO")
            return

        row = col.row(align=True)
        row.template_list(
            "EZS_UL_ObjectTransform",
            "",
            self,
            "objects_transform",
            self,
            "objects_index",
            rows=4,
        )

        try:
            active_object_transform = self.objects_transform[
                self.objects_index
            ]
        except IndexError:
            return

        if not active_object_transform.object:
            return

        box = col.box()
        # box.use_property_decorate = False
        # box.use_property_split = True

        row = box.row(align=False)
        row.label(
            text=f"{active_object_transform.object.name} Transform:",
            icon="OBJECT_DATA",
        )

        row = box.row(align=False)
        row.prop(active_object_transform, "location")

        row = box.row(align=False)
        row.prop(active_object_transform, "rotation_euler")

        row = box.row(align=False)
        row.prop(active_object_transform, "scale")

    def _apply(self, scene: Scene) -> None:

        for item in self.objects_transform:
            item.apply(scene)

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool = False,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties

        Args:
            scene (Scene): Scene to load values
            global_properties (GlobalSceneStateProperties): Global properties
            create_global_items (bool, optional): Create global items when exists. Defaults to False.
        """

        if create_global_items and current_scene_state:
            print("Creating global items")
            for (
                obj
            ) in (
                current_scene_state.objects_transform_modifier.objects_transform
            ):
                neologging.info(f"Adding object transform {obj.object.name}")
                obj_viz: ObjectTransform = self.objects_transform.add()

                obj_viz.block_update = True
                obj_viz.copy_from(obj)
                obj_viz.block_update = False

        # load scene vales
        for obj_item in self.objects_transform:
            # Update with current scene values
            obj_item.block_update = True
            obj_item.location = obj_item.object.location

            # convert to euler
            obj_item.rotation_euler = obj_item.object.rotation_euler
            obj_item.scale = obj_item.object.scale
            obj_item.block_update = False

    def get_object(self, obj: bpy.types.Object) -> ObjectTransform | None:
        """Get object visibility by object."""

        for item in self.objects_transform:
            if item.object == obj:
                return item
        return None

    def _clear(self) -> None:
        self.objects_transform.clear()


class RenderRegionModifier(SceneModifierPropertyGroup):
    """Objects Visibility Snapshots."""

    global_props_name: bpy.props.StringProperty(
        default="render_region_modifier"
    )  # type:ignore

    use_render_border: bpy.props.BoolProperty(
        name="Use render border in this scene_state",
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    border_min_x: bpy.props.FloatProperty(
        default=0.0,
        name="Min X",
        min=0.0,
        max=1.0,
    )  # type:ignore

    border_max_x: bpy.props.FloatProperty(
        default=0.0,
        name="Max X",
        min=0.0,
        max=1.0,
    )  # type:ignore

    border_min_y: bpy.props.FloatProperty(
        default=0.0,
        name="Min Y",
        min=0.0,
        max=1.0,
    )  # type:ignore

    border_max_y: bpy.props.FloatProperty(
        default=0.0,
        name="Max Y",
        min=0.0,
        max=1.0,
    )  # type:ignore

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        row = layout.row(align=True)
        row.prop(
            self,
            "use_render_border",
            text="Use Render Region",
        )

        if not self.use_render_border:
            return

        box_label = (
            f" Xmin: {self.border_min_x:.2f} Ymin: {self.border_min_y:.2f} Xmax: {self.border_max_x:.2f} Ymax: {self.border_max_y:.2f}"
            if self.border_min_x
            or self.border_min_y
            or self.border_max_x
            or self.border_max_y
            else "No Render Region Stored"
        )

        col = layout.column(align=True)

        box = col.box()
        box.label(text=box_label)

        row = col.row(align=True)
        row.operator(
            "easystates.update_scene_state_render_border",
            text="Save Current Render Region",
            icon="FILE_TICK",
        )

    def _apply(self, scene: Scene) -> None:

        if not self.use_render_border:
            scene.render.border_min_x = 0
            scene.render.border_max_x = 1
            scene.render.border_min_y = 0
            scene.render.border_max_y = 1
            return

        scene.render.border_min_x = self.border_min_x
        scene.render.border_max_x = self.border_max_x
        scene.render.border_min_y = self.border_min_y
        scene.render.border_max_y = self.border_max_y

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties"""
        return

    def _clear(self) -> None:
        return


class SimplifyModifier(SceneModifierPropertyGroup):
    """Objects Visibility Snapshots."""

    global_props_name: bpy.props.StringProperty(
        default="simplify_modifier"
    )  # type:ignore

    use_simplify: bpy.props.BoolProperty(
        name="Use Simplify",
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_subdivision: bpy.props.IntProperty(
        name="Subdivision",
        default=0,
        min=0,
        max=6,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_subdivision_render: bpy.props.IntProperty(
        name="Subdivision",
        default=0,
        min=0,
        max=6,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_child_particles: bpy.props.FloatProperty(
        name="Child Particles",
        default=1,
        min=0,
        max=1,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_child_particles_render: bpy.props.FloatProperty(
        name="Child Particles",
        default=1,
        min=0,
        max=1,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    texture_limit: bpy.props.EnumProperty(
        items=[
            ("OFF", "No Limit", ""),
            ("128", "128", ""),
            ("256", "256", ""),
            ("512", "512", ""),
            ("1024", "1024", ""),
            ("2048", "2048", ""),
            ("4096", "4096", ""),
            ("8192", "8192", ""),
        ],
        default="4096",
        name="Texture Limit",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    texture_limit_render: bpy.props.EnumProperty(
        items=[
            ("OFF", "No Limit", ""),
            ("128", "128", ""),
            ("256", "256", ""),
            ("512", "512", ""),
            ("1024", "1024", ""),
            ("2048", "2048", ""),
            ("4096", "4096", ""),
            ("8192", "8192", ""),
        ],
        default="4096",
        name="Texture Limit",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_volumes: bpy.props.FloatProperty(
        name="Volume Resolution",
        default=1,
        min=0,
        max=1,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    use_simplify_normals: bpy.props.BoolProperty(
        name="Normals",
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_shadows: bpy.props.FloatProperty(
        name="Shadows",
        default=1,
        min=0,
        max=1,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    simplify_shadows_render: bpy.props.FloatProperty(
        name="Shadows",
        default=1,
        min=0,
        max=1,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        row = layout.row(align=True)
        row.prop(
            self,
            "use_simplify",
        )

        if not self.use_simplify:
            return

        render_engine = context.scene.render.engine

        col = layout.column(align=True)
        col.use_property_split = True
        col.use_property_decorate = False

        box = col.box()
        box.label(text="Viewport")

        box.prop(self, "simplify_subdivision")
        box.prop(self, "simplify_child_particles", slider=True)

        if render_engine == "CYCLES":
            box.prop(self, "texture_limit")

        box.prop(self, "simplify_volumes", slider=True)

        if render_engine == "BLENDER_EEVEE":
            if check_blender_version((3, 5, 0)):
                box.prop(self, "simplify_shadows", slider=True)

        if check_blender_version((4, 1, 0)):
            box.prop(self, "use_simplify_normals")

        box = col.box()
        box.label(text="Render")

        box.prop(self, "simplify_subdivision_render")
        box.prop(self, "simplify_child_particles_render", slider=True)

        if render_engine == "CYCLES":
            box.prop(self, "texture_limit_render")
        if render_engine == "BLENDER_EEVEE":
            if check_blender_version((3, 5, 0)):
                box.prop(self, "simplify_shadows_render", slider=True)

    def _apply(self, scene: Scene) -> None:

        scene.render.use_simplify = self.use_simplify
        if not self.use_simplify:
            return

        scene.render.simplify_subdivision = self.simplify_subdivision
        scene.render.simplify_subdivision_render = (
            self.simplify_subdivision_render
        )
        scene.render.simplify_child_particles = self.simplify_child_particles
        scene.render.simplify_child_particles_render = (
            self.simplify_child_particles_render
        )
        scene.cycles.texture_limit = self.texture_limit
        scene.cycles.texture_limit_render = self.texture_limit_render
        scene.render.simplify_volumes = self.simplify_volumes

        if check_blender_version((4, 1, 0)):
            scene.render.use_simplify_normals = self.use_simplify_normals

        if check_blender_version((3, 5, 0)):
            scene.render.simplify_shadows = self.simplify_shadows
            scene.render.simplify_shadows_render = self.simplify_shadows_render

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties"""

        self.use_simplify = scene.render.use_simplify
        self.simplify_subdivision = scene.render.simplify_subdivision
        self.simplify_subdivision_render = (
            scene.render.simplify_subdivision_render
        )
        self.simplify_child_particles = scene.render.simplify_child_particles
        self.simplify_child_particles_render = (
            scene.render.simplify_child_particles_render
        )
        self.texture_limit = scene.cycles.texture_limit
        self.texture_limit_render = scene.cycles.texture_limit_render
        self.simplify_volumes = scene.render.simplify_volumes

        if check_blender_version((4, 1, 0)):
            self.use_simplify_normals = scene.render.use_simplify_normals

        if check_blender_version((3, 5, 0)):
            self.simplify_shadows = scene.render.simplify_shadows
            self.simplify_shadows_render = scene.render.simplify_shadows_render

    def _clear(self) -> None:
        return


class AnimationModifier(SceneModifierPropertyGroup):
    """Objects Visibility Snapshots."""

    global_props_name: bpy.props.StringProperty(
        default="animation_modifier"
    )  # type:ignore

    render_as_animation: bpy.props.BoolProperty(
        name="Render as Animation",
        default=False,
    )  # type:ignore

    frame_start: bpy.props.IntProperty(
        name="Start Frame",
        default=1,
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    frame_end: bpy.props.IntProperty(
        name="End Frame",
        default=250,
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    frame_step: bpy.props.IntProperty(
        name="Frame Step",
        default=1,
        min=1,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _draw(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):

        row = layout.row(align=True)
        row.prop(self, "render_as_animation")

        if not self.render_as_animation:
            return

        col = layout.column(align=True)
        col.use_property_decorate = False
        col.use_property_split = True

        col.prop(
            self,
            "frame_start",
        )
        col.prop(
            self,
            "frame_end",
        )

        col.prop(
            self,
            "frame_step",
        )

    def _apply(self, scene: Scene) -> None:

        if not self.render_as_animation:
            return

        scene.frame_start = self.frame_start
        scene.frame_end = self.frame_end
        scene.frame_step = self.frame_step

    def _load_scene_values(
        self,
        scene: Scene,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool,
    ) -> None:
        """Load default values. loads all current collections registered
        in the global scene_state properties"""

        self.frame_start = scene.frame_start
        self.frame_end = scene.frame_end
        self.frame_step = scene.frame_step

    def _clear(self) -> None:
        return


class EZS_SceneStates(bpy.types.PropertyGroup):
    """Scene State Properties."""

    selected : bpy.props.BoolProperty(default=False)  # type:ignore
    """Selected state. It's used to mark the state as selected in the UI so
    some operation can be peformed. currently, only 'apply to selected state' is using it."""
    
    id: bpy.props.StringProperty()  # type:ignore
    name: bpy.props.StringProperty(name="Name")  # type:ignore
    render: bpy.props.BoolProperty(default=True)  # type:ignore
    export: bpy.props.BoolProperty(default=True)  # type:ignore

    # Stores the last render path used for this state. 
    # It does not stores the full filepath with the extension
    # since at the time of saving the scene state the extension
    # is not known until the render is done.
    last_render_path: bpy.props.StringProperty(
        name="Last Render Path",
        description="Last render path used",
        subtype="FILE_PATH",
    )  # type:ignore

    camera_modifier: bpy.props.PointerProperty(
        type=CameraModifier
    )  # type:ignore

    world_modifier: bpy.props.PointerProperty(
        type=WorldModifier
    )  # type:ignore

    render_modifier: bpy.props.PointerProperty(
        type=RenderModifier
    )  # type:ignore

    simplify_modifier: bpy.props.PointerProperty(
        type=SimplifyModifier
    )  # type:ignore

    resolution_modifier: bpy.props.PointerProperty(
        type=ResolutionModifier
    )  # type:ignore

    animation_modifier: bpy.props.PointerProperty(
        type=AnimationModifier
    )  # type:ignore

    output_modifier: bpy.props.PointerProperty(
        type=OutputModifier
    )  # type:ignore

    color_management_modifier: bpy.props.PointerProperty(
        type=ColorManagementModifier
    )  # type:ignore

    collection_visibility_modifier: bpy.props.PointerProperty(
        type=CollectionVisibilitysModifier
    )  # type:ignore

    material_slots_overwrite_modifier: bpy.props.PointerProperty(
        type=MaterialSlotsOverwriteModifier
    )  # type:ignore

    objects_visibility_modifier: bpy.props.PointerProperty(
        type=ObjectsVisibilityModifier
    )  # type:ignore

    objects_action_modifier: bpy.props.PointerProperty(
        type=ObjectsActionModifier
    )  # type:ignore

    objects_transform_modifier: bpy.props.PointerProperty(
        type=ObjectsTransformModifier
    )  # type:ignore

    custom_properties_modifier: bpy.props.PointerProperty(
        type=CustomPropertiesModifier
    )  # type:ignore

    render_region_modifier: bpy.props.PointerProperty(
        type=RenderRegionModifier
    )  # type:ignore

    def copy_from(self, other: "EZS_SceneStates") -> None:
        """Copy properties from another scene_state."""

        self.render = other.render

        for annotation in self.__annotations__:
            if not annotation.endswith("_modifier"):
                continue

            scene_state_prop_group: SceneModifierPropertyGroup = getattr(
                self, annotation
            )
            scene_state_prop_group.copy_from(getattr(other, annotation))

    def _get_modifier_props(self) -> list[SceneModifierPropertyGroup]:

        props = []

        for annotation in self.__annotations__:
            if not annotation.endswith("_modifier"):
                continue
            props.append(getattr(self, annotation))

        return props

    def apply(
        self, scene: Scene, global_properties: GlobalSceneStateProperties
    ):
        """Apply Scene State."""

        for prop in self._get_modifier_props():
            prop.apply(scene, global_properties)

    def clear(self):
        """Clear all scene state properties."""
        for prop in self._get_modifier_props():
            prop.clear()

    def get_output_filepath(
        self, output_dir: str, global_properties: GlobalSceneStateProperties
    ) -> Path:
        """Get the output path for the scene state.

        Args:
            output_dir (Path): Output directory (EasyState output directory)
            global_properties (GlobalSceneStateProperties): Global properties
        """

        output_modifier: OutputModifier = self.output_modifier
        scene_output = Path(output_dir)

        if not output_modifier.enabled(global_properties):
            return scene_output / self.name

        if output_modifier.use_overwrite_output:
            if not output_modifier.overwrite_output:
                return scene_output / self.name

            overwrite_output = Path(output_modifier.overwrite_output)
            if not overwrite_output.exists():
                return scene_output / self.name

            scene_output = overwrite_output

        if output_modifier.create_scene_state_subfolder:
            scene_output: Path = scene_output / self.name
            if not scene_output.exists():
                scene_output.mkdir()

        return scene_output / self.name

    def render_as_animation(self, scene: Scene) -> bool:
        """Check if the scene state is an animation."""
        return self.animation_modifier.render_as_animation

    def load_scene_values(
        self,
        scene: Scene,
        global_properties: GlobalSceneStateProperties,
        current_scene_state: "EZS_SceneStates | None",
        create_global_items: bool = False,
    ) -> int:
        """Load default values."""

        total_changes = 0
        for prop in self._get_modifier_props():

            try:
                total_changes += prop.load_scene_values(
                    scene,
                    global_properties,
                    current_scene_state,
                    create_global_items=create_global_items,
                )
            except Exception as e:  # pylint: disable=broad-except
                neologging.error(f"Error loading default values for {prop}")
                neologging.debug(traceback.format_exc())
                neologging.error(str(e))

        return total_changes

    def draw_props(
        self,
        context: Context,
        layout: bpy.types.UILayout,
        global_properties: GlobalSceneStateProperties,
    ):
        """Draw scene state properties."""
        for prop in self._get_modifier_props():
            prop.draw(context, layout, global_properties)

    def get_modifier_by_type(
        self, by_type: type[SceneModifierPropertyGroup]
    ) -> SceneModifierPropertyGroup | None:
        """Get modifier by instance."""
        for prop in self._get_modifier_props():
            if isinstance(prop, by_type):
                return prop
        return None


scene_modifiers = (
    ObjectsActionModifier,
    ObjectsTransformModifier,
    OutputModifier,
    AnimationModifier,
    SimplifyModifier,
    CameraModifier,
    WorldModifier,
    RenderModifier,
    ResolutionModifier,
    ColorManagementModifier,
    CollectionVisibilitysModifier,
    MaterialSlotsOverwriteModifier,
    ObjectsVisibilityModifier,
    CustomPropertiesModifier,
    RenderRegionModifier,
)
