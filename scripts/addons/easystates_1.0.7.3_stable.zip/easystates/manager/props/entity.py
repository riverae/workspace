# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import traceback
from dataclasses import dataclass, field
from typing import Any

import bpy
from bpy.types import Context, Scene

from ...libs import neologging
from .utils import get_viewlayer_collection


def _get_material_from_nodetree(
    nodetree: bpy.types.ShaderNodeTree,
) -> bpy.types.Material | None:
    for material in bpy.data.materials:
        if material.node_tree == nodetree:
            return material
    return None


def _get_world_from_nodetree(
    nodetree: bpy.types.ShaderNodeTree,
) -> bpy.types.World | None:

    for world in bpy.data.worlds:
        if world.node_tree == nodetree:
            return world
    return None


@dataclass
class CustomPropCategoryData:
    """Custom Property Category Data."""

    name: str = field(default="None")
    icon_name: str = field(default="BLANK1")


class CustomPropertyCategory(bpy.types.PropertyGroup):
    """Custom Property Category."""

    name: bpy.props.StringProperty(name="Name")  # type:ignore
    icon_name: bpy.props.StringProperty(
        name="Icon Name", default="NONE"
    )  # type:ignore


class GlobalCollectionPropertyItem(bpy.types.PropertyGroup):
    """Global Collection Property Item is a bpy.props.CollectionProperty item
    that exists both in the global scene_state properties
    and in each scene_state modifiers, so it's possible to shares the same
    collection itens across all scene states,
    but with different values.

    When a global reference is removed from the scene_state, it's also removed
    from the global scene_state properties.

    NOTE: This is not working like this anymore,
    check the DEVELOPMENT.md file (23/11/2024)

    Attributes:
        global_id (bpy.props.StringProperty): The global id of the item.
        This is the property that is used to identify the same item in the
        global scene_state properties and in the scene_state modifiers.
    """

    global_id: bpy.props.StringProperty()  # type:ignore
    block_update: bpy.props.BoolProperty(default=False)  # type:ignore

    def copy_from(self, other: "GlobalCollectionPropertyItem") -> None:
        """Copy values from other custom property."""

        for annotation in other.__annotations__:
            prop = getattr(self, annotation)
            if isinstance(prop, bpy.types.bpy_prop_collection):
                for item in getattr(other, annotation):
                    new_item: "GlobalCollectionPropertyItem" = prop.add()
                    new_item.copy_from(item)
            else:
                setattr(self, annotation, getattr(other, annotation))

    def apply(self, scene: Scene) -> None:
        """Apply changes to the scene."""
        self._apply(scene)

    def _apply(self, scene: Scene) -> None:
        """Apply changes to the scene."""
        raise NotImplementedError

    def get_global_properties(self, scene: Scene) -> bpy.types.PropertyGroup:
        """Get global properties."""
        return scene.easystates_manager.global_properties

    def _apply_update(self, scene: Scene) -> None:

        if self.block_update:
            return

        self._apply(scene)


class CustomProperty(GlobalCollectionPropertyItem):
    """Collection Property Item."""

    global_id: bpy.props.StringProperty()  # type:ignore

    name: bpy.props.StringProperty(
        name="Name",
        default="",
    )  # type:ignore

    id_data_pointer: bpy.props.PointerProperty(
        type=bpy.types.ID,
    )  # type:ignore

    path_from_id: bpy.props.StringProperty(
        name="Full Path From ID",
        default="",
    )  # type:ignore

    identifier: bpy.props.StringProperty(
        name="Identifier",
    )  # type:ignore

    category_name: bpy.props.StringProperty(
        name="Category",
        default="",
    )  # type:ignore

    category_icon: bpy.props.StringProperty(
        name="Category Icon",
        default="BLANK1",
    )  # type:ignore

    value_type: bpy.props.EnumProperty(
        items=[
            ("FLOAT", "Float", ""),
            ("INT", "Int", ""),
            ("BOOL", "Bool", ""),
            ("STRING", "String", ""),
            ("ARRAY2", "Array", ""),
            ("ARRAY3", "Array", ""),
            ("ARRAY3COLOR", "Array", ""),
            ("ARRAY4", "Array", ""),
            ("ARRAY4COLOR", "Array", ""),
        ],
        default="FLOAT",
        name="Value Type",
    )  # type:ignore

    float_value: bpy.props.FloatProperty(
        name="Number",
        default=0.0,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    int_value: bpy.props.IntProperty(
        name="Int",
        default=0,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    bool_value: bpy.props.BoolProperty(
        name="Bool",
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    string_value: bpy.props.StringProperty(
        name="String",
        default="",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    array2_value: bpy.props.FloatVectorProperty(
        name="Array",
        default=(0.0, 0.0),
        size=2,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    array3_value: bpy.props.FloatVectorProperty(
        name="Array",
        default=(0.0, 0.0, 0.0),
        size=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    array3color_value: bpy.props.FloatVectorProperty(
        name="Color",
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0),
        subtype="COLOR",
        size=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    array4_value: bpy.props.FloatVectorProperty(
        name="Array",
        default=(0.0, 0.0, 0.0, 0.0),
        size=4,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    array4color_value: bpy.props.FloatVectorProperty(
        name="Color",
        min=0.0,
        max=1.0,
        default=(1.0, 1.0, 1.0, 1.0),
        subtype="COLOR",
        size=4,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    invalid_path: bpy.props.BoolProperty(
        default=False, name="Invalid Path"
    )  # type:ignore
    """Flag to indicate if the path is invalid. 
    So the Repair Custom Property Operator can be used"""

    invalid_value: bpy.props.BoolProperty(
        default=False, name="Invalid Value"
    )  # type:ignore
    """Flag to indicate if the value is invalid.
    So the Repair Custom Property Operator can be used"""

    invalid_identifier: bpy.props.BoolProperty(
        default=False, name="Invalid Identifier"
    )  # type:ignore
    """Flag to indicate if the identifier is invalid.
    So the Repair Custom Property Operator can be used"""

    def get_bl_data(self) -> bpy.types.PropertyGroup | None:
        """Get bl Data"""

        try:
            id_data = self.id_data_pointer
            if self.path_from_id:  # pylint: disable=using-constant-test
                id_data = self.id_data_pointer.path_resolve(self.path_from_id)

            self.invalid_path = False
            return id_data
        except (ValueError, AttributeError):
            neologging.warning(
                f"Invalid path from id: {self.path_from_id}, pointer: {self.id_data_pointer}"
            )
            self.invalid_path = True
            return None

    def get_bl_prop_value(self) -> Any | None:
        """Get prop value"""

        bl_prop = self.get_bl_data()
        if not bl_prop:
            return None

        try:
            return getattr(bl_prop, self.identifier)
        except AttributeError:
            try:
                return bl_prop[self.identifier]
            except AttributeError:
                neologging.exception(traceback.format_exc())
                neologging.error(f"Invalid identifier: {self.identifier}")
            except KeyError:
                neologging.exception(traceback.format_exc())
                neologging.error(f"Invalid key identifier: {self.identifier}")

        return None

    def apply_bl_prop_value(self, value: Any) -> None:
        """Apply value to bl prop."""

        bl_prop = self.get_bl_data()
        if not bl_prop:
            return

        try:
            setattr(bl_prop, self.identifier, value)
        except ValueError:
            neologging.exception(traceback.format_exc())
            neologging.warning(
                f"Invalid value for {self.id_data_pointer} > {bl_prop} > {self.path_from_id} > {self.identifier} = {value}"
            )
            self.invalid_value = True
        except AttributeError:
            try:
                bl_prop[self.identifier] = value
            except AttributeError:
                neologging.exception(traceback.format_exc())
                neologging.warning(f"Invalid identifier: {self.identifier}")
                self.invalid_identifier = True

    def _is_geomtry_node_id_data(self) -> bool:
        """Check if id data is a geometry node tree."""

        bl_data = self.get_bl_data()

        if not bl_data:
            return False
        if not hasattr(bl_data, "node_group"):
            return False
        if not bl_data.node_group.bl_idname == "GeometryNodeTree":
            return False
        return True

    def _update_geometry_node_id_data(self, context: Context) -> None:

        bl_data = self.get_bl_data()
        if not bl_data:
            return

        bl_data.node_group.interface_update(context)

    def _apply(self, scene: Scene):
        """Set value to data path."""

        if not self.id_data:
            raise ValueError("ID Data is empty.")
        if not self.identifier:
            raise ValueError("Identifier is empty.")

        match self.value_type:
            case "FLOAT":
                self.apply_bl_prop_value(self.float_value)
            case "INT":
                self.apply_bl_prop_value(self.int_value)
            case "BOOL":
                self.apply_bl_prop_value(self.bool_value)
            case "STRING":
                try:
                    self.apply_bl_prop_value(self.string_value)
                except TypeError:
                    neologging.exception(
                        f"Invalid value for {self.identifier}"
                    )
            case "ARRAY2":
                self.apply_bl_prop_value(self.array2_value)
            case "ARRAY3":
                self.apply_bl_prop_value(self.array3_value)
            case "ARRAY3COLOR":
                self.apply_bl_prop_value(self.array3color_value)
            case "ARRAY4":
                self.apply_bl_prop_value(self.array4_value)
            case "ARRAY4COLOR":
                self.apply_bl_prop_value(self.array4color_value)
            case _:
                raise ValueError(f"Invalid value type: {self.value_type}")

        if self._is_geomtry_node_id_data():
            self._update_geometry_node_id_data(
                bpy.context  # FIXME: bpy.context is not defined
            )

    def set_prop_default_value(self):
        """Set default value to property."""

        match self.value_type:
            case "FLOAT":
                self.float_value = self.get_bl_prop_value()
            case "INT":
                self.int_value = self.get_bl_prop_value()
            case "BOOL":
                self.bool_value = self.get_bl_prop_value()
            case "STRING":
                self.string_value = self.get_bl_prop_value()
            case "ARRAY2":
                self.array2_value = self.get_bl_prop_value()
            case "ARRAY3":
                self.array3_value = self.get_bl_prop_value()
            case "ARRAY3COLOR":
                self.array3color_value = self.get_bl_prop_value()
            case "ARRAY4":
                self.array4_value = self.get_bl_prop_value()
            case "ARRAY4COLOR":
                self.array4color_value = self.get_bl_prop_value()
            case _:
                raise ValueError(f"Invalid value type: {self.value_type}")

    def get_prop_default_name(self) -> str:
        """Get default property name."""

        bl_prop = self.get_bl_data()
        if not bl_prop:
            return ""

        prop_name = ""
        if hasattr(bl_prop, "name"):
            prop_name = bl_prop.name

        if prop_name:
            # If the identifier is default_value, return the prop name
            # since its not useful to show it
            if self.identifier == "default_value":
                return prop_name
            else:
                return f"{prop_name}.{self.identifier}"
        else:
            return self.identifier.replace("_", " ").title()

    def save_updated_category(self) -> CustomPropCategoryData:
        """Return a string that represents the category of the custom property"""

        category_data = CustomPropCategoryData()

        if isinstance(self.id_data_pointer, bpy.types.ShaderNodeTree):
            material = _get_material_from_nodetree(self.id_data_pointer)
            if material:
                category_data.name = material.name
                category_data.icon_name = "MATERIAL"
            elif world := _get_world_from_nodetree(self.id_data_pointer):
                category_data.name = world.name
                category_data.icon_name = "WORLD_DATA"
        else:
            match type(self.id_data_pointer):
                case bpy.types.Mesh:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "MESH_DATA"
                case bpy.types.Camera:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "CAMERA_DATA"
                case bpy.types.Object:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "OBJECT_DATA"
                case bpy.types.World:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "WORLD_DATA"

                case bpy.types.Collection:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "OUTLINER_COLLECTION"
                case bpy.types.Material:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "MATERIAL"
                case bpy.types.Scene:
                    category_data.name = self.id_data_pointer.name
                    category_data.icon_name = "SCENE_DATA"
                case _:
                    category_data.name = "Other"
                    category_data.icon_name = "QUESTION"

        self.category_name = category_data.name
        self.category_icon = category_data.icon_name
        return category_data


class CollectionVisibility(GlobalCollectionPropertyItem):
    """Collection Visibility Item."""

    global_id: bpy.props.StringProperty()  # type:ignore

    collection: bpy.props.PointerProperty(
        type=bpy.types.Collection,
    )  # type:ignore

    exclude: bpy.props.BoolProperty(
        default=False,
        name="Exclude",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    hide_select: bpy.props.BoolProperty(
        default=False,
        name="Hide Select",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    hide_viewport: bpy.props.BoolProperty(
        default=True,
        name="Hide Viewport",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    hide_viewport_layer: bpy.props.BoolProperty(
        default=True,
        name="Hide Viewport Layer",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    hide_render: bpy.props.BoolProperty(
        default=True,
        name="Hide Render",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    holdout: bpy.props.BoolProperty(
        default=False,
        name="Holdout",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    indirect_only: bpy.props.BoolProperty(
        default=False,
        name="Indirect Only",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _apply(self, scene: Scene):
        """Apply visibility to collection."""

        if not self.collection:
            return

        global_props = self.get_global_properties(scene)
        collections_visibility_props = (
            global_props.collection_visibility_modifier
        )

        if collections_visibility_props.use_hide_viewport:
            self.collection.hide_viewport = self.hide_viewport
        if collections_visibility_props.use_hide_render:
            self.collection.hide_render = self.hide_render
        if collections_visibility_props.use_hide_select:
            self.collection.hide_select = self.hide_select

        view_layer_collection = get_viewlayer_collection(self.collection)
        if view_layer_collection is None:
            neologging.warning(
                f"Collection {self.collection.name} not found in view layer."
            )
            return

        if collections_visibility_props.use_exclude:
            view_layer_collection.exclude = self.exclude
        if collections_visibility_props.use_holdout:
            view_layer_collection.holdout = self.holdout
        if collections_visibility_props.use_indirect_only:
            view_layer_collection.indirect_only = self.indirect_only
        if collections_visibility_props.use_hide_viewport_layer:
            view_layer_collection.hide_viewport = self.hide_viewport_layer


class ObjectVisibility(GlobalCollectionPropertyItem):
    """Object Visibility Item."""

    # TODO add hide select and hide from view layer

    global_id: bpy.props.StringProperty()  # type:ignore

    object: bpy.props.PointerProperty(type=bpy.types.Object)  # type:ignore

    hide_select: bpy.props.BoolProperty(
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    hide_set: bpy.props.BoolProperty(
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )

    hide_viewport: bpy.props.BoolProperty(
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    hide_render: bpy.props.BoolProperty(
        default=False,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),  # type:ignore
    )  # type:ignore

    def _apply(self, scene: Scene):
        """Apply visibility to object."""

        if not self.object:
            return

        global_props = self.get_global_properties(scene)
        objects_visibility_props = global_props.objects_visibility_modifier

        if objects_visibility_props.use_hide_select:
            self.object.hide_select = self.hide_select
        if objects_visibility_props.use_hide_set:
            self.object.hide_set(self.hide_set)
        if objects_visibility_props.use_hide_viewport:
            self.object.hide_viewport = self.hide_viewport
        if objects_visibility_props.use_hide_render:
            self.object.hide_render = self.hide_render


class ObjectAction(GlobalCollectionPropertyItem):
    """Object Visibility Item."""

    global_id: bpy.props.StringProperty()  # type:ignore

    object: bpy.props.PointerProperty(type=bpy.types.Object)  # type:ignore
    action: bpy.props.PointerProperty(
        type=bpy.types.Action,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _apply(self, scene: Scene):
        """Apply visibility to object."""

        if not self.object:
            return

        if not self.action:
            neologging.warning("Action is empty.")
            return

        if not self.object.animation_data:
            neologging.warning("Object has no animation data.")
            return

        self.object.animation_data.action = self.action


class ObjectTransform(GlobalCollectionPropertyItem):
    """Object Visibility Item."""

    global_id: bpy.props.StringProperty()  # type:ignore
    object: bpy.props.PointerProperty(type=bpy.types.Object)  # type:ignore
    location: bpy.props.FloatVectorProperty(
        default=(0.0, 0.0, 0.0),
        name="Location",
        subtype="TRANSLATION",
        size=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    rotation_euler: bpy.props.FloatVectorProperty(
        default=(0.0, 0.0, 0.0),
        name="Rotation",
        size=3,
        subtype="EULER",
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    scale: bpy.props.FloatVectorProperty(
        default=(1.0, 1.0, 1.0),
        name="Scale",
        size=3,
        precision=3,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _apply(self, scene: Scene):
        """Apply visibility to object."""

        if not self.object:
            neologging.warning("Object is empty.")
            return

        self.object.location = self.location
        self.object.rotation_euler = self.rotation_euler
        self.object.scale = self.scale


class MaterialSlot(GlobalCollectionPropertyItem):
    """Material Slot Item. Contains a material that will be applied to the object and slot index."""

    global_id: bpy.props.StringProperty()  # type:ignore

    object: bpy.props.PointerProperty(type=bpy.types.Object)  # type:ignore
    material: bpy.props.PointerProperty(
        type=bpy.types.Material,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore
    slot_index: bpy.props.IntProperty(
        default=0,
        update=lambda self, context: self._apply_update(  # type:ignore
            context.scene
        ),
    )  # type:ignore

    def _apply(self, scene: Scene):
        """Apply material to object."""

        if not self.material:
            neologging.warning("Material is empty.")
            return

        neologging.info(
            f"Applying material {self.material} to object"
            f"{self.object.name} at slot {self.slot_index}"
        )

        try:
            self.object.material_slots[self.slot_index].material = (
                self.material
            )
        except IndexError:
            neologging.warning(
                f"Invalid material slot index: {self.slot_index}"
            )


class MaterialSlotsOverwrite(GlobalCollectionPropertyItem):
    """Material Slots Overwrite Item. Contains a list of
    material slots that will be applied to the object."""

    global_id: bpy.props.StringProperty()  # type:ignore

    object: bpy.props.PointerProperty(type=bpy.types.Object)  # type:ignore
    material_slots: bpy.props.CollectionProperty(
        type=MaterialSlot
    )  # type:ignore
    material_slots_index: bpy.props.IntProperty(default=0)  # type:ignore

    def _apply(self, scene: Scene):
        """Apply visibility to object."""
        for material_slot in self.material_slots:
            material_slot.apply(scene)

    def clear(self):
        """Clear material slots."""
        self.material_slots.clear()


entity_classes = (
    CustomProperty,
    ObjectTransform,
    CustomPropertyCategory,
    CollectionVisibility,
    MaterialSlot,
    MaterialSlotsOverwrite,
    ObjectVisibility,
    ObjectAction,
)
