# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

from typing import Iterator

import bpy

from ...libs import neologging


def get_viewlayer_collection(
    collection: bpy.types.Collection,
) -> bpy.types.LayerCollection | None:
    """Get view layer collection."""

    def get_all_children(
        col: bpy.types.LayerCollection,
    ) -> Iterator[bpy.types.LayerCollection]:
        """Get all children from collection."""
        yield col
        for child in col.children:
            yield from get_all_children(child)

    view_layer = bpy.context.view_layer
    for layer_col in reversed(
        list(get_all_children(view_layer.layer_collection))
    ):
        if layer_col.collection == collection:
            return layer_col
    return None


def safe_viewport_state_switch():
    """Switch to solid mode if the current mode is not solid."""

    for area in bpy.context.screen.areas:
        if area.type == "VIEW_3D":
            for space in area.spaces:
                if space.type == "VIEW_3D":
                    if space.shading.type in ("RENDERED", "MATERIAL"):
                        space.shading.type = "SOLID"


def get_collection_properties_items_recursive(
    collection_property: bpy.types.bpy_prop_collection,
) -> list[bpy.types.PropertyGroup]:
    """Get collection properties recursively."""

    properties = []

    for col_item in collection_property:
        properties.append(col_item)
        for annonation in col_item.__annotations__:
            prop = getattr(col_item, annonation)
            if isinstance(prop, bpy.types.bpy_prop_collection):
                properties.extend(
                    get_collection_properties_items_recursive(prop)
                )

    return properties


def get_bl_data(
    id_data_pointer: bpy.types.ID, path_from_id: str
) -> bpy.types.ID | None:
    """Get bl Data"""

    try:
        id_data = id_data_pointer
        if path_from_id:  # pylint: disable=using-constant-test
            id_data = id_data_pointer.path_resolve(path_from_id)
        return id_data
    except ValueError:
        neologging.warning(f"Invalid path from id: {path_from_id}")
        return None


def get_bl_prop_value(
    id_data_pointer: bpy.types.ID, path_from_id: str, identifier: str
) -> str | None:
    """Get prop value"""

    try:
        return getattr(get_bl_data(id_data_pointer, path_from_id), identifier)
    except AttributeError:
        neologging.warning(f"Invalid identifier: {identifier}")
        return None
