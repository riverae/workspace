# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

"""Properties for the addon."""

import uuid

import bpy
from bpy.types import Scene
from mathutils import Vector

from ...libs import neologging
from ...utils import get_prefs
from .entity import (
    CustomPropCategoryData,
    CustomProperty,
    CustomPropertyCategory,
    GlobalCollectionPropertyItem,
    entity_classes,
)
from .global_properties import (
    AnimationGlobalProps,
    CameraGlobalProps,
    CollectionVisibilityGlobalProps,
    ColorManagementGlobalProps,
    CustomPropertiesGlobalProps,
    GlobalSceneStateProperties,
    MaterialSlotsOverwriteGlobalProps,
    ObjectsActionGlobalProps,
    ObjectsTransformGlobalProps,
    ObjectsVisibilityGlobalProps,
    OutputGlobalProps,
    RenderGlobalProps,
    RenderRegionGlobalProps,
    ResolutionGlobalProps,
    SceneModifierGlobalProps,
    SimplifyGlobalProps,
    WorldGlobalProps,
)
from .scene_modifiers import EZS_SceneStates, scene_modifiers
from .utils import get_collection_properties_items_recursive, safe_viewport_state_switch


def _get_default_scene_state_name(scene: Scene) -> str:
    """Get default scene_state name based on index."""

    default_name = "Scene State"

    used_indexes: list[int] = []
    for scene_state in get_scene_state_manager(scene).scene_states:
        if default_name in scene_state.name:

            default_name_num = scene_state.name.split()[-1]
            if default_name_num.isnumeric():
                used_indexes.append(int(scene_state.name.split()[-1]))

    used_indexes.sort()
    possible_index = 1

    while True:
        if possible_index not in used_indexes:
            return f"{default_name} {possible_index}"
        possible_index += 1


class EZS_SceneStatesManager(bpy.types.PropertyGroup):
    """Scene States Manager."""

    # If empty, a load_post handler will set it to the scene render output
    render_output: bpy.props.StringProperty(
        default="", name="Render Output", subtype="DIR_PATH"
    )  # type:ignore
    
    enable_selection : bpy.props.BoolProperty(
        default=True,
        name="Enable Selection",
        description="Enable selection of scene states.",
    )  # type:ignore

    scene_states: bpy.props.CollectionProperty(
        type=EZS_SceneStates
    )  # type:ignore

    scene_states_index: bpy.props.IntProperty(
        update=lambda self, context: self.activate_by_idx(  # type:ignore
            context.scene, self.scene_states_index
        )
    )  # type:ignore

    sync_scene_values: bpy.props.BoolProperty(
        default=False,
        name="Sync Scene Values",
        description="Automatically update all scene modifiers with the current scene values when switching between scene states.",
    )  # type:ignore

    skip_next_sync: bpy.props.BoolProperty(
        default=False,
        name="Skip Next Sync",
        description="Skip the next sync when switching between scene states.",
    )  # type:ignore

    last_scene_states_index: bpy.props.IntProperty(default=-1)  # type:ignore

    global_properties: bpy.props.PointerProperty(
        type=GlobalSceneStateProperties
    )  # type:ignore

    # ------------------------------------------------
    # Scene States Management
    # ------------------------------------------------

    def get_active(self) -> EZS_SceneStates | None:
        """Get active scene_state."""
        return self.get_by_index(self.scene_states_index)

    def get_all(self) -> list[EZS_SceneStates]:
        """Get all scene states."""
        return list(self.scene_states)
    
    def get_selected(self) -> list[EZS_SceneStates]:
        """Get selected scene states."""
        if not self.enable_selection:
            return []
        return [state for state in self.scene_states if state.selected]

    def get_by_index(self, index: int) -> EZS_SceneStates | None:
        """Get scene_state by index."""

        if index < 0 or index >= len(self.scene_states):
            return None

        return self.scene_states[index]

    def add(
        self,
        scene: Scene,
        name: str = "",
        camera: bpy.types.Object | None = None,
    ) -> EZS_SceneStates:
        """Add Scene State."""
        new_scene_state: EZS_SceneStates = self.scene_states.add()
        current_scene_state: EZS_SceneStates | None = self.get_active()

        if not name:
            name = _get_default_scene_state_name(bpy.context.scene)

        new_scene_state.id = uuid.uuid4().hex
        new_scene_state.name = name

        camera_modifier = new_scene_state.camera_modifier

        camera_modifier.block_update = True
        camera_modifier.camera = camera
        camera_modifier.block_update = False

        new_scene_state.load_scene_values(
            scene,
            self.global_properties,
            current_scene_state,
            create_global_items=True,
        )

        prefs = get_prefs()
        if prefs.store_camera_loc_roc_by_default:
            camera_modifier.store_camera_loc_rot = True

        # Activate new scene state
        self.scene_states_index = len(self.scene_states) - 1
        return new_scene_state

    def get_by_id(self, scene_state_id: str) -> EZS_SceneStates | None:
        """Get Scene State by ID."""
        for scene_state in self.scene_states:
            if scene_state.id == scene_state_id:
                return scene_state
        return None
    
    def move_up(self, index: int):
        """Move Scene State Up."""
        
        if index < 0:
            return False

        if not self.scene_states:
            return False

        if index == 0:
            return False
        
        self.skip_next_sync = True
        self.scene_states.move(
            index, index - 1
        )
        self.scene_states_index -= 1
        
        return True
    
    def move_down(self, index: int):
        """Move Scene State Down."""
        
        if index < 0:
            return False
        if not self.scene_states:
            return False
        if index == len(self.scene_states) - 1:
            return False

        self.skip_next_sync = True
        self.scene_states.move(
            index, index + 1
        )
        self.scene_states_index += 1

        return True

    def remove(self, index: int):
        """Remove Scene State."""
        self.skip_next_sync = True
        self.scene_states.remove(index)

    def clear(self):
        """Clear all scene states."""
        self.scene_states.clear()

    def activate_by_id(self, scene: Scene, scene_state_id: str):
        """Activate Scene State by ID."""
        for scene_state in self.scene_states:
            if scene_state.id == scene_state_id:
                scene_state.apply(scene, self.global_properties)
                break

    def activate_by_idx(
        self, scene: Scene, index: int, skip_sync: bool = False
    ):
        """Activate Scene State"""

        if get_prefs().safe_viewport_state_switch:
            safe_viewport_state_switch()

        if self.sync_scene_values:

            if self.skip_next_sync:
                self.skip_next_sync = False
            else:
                last_scene_state = self.get_by_index(
                    self.last_scene_states_index
                )
                if last_scene_state is not None:
                    last_scene_state.load_scene_values(
                        scene, self.global_properties, None, False
                    )

        scene_state: EZS_SceneStates = self.scene_states[index]
        scene_state.apply(scene, self.global_properties)

        self.last_scene_states_index = index

    # ------------------------------------------------
    # Global Properties Management
    # ------------------------------------------------
    
    # These methods are responsible to create a new global item in the scene state
    # and add it to the global properties as well. but this behavior is not beign 
    # used for now, check the DEVELOPMENT.md file (23/11/2024).

    def add_object_visibility(
        self,
        adding_obj: bpy.types.Object,
        hide_viewport: bool = False,
        hide_render: bool = False,
    ) -> bool:
        """Add object visibility item to global and each scene_state.

        Returns:
            Always True
        """
        global_properties: GlobalSceneStateProperties = self.global_properties
        global_obj = global_properties.objects_visibility_modifier.add_object_visibility(
            adding_obj, hide_viewport, hide_render
        )
        if global_obj is None:
            return False

        for scene_state in self.scene_states:
            scene_state_obj = (
                scene_state.objects_visibility_modifier.objects_visibility.add()
            )
            scene_state_obj.copy_from(global_obj)

        return True

    def add_object_action(
        self,
        adding_obj: bpy.types.Object,
        action: bpy.types.Action | None = None,
    ) -> bool:
        """Add object action item to global and each scene_state.

        Returns:
            Always True
        """
        global_properties: GlobalSceneStateProperties = self.global_properties
        global_obj = (
            global_properties.objects_action_modifier.add_object_action(
                adding_obj, action
            )
        )
        if global_obj is None:
            return False

        for scene_state in self.scene_states:
            scene_state_obj = (
                scene_state.objects_action_modifier.objects_action.add()
            )
            scene_state_obj.copy_from(global_obj)

        return True

    def add_object_transform(
        self,
        adding_obj: bpy.types.Object,
        location: Vector,
        rotation_euler: Vector,
        scale: Vector,
    ) -> bool:
        """Add object transform item to global and each scene_state.

        Returns:
            Always True
        """

        global_properties: GlobalSceneStateProperties = self.global_properties
        global_obj = (
            global_properties.objects_transform_modifier.add_object_transform(
                adding_obj, location, rotation_euler, scale
            )
        )
        if global_obj is None:
            return False

        for scene_state in self.scene_states:
            scene_state_obj = (
                scene_state.objects_transform_modifier.objects_transform.add()
            )
            scene_state_obj.copy_from(global_obj)

        return True

    def add_collection_visibility(
        self, collection: bpy.types.Collection
    ) -> bool:
        """Add collection visibility item to global and each scene_state.

        Returns:
            bool: True if collection was added, False otherwise
                (Collection already exists in global scene_state properties)
        """

        global_properties: GlobalSceneStateProperties = self.global_properties
        global_col = global_properties.collection_visibility_modifier.add_collection_visibility(
            collection
        )

        if global_col is None:
            return False

        for scene_state in self.scene_states:
            scene_state_col = (
                scene_state.collection_visibility_modifier.collections_visibility.add()
            )
            scene_state_col.copy_from(global_col)

        return True

    def add_material_slots_overwrite(
        self,
        adding_obj: bpy.types.Object,
    ) -> bool:
        """Add a material slots overwrite item to global and each scene_state.
        Returns:
            bool: Always True
        """

        # Adding to global scene_state properties
        global_properties: GlobalSceneStateProperties = self.global_properties
        global_obj = global_properties.material_slots_overwrite_modifier.add_material_slots_overwrite(
            adding_obj
        )

        if global_obj is None:
            return False

        # Adding for each scene_state
        for scene_state in self.scene_states:
            scene_state_obj = (
                scene_state.material_slots_overwrite_modifier.overwrites.add()
            )
            scene_state_obj.copy_from(global_obj)

        return True

    def add_material_slot(self, obj: bpy.types.Object, slot_index: int):
        """Add a MaterialSlot to a specific MaterialSlotsOverwrite
        in global and each scene_state."""

        global_properties: GlobalSceneStateProperties = self.global_properties
        global_obj = global_properties.material_slots_overwrite_modifier.add_material_slot(
            obj, slot_index
        )

        for scene_state in self.scene_states:
            scene_state_obj = (
                scene_state.material_slots_overwrite_modifier.get_object(obj)
            )
            if not scene_state_obj:
                raise ValueError("EasyStates: Material slots object not found")

            scene_state_new_slot = scene_state_obj.material_slots.add()
            scene_state_new_slot.copy_from(global_obj)

        return True

    def add_custom_property(
        self,
        id_data: bpy.types.ID,
        path_from_id: str,
        identifier: str,
    ) -> bool:
        """Add custom property to global and each scene_state."""

        global_properties: GlobalSceneStateProperties = self.global_properties
        custom_properties_global_props = (
            global_properties.custom_properties_modifier
        )

        global_prop = custom_properties_global_props.add_custom_property(
            id_data, path_from_id, identifier
        )

        if global_prop is None:
            return False
        for scene_state in self.scene_states:
            custom_property: CustomProperty = (
                scene_state.custom_properties_modifier.custom_properties.add()
            )

            custom_property.copy_from(global_prop)
            custom_property.set_prop_default_value()

        self.update_custom_property_categories()
        return True

    def remove_global_id(self, global_id: str) -> bool:
        """Remove any GlobalCollectionPropertyItem by global_id.

        Returns:
            bool: True if item was removed, False otherwise
        """
        global_col_props = self.get_all_global_collection_properties()

        for col in global_col_props:
            for idx, item in enumerate(col):
                if hasattr(item, "global_id") and item.global_id == global_id:
                    neologging.info(
                        f"Removing {item} with global_id {global_id} from {col}"
                    )
                    col.remove(idx)

        return False

    # ------------------------------------------------
    # Global Properties Utils
    # ------------------------------------------------

    def repair_custom_property(
        self,
        global_id: str,
        id_data: bpy.types.ID,
        path_from_id: str,
        identifier: str,
    ):
        """Update custom property from global and each scene_state."""

        global_properties: GlobalSceneStateProperties = self.global_properties

        global_prop = (
            global_properties.custom_properties_modifier.get_custom_property(
                global_id
            )
        )
        if global_prop is None:
            return False

        global_prop.id_data_pointer = id_data
        global_prop.path_from_id = path_from_id
        global_prop.identifier = identifier
        global_prop.invalid_path = False
        global_prop.invalid_value = False
        global_prop.invalid_identifier = False

        bl_data = global_prop.get_bl_data()
        if bl_data is None:
            raise ValueError("EasyStates: Custom property value is None")

        for scene_state in self.scene_states:
            custom_property: CustomProperty = (
                scene_state.custom_properties_modifier.get_custom_property(
                    global_id
                )
            )
            if custom_property is None:
                continue
            custom_property.id_data_pointer = global_prop.id_data_pointer
            custom_property.path_from_id = global_prop.path_from_id
            custom_property.identifier = global_prop.identifier
            custom_property.invalid_path = False
            custom_property.invalid_value = False
            custom_property.invalid_identifier = False

        self.update_custom_property_categories()
        return True

    def update_custom_property_categories(self) -> None:
        """Update existing categories from all custom properties instances.

        Categories are generated from id_data names, so if id_data name changes,
        categories will be updated as well.
        """

        registered_categories: list[CustomPropCategoryData] = []

        custom_properties_global_props = (
            self.global_properties.custom_properties_modifier
        )

        global_items = custom_properties_global_props.global_items

        for custom_property in global_items:
            cat: CustomPropCategoryData = (
                custom_property.save_updated_category()
            )
            if not cat in registered_categories:
                registered_categories.append(cat)

        for scene_state in self.scene_states:
            for (
                custom_property
            ) in scene_state.custom_properties_modifier.custom_properties:
                cat: CustomPropCategoryData = (
                    custom_property.save_updated_category()
                )
                if not cat in registered_categories:
                    registered_categories.append(cat)

        custom_properties_global_props.registered_cp_categories.clear()

        for cat in registered_categories:
            new_cat: CustomPropertyCategory = (
                custom_properties_global_props.registered_cp_categories.add()
            )
            new_cat.name = cat.name
            new_cat.icon_name = cat.icon_name

        custom_properties_global_props.custom_properties_categories = "ALL"

    def get_selected_custom_property(self) -> CustomProperty | None:
        """Get selected custom property."""

        active_state = self.get_active()
        if not active_state:
            neologging.error("No active scene state.")
            return None

        custom_properties_modifier = active_state.custom_properties_modifier

        custom_property_index = (
            custom_properties_modifier.custom_properties_index
        )

        if custom_property_index < 0:
            neologging.error("No custom property selected.")
            return None

        try:
            custom_property = custom_properties_modifier.custom_properties[
                custom_property_index
            ]
        except IndexError:
            neologging.error("Custom property not found.")
            return None

        return custom_property

    def get_all_global_collection_properties(
        self, scene_state_id : str = ""
    ) -> list[bpy.types.bpy_prop_collection]:
        """Get all registered global collection properties
        inside each state set and global properties.
        
        Args:
            scene_state_id (str, optional): Scene state id to get collection properties from. 
            If empty, will get from all scene states. Defaults to "".
        """

        # FIXME This code is bad, should use recursion to get all collection properties
        all_col_props = []

        for state_set in self.scene_states:
            if scene_state_id and state_set.id != scene_state_id:
                continue
            for annotation in state_set.__annotations__:
                if not annotation.endswith("_modifier"):
                    continue

                state_set_prop = getattr(state_set, annotation)
                for mod_annotation in state_set_prop.__annotations__:
                    mod_prop = getattr(state_set_prop, mod_annotation)
                    if isinstance(mod_prop, bpy.types.bpy_prop_collection):
                        all_col_props.append(mod_prop)
                        for col_item in mod_prop:
                            for annontation in col_item.__annotations__:
                                prop = getattr(col_item, annontation)
                                if isinstance(
                                    prop, bpy.types.bpy_prop_collection
                                ):
                                    all_col_props.append(prop)
        
        # If the scene state id is provided,
        # return only the collection properties from that state set    
        # Global collection properties should not be returned
        if not scene_state_id:  
            for annotation in self.global_properties.__annotations__:
                global_mod_prop = getattr(self.global_properties, annotation)
                if not isinstance(global_mod_prop, SceneModifierGlobalProps):
                    continue

                for mod_annotation in global_mod_prop.__annotations__:
                    mod_prop = getattr(global_mod_prop, mod_annotation)
                    if not isinstance(mod_prop, bpy.types.bpy_prop_collection):
                        continue
                    all_col_props.append(mod_prop)
                    for col_item in mod_prop:
                        for annontation2 in col_item.__annotations__:
                            prop = getattr(col_item, annontation2)
                            if isinstance(prop, bpy.types.bpy_prop_collection):
                                all_col_props.append(prop)

        return all_col_props

    def get_all_global_collection_property_items(
        self, scene_state_id: str = ""
    ) -> list[GlobalCollectionPropertyItem]:
        """Get all global collection items
        inside each state set and global properties.
        
        Agrs:
            scene_state_id (str, optional): Scene state id to get collection properties from.
            If empty, will get from all scene states. Defaults to "".
        """

        all_col_props = self.get_all_global_collection_properties(scene_state_id)
        all_col_items = []

        for col_props in all_col_props:
            all_col_items.extend(
                get_collection_properties_items_recursive(col_props)
            )

        global_collection_items = []
        for col_props in all_col_items:
            if isinstance(col_props, GlobalCollectionPropertyItem):
                global_collection_items.append(col_props)

        return global_collection_items


def get_scene_state_manager(scene: Scene) -> EZS_SceneStatesManager:
    """Get addon properties."""
    return scene.easystates_manager


classes = (
    CameraGlobalProps,
    ObjectsActionGlobalProps,
    WorldGlobalProps,
    ResolutionGlobalProps,
    ObjectsTransformGlobalProps,
    OutputGlobalProps,
    RenderGlobalProps,
    ColorManagementGlobalProps,
    CollectionVisibilityGlobalProps,
    MaterialSlotsOverwriteGlobalProps,
    CustomPropertiesGlobalProps,
    RenderRegionGlobalProps,
    SimplifyGlobalProps,
    AnimationGlobalProps,
    ObjectsVisibilityGlobalProps,
    GlobalSceneStateProperties,
    EZS_SceneStates,
    EZS_SceneStatesManager,
)


def register():
    """Register properties."""

    from bpy.utils import register_class

    for cls in entity_classes:
        register_class(cls)
    for cls in scene_modifiers:
        register_class(cls)
    for cls in classes:
        register_class(cls)

    bpy.types.Scene.easystates_manager = bpy.props.PointerProperty(
        type=EZS_SceneStatesManager
    )


def unregister():
    """Unregister properties."""

    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
    for cls in reversed(scene_modifiers):
        unregister_class(cls)
    for cls in reversed(entity_classes):
        unregister_class(cls)

    del bpy.types.Scene.easystates_manager
