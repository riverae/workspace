# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import builtins
import traceback
import uuid

import bpy
import mathutils

from ...libs import neologging
from .entity import (
    CollectionVisibility,
    CustomProperty,
    CustomPropertyCategory,
    MaterialSlot,
    MaterialSlotsOverwrite,
    ObjectAction,
    ObjectTransform,
    ObjectVisibility,
)


def generate_global_id() -> str:
    """Generate a global id."""
    return uuid.uuid4().hex


class SceneModifierGlobalProps(bpy.types.PropertyGroup):
    """Objects Visibility Properties."""

    enabled: bpy.props.BoolProperty(
        name="Use",
        default=False,
    )  # type:ignore

    expand: bpy.props.BoolProperty(
        name="Expand",
        default=False,
    )  # type:ignore

    icon: bpy.props.StringProperty(
        name="Icon",
        default="NONE",
    )  # type:ignore

    modifier_name: bpy.props.StringProperty(
        name="Name",
        default="",
    )  # type:ignore

    def clear(self):
        self._clear()

    def _clear(self):
        raise NotImplementedError("Method not implemented")


class CameraGlobalProps(SceneModifierGlobalProps):
    """Camera Modifier Properties."""

    icon: bpy.props.StringProperty(default="CAMERA_DATA")  # type:ignore
    modifier_name: bpy.props.StringProperty(default="Camera")  # type:ignore

    # Forcing this modifier to be True by default
    enabled: bpy.props.BoolProperty(
        name="Use",
        default=True,
    )  # type:ignore

    def _clear(self):
        pass


class WorldGlobalProps(SceneModifierGlobalProps):
    """World Modifier Properties."""

    icon: bpy.props.StringProperty(default="WORLD_DATA")  # type:ignore
    modifier_name: bpy.props.StringProperty(default="World")  # type:ignore

    def _clear(self):
        pass


class ResolutionGlobalProps(SceneModifierGlobalProps):
    """Resolution Modifier Properties."""

    icon: bpy.props.StringProperty(default="IMAGE_PLANE")  # type:ignore
    modifier_name: bpy.props.StringProperty(
        default="Resolution"
    )  # type:ignore

    def _clear(self):
        pass


class OutputGlobalProps(SceneModifierGlobalProps):
    """Output Modifier Properties."""

    icon: bpy.props.StringProperty(default="OUTPUT")  # type:ignore
    modifier_name: bpy.props.StringProperty(default="Output")  # type:ignore

    def _clear(self):
        pass


class RenderGlobalProps(SceneModifierGlobalProps):
    """Render Modifier Properties."""

    icon: bpy.props.StringProperty(default="SCENE")  # type:ignore
    modifier_name: bpy.props.StringProperty(default="Render")  # type:ignore

    def _clear(self):
        pass


class ColorManagementGlobalProps(SceneModifierGlobalProps):
    """Color Management Modifier Properties."""

    icon: bpy.props.StringProperty(default="COLOR")  # type:ignore
    modifier_name: bpy.props.StringProperty(
        default="Color Management"
    )  # type:ignore

    def _clear(self):
        pass


class CollectionVisibilityGlobalProps(SceneModifierGlobalProps):
    """Collection Visibility Modifier Properties."""

    icon: bpy.props.StringProperty(default="COLLECTION_NEW")  # type:ignore
    modifier_name: bpy.props.StringProperty(
        default="Collection Visibility"
    )  # type:ignore

    global_items: bpy.props.CollectionProperty(
        type=CollectionVisibility,
    )  # type:ignore

    use_exclude: bpy.props.BoolProperty(
        name="Exclude",
        default=False,
    )  # type:ignore

    use_hide_select: bpy.props.BoolProperty(
        name="Hide Select",
        default=False,
    )  # type:ignore

    use_hide_viewport_layer: bpy.props.BoolProperty(
        name="Hide Viewport",
        default=False,
    )  # type:ignore

    use_hide_viewport: bpy.props.BoolProperty(
        name="Hide Viewport Layer",
        default=True,
    )  # type:ignore

    use_hide_render: bpy.props.BoolProperty(
        name="Hide Render",
        default=True,
    )  # type:ignore

    use_holdout: bpy.props.BoolProperty(
        name="Holdout",
        default=False,
    )  # type:ignore

    use_indirect_only: bpy.props.BoolProperty(
        name="Indirect Only",
        default=False,
    )  # type:ignore

    def add_collection_visibility(
        self, collection: bpy.types.Collection
    ) -> CollectionVisibility | None:
        """Add collection visibility by collection.

        Returns:
            None if collection already exists. Otherwise, the new collection visibility.
        """
        for item in self.global_items:
            if item.collection == collection:
                return None

        global_col: CollectionVisibility = self.global_items.add()
        global_col.block_update = True

        global_col.global_id = generate_global_id()
        global_col.collection = collection
        global_col.hide_viewport = collection.hide_viewport
        global_col.hide_render = collection.hide_render
        global_col.block_update = False

        return global_col

    def _clear(self):
        self.global_items.clear()


class MaterialSlotsOverwriteGlobalProps(SceneModifierGlobalProps):
    """Material Slots Overwrite Modifier Properties."""

    icon: bpy.props.StringProperty(default="MATERIAL")  # type:ignore
    modifier_name: bpy.props.StringProperty(
        default="Material Slots Overwrite"
    )  # type:ignore

    global_items: bpy.props.CollectionProperty(
        type=MaterialSlotsOverwrite,
    )  # type:ignore

    def add_material_slots_overwrite(
        self, obj: bpy.types.Object
    ) -> MaterialSlotsOverwrite | None:
        """Add material slots overwrite by object."""

        for item in self.global_items:
            if item.object == obj:
                return None

        global_obj = self.global_items.add()
        global_obj.global_id = generate_global_id()
        global_obj.object = obj

        return global_obj

    def add_material_slot(
        self,
        obj: bpy.types.Object,
        slot_index: int,
    ) -> MaterialSlot:
        """Add material slot to overwrite by object."""

        obj_overwrite: MaterialSlotsOverwrite | None = None
        for item in self.global_items:
            if item.object == obj:
                obj_overwrite = item
        if not obj_overwrite:
            raise ValueError("EasyStates: Material slots object not found")

        new_slot: MaterialSlot = obj_overwrite.material_slots.add()
        new_slot.global_id = generate_global_id()
        new_slot.material = None
        new_slot.object = obj
        new_slot.slot_index = slot_index

        return new_slot

    def _clear(self):
        for i in self.global_items:
            i.material_slots.clear()
        self.global_items.clear()


class CustomPropertiesGlobalProps(SceneModifierGlobalProps):
    """Custom Properties Modifier Properties."""

    icon: bpy.props.StringProperty(default="PROPERTIES")  # type:ignore

    modifier_name: bpy.props.StringProperty(
        default="Custom Properties"
    )  # type:ignore

    global_items: bpy.props.CollectionProperty(
        type=CustomProperty,
    )  # type:ignore

    custom_properties_categories: bpy.props.EnumProperty(
        items=lambda self, context: self._get_enum_items_cp_categories(),  # type:ignore
    )  # type:ignore

    registered_cp_categories: bpy.props.CollectionProperty(
        type=CustomPropertyCategory
    )  # type:ignore

    def register_custom_property_category(
        self, name: str, icon_name: str = ""
    ) -> CustomPropertyCategory:
        """Register category."""

        for cat in self.registered_cp_categories:
            if cat.name == name:
                return cat

        category = self.registered_cp_categories.add()
        category.name = name
        category.icon_name = icon_name

        return category

    def cleanup_registered_cp_categories(self) -> None:
        """Cleanup registered categories."""

        for idx, cat in enumerate(self.registered_cp_categories):
            if not any(
                cp.category_name == cat.name for cp in self.custom_properties
            ):
                self.registered_cp_categories.remove(idx)
                self.custom_properties_categories = "ALL"

    def _get_enum_items_cp_categories(
        self,
    ) -> list[tuple[str, str, str]]:

        global_enum_items_cp_categories.clear()
        global_enum_items_cp_categories.append(("ALL", "All", "", "", 0))

        for idx, cat in enumerate(self.registered_cp_categories):
            global_enum_items_cp_categories.append(
                (cat.name, cat.name, "", cat.icon_name, idx + 1)
            )

        return global_enum_items_cp_categories

    def add_custom_property(
        self,
        id_data: bpy.types.ID,
        path_from_id: str,
        identifier: str,
    ) -> CustomProperty | None:
        """Add custom property to global properties."""

        global_prop: CustomProperty = self.global_items.add()

        global_prop.global_id = uuid.uuid4().hex
        global_prop.id_data_pointer = id_data
        global_prop.path_from_id = path_from_id
        global_prop.identifier = identifier
        global_prop.name = global_prop.get_prop_default_name()

        bl_prop_value = global_prop.get_bl_prop_value()
        if bl_prop_value is None:
            neologging.warning("EasyStates: Custom property has no value")
            return None

        global_prop.value_type = _get_property_value_type(bl_prop_value)
        global_prop.set_prop_default_value()

        bl_data = global_prop.get_bl_data()
        if bl_data is None:
            raise ValueError("EasyStates: Custom property value is None")

        return global_prop

    def get_custom_property(self, global_id: str) -> CustomProperty | None:
        """Get custom property by global id."""
        for cp in self.global_items:
            if cp.global_id == global_id:
                return cp
        return None

    def _clear(self):
        self.global_items.clear()


class ObjectsVisibilityGlobalProps(SceneModifierGlobalProps):
    """Objects Visibility Properties."""

    icon: bpy.props.StringProperty(default="OBJECT_DATAMODE")  # type:ignore

    modifier_name: bpy.props.StringProperty(
        default="Objects Visibility"
    )  # type:ignore

    global_items: bpy.props.CollectionProperty(
        type=ObjectVisibility,
    )  # type:ignore

    sync_selection: bpy.props.BoolProperty(
        name="Sync Selection",
        default=False,
    )  # type:ignore

    use_hide_select: bpy.props.BoolProperty(
        name="Hide Select",
        default=False,
    )  # type:ignore

    use_hide_set: bpy.props.BoolProperty(
        name="Hide Viewport (Eye Icon)",
        default=True,
    )  # type:ignore

    use_hide_viewport: bpy.props.BoolProperty(
        name="Hide Viewport Layer",
        default=True,
    )  # type:ignore

    use_hide_render: bpy.props.BoolProperty(
        name="Hide Render",
        default=True,
    )  # type:ignore

    def add_object_visibility(
        self, obj: bpy.types.Object, hide_viewport: bool, hide_render: bool
    ) -> ObjectVisibility | None:
        """Add object visibility by object.

        Returns:
            None if object already exists. Otherwise, the new object visibility.
        """
        for item in self.global_items:
            if item.object == obj:
                return None

        global_obj: ObjectVisibility = self.global_items.add()
        global_obj.block_update = True

        global_obj.global_id = generate_global_id()
        global_obj.object = obj
        global_obj.hide_viewport = hide_viewport
        global_obj.hide_render = hide_render

        global_obj.block_update = False

        return global_obj

    def _clear(self):
        self.global_items.clear()


class ObjectsActionGlobalProps(SceneModifierGlobalProps):
    """Objects Visibility Properties."""

    icon: bpy.props.StringProperty(default="ACTION")  # type:ignore

    modifier_name: bpy.props.StringProperty(
        default="Objects Action"
    )  # type:ignore

    global_items: bpy.props.CollectionProperty(
        type=ObjectAction,
    )  # type:ignore

    def add_object_action(
        self, obj: bpy.types.Object, action: bpy.types.Action
    ) -> ObjectAction | None:
        """Add object visibility by object.

        Returns:
            None if object already exists. Otherwise, the new object visibility.
        """
        for item in self.global_items:
            if item.object == obj:
                return None

        global_obj: ObjectAction = self.global_items.add()
        global_obj.block_update = True

        global_obj.global_id = generate_global_id()
        global_obj.object = obj
        global_obj.action = action

        global_obj.block_update = False

        return global_obj

    def _clear(self):
        self.global_items.clear()


class ObjectsTransformGlobalProps(SceneModifierGlobalProps):
    """Objects Transform Properties."""

    icon: bpy.props.StringProperty(default="CON_LOCLIKE")  # type:ignore

    modifier_name: bpy.props.StringProperty(
        default="Objects Transform"
    )  # type:ignore

    global_items: bpy.props.CollectionProperty(
        type=ObjectTransform,
    )  # type:ignore

    def add_object_transform(
        self,
        obj: bpy.types.Object,
        location: mathutils.Vector,
        rotation_euler: mathutils.Vector,
        scale: mathutils.Vector,
    ) -> ObjectTransform | None:
        """Add object transform by object.

        Returns:
            None if object already exists. Otherwise, the new object transform.
        """
        for item in self.global_items:
            if item.object == obj:
                return None

        global_obj: ObjectTransform = self.global_items.add()
        global_obj.block_update = True

        global_obj.global_id = generate_global_id()
        global_obj.object = obj
        global_obj.location = location
        global_obj.rotation_euler = rotation_euler
        global_obj.scale = scale

        global_obj.block_update = False

        return global_obj

    def _clear(self):
        self.global_items.clear()


class RenderRegionGlobalProps(SceneModifierGlobalProps):
    """Render Region Modifier Properties."""

    icon: bpy.props.StringProperty(default="SELECT_SET")  # type:ignore
    modifier_name: bpy.props.StringProperty(
        default="Render Region"
    )  # type:ignore

    def _clear(self):
        return


class SimplifyGlobalProps(SceneModifierGlobalProps):
    """Simplify Modifier Properties."""

    icon: bpy.props.StringProperty(default="MOD_REMESH")  # type:ignore
    modifier_name: bpy.props.StringProperty(default="Simplify")  # type:ignore

    def _clear(self):
        return


class AnimationGlobalProps(SceneModifierGlobalProps):
    """Animation Modifier Properties."""

    icon: bpy.props.StringProperty(default="RENDER_ANIMATION")  # type:ignore
    modifier_name: bpy.props.StringProperty(
        default="Render Animation"
    )  # type:ignore

    def _clear(self):
        return


def _get_property_value_type(value: str) -> str:
    """Return an valid enum value from scene_modifiers.CustomProperty.value_type"""

    match type(value):
        case bpy.types.bpy_prop_array:
            size = len(value)
            if size == 4:
                return "ARRAY4COLOR"
            return "ARRAY" + str(size)
        case mathutils.Color:
            return "ARRAY3COLOR"
        case mathutils.Vector:
            return "ARRAY3"
        case mathutils.Euler:
            return "ARRAY3"
        case builtins.int:
            return "INT"
        case builtins.float:
            return "FLOAT"
        case builtins.str:
            return "STRING"
        case builtins.bool:
            return "BOOL"
        case _:
            raise ValueError(
                "EasyStates: Unsupported data type -> " + str(type(value))
            )


global_enum_items_cp_categories = []


class GlobalSceneStateProperties(bpy.types.PropertyGroup):
    """Universal Scene State Properties."""

    animation_modifier: bpy.props.PointerProperty(
        type=AnimationGlobalProps,
    )  # type:ignore

    camera_modifier: bpy.props.PointerProperty(
        type=CameraGlobalProps,
    )  # type:ignore

    collection_visibility_modifier: bpy.props.PointerProperty(
        type=CollectionVisibilityGlobalProps,
    )  # type:ignore

    color_management_modifier: bpy.props.PointerProperty(
        type=ColorManagementGlobalProps,
    )  # type:ignore

    custom_properties_modifier: bpy.props.PointerProperty(
        type=CustomPropertiesGlobalProps,
    )  # type:ignore

    material_slots_overwrite_modifier: bpy.props.PointerProperty(
        type=MaterialSlotsOverwriteGlobalProps,
    )  # type:ignore

    objects_action_modifier: bpy.props.PointerProperty(
        type=ObjectsActionGlobalProps,
    )  # type:ignore

    objects_transform_modifier: bpy.props.PointerProperty(
        type=ObjectsTransformGlobalProps,
    )  # type:ignore

    objects_visibility_modifier: bpy.props.PointerProperty(
        type=ObjectsVisibilityGlobalProps,
    )  # type:ignore

    output_modifier: bpy.props.PointerProperty(
        type=OutputGlobalProps,
    )  # type:ignore

    render_modifier: bpy.props.PointerProperty(
        type=RenderGlobalProps,
    )  # type:ignore

    render_region_modifier: bpy.props.PointerProperty(
        type=RenderRegionGlobalProps,
    )  # type:ignore

    resolution_modifier: bpy.props.PointerProperty(
        type=ResolutionGlobalProps,
    )  # type:ignore

    simplify_modifier: bpy.props.PointerProperty(
        type=SimplifyGlobalProps,
    )  # type:ignore

    world_modifier: bpy.props.PointerProperty(
        type=WorldGlobalProps,
    )  # type:ignore

    # ------------------------------------------------------
    # Old Properties <= 1.0.4
    # ------------------------------------------------------

    use_camera_modifier: bpy.props.BoolProperty(
        name="Use Camera Modifier",
        default=True,
    )  # type:ignore

    expand_camera_modifier: bpy.props.BoolProperty(
        name="Expand Camera Modifier",
        default=False,
    )  # type:ignore

    use_world_modifier: bpy.props.BoolProperty(
        name="Use World Modifier",
        default=False,
    )  # type:ignore

    expand_world_modifier: bpy.props.BoolProperty(
        name="Expand World Modifier",
        default=False,
    )  # type:ignore

    use_resolution_modifier: bpy.props.BoolProperty(
        name="Use Resolution Modifier",
        default=False,
    )  # type:ignore

    expand_resolution_modifier: bpy.props.BoolProperty(
        name="Expand Resolution Modifier",
        default=False,
    )  # type:ignore

    use_animation_modifier: bpy.props.BoolProperty(
        name="Use Animation Modifier",
        default=False,
    )  # type:ignore

    expand_animation_modifier: bpy.props.BoolProperty(
        name="Expand Animation Modifier",
        default=False,
    )  # type:ignore

    use_output_modifier: bpy.props.BoolProperty(
        name="Use Output Modifier",
        default=False,
    )  # type:ignore

    expand_output_modifier: bpy.props.BoolProperty(
        name="Expand Output Modifier",
        default=False,
    )  # type:ignore

    use_render_modifier: bpy.props.BoolProperty(
        name="Use Render Modifier",
        default=False,
    )  # type:ignore

    expand_render_modifier: bpy.props.BoolProperty(
        name="Expand Render Modifier",
        default=False,
    )  # type:ignore

    use_simplify_modifier: bpy.props.BoolProperty(
        name="Use Simplify Modifier",
        default=False,
    )  # type:ignore

    expand_simplify_modifier: bpy.props.BoolProperty(
        name="Expand Simplify Modifier",
        default=False,
    )  # type:ignore

    use_color_management_modifier: bpy.props.BoolProperty(
        name="Use Color Management Modifier",
        default=False,
    )  # type:ignore

    expand_color_management_modifier: bpy.props.BoolProperty(
        name="Expand Color Management Modifier",
        default=False,
    )  # type:ignore

    use_collection_visibility_modifier: bpy.props.BoolProperty(
        name="Use Collection Visibility Modifier",
        default=False,
    )  # type:ignore

    expand_collection_visibility_modifier: bpy.props.BoolProperty(
        name="Expand Collection Visibility Modifier",
        default=False,
    )  # type:ignore

    use_material_slots_overwrite_modifier: bpy.props.BoolProperty(
        name="Use Material Slots Overwrite Modifier",
        default=False,
    )  # type:ignore

    expand_material_slots_overwrite_modifier: bpy.props.BoolProperty(
        name="Expand Material Slots Overwrite Modifier",
        default=False,
    )  # type:ignore

    use_custom_properties_modifier: bpy.props.BoolProperty(
        name="Use Custom Properties Modifier",
        default=False,
    )  # type:ignore

    expand_custom_properties_modifier: bpy.props.BoolProperty(
        name="Expand Custom Properties Modifier",
        default=False,
    )  # type:ignore

    use_objects_visibility_modifier: bpy.props.BoolProperty(
        name="Use Objects Visibility Modifier",
        default=False,
    )  # type:ignore

    expand_objects_visibility_modifier: bpy.props.BoolProperty(
        name="Expand Objects Visibility Modifier",
        default=False,
    )  # type:ignore

    use_render_region_modifier: bpy.props.BoolProperty(
        name="Use Render Region Modifier",
        default=False,
    )  # type:ignore

    expand_render_region_modifier: bpy.props.BoolProperty(
        name="Expand Render Region Modifier",
        default=False,
    )  # type:ignore

    # ------------------------------------------------------
    # Scene Modifier Properties
    # ------------------------------------------------------

    sync_object_visibility_selection: bpy.props.BoolProperty(
        name="Sync Selection",
        default=False,
    )  # type:ignore

    # ------------------------------------------------------
    # Global Collection Items
    # ------------------------------------------------------

    collections_visibility: bpy.props.CollectionProperty(
        type=CollectionVisibility,
    )  # type:ignore

    objects_visibility: bpy.props.CollectionProperty(
        type=ObjectVisibility,
    )  # type:ignore

    overwrites: bpy.props.CollectionProperty(
        type=MaterialSlotsOverwrite,
    )  # type:ignore

    custom_properties: bpy.props.CollectionProperty(
        type=CustomProperty,
    )  # type:ignore

    def convert_legacy_properties(self) -> bool:
        """Convert old properties to new properties."""

        neologging.info(
            "EasyStates: Migrating global properties to new structure"
        )

        try:

            neologging.info("Camera Modifier", indent=1)
            self.camera_modifier.enabled = self.use_camera_modifier
            self.camera_modifier.expand = self.expand_camera_modifier

            neologging.info("Migrating World Modifier", indent=1)
            self.world_modifier.enabled = self.use_world_modifier
            self.world_modifier.expand = self.expand_world_modifier

            neologging.info("Migrating Resolution Modifier", indent=1)
            self.resolution_modifier.enabled = self.use_resolution_modifier
            self.resolution_modifier.expand = self.expand_resolution_modifier

            neologging.info("Migrating Output Modifier", indent=1)
            self.output_modifier.enabled = self.use_output_modifier
            self.output_modifier.expand = self.expand_output_modifier

            neologging.info("Migrating Render Modifier", indent=1)
            self.render_modifier.enabled = self.use_render_modifier
            self.render_modifier.expand = self.expand_render_modifier

            neologging.info("Migrating Color Management Modifier", indent=1)
            self.color_management_modifier.enabled = (
                self.use_color_management_modifier
            )
            self.color_management_modifier.expand = (
                self.expand_color_management_modifier
            )

            neologging.info(
                "Migrating Collection Visibility Modifier", indent=1
            )
            self.collection_visibility_modifier.enabled = (
                self.use_collection_visibility_modifier
            )
            self.collection_visibility_modifier.expand = (
                self.expand_collection_visibility_modifier
            )

            col_viz_global_items = (
                self.collection_visibility_modifier.global_items
            )
            col_viz_global_items.clear()

            for col_vis in self.collections_visibility:
                neologging.info(f"Clonning {str(col_vis)}", indent=2)

                new_col_vis = col_viz_global_items.add()
                new_col_vis.copy_from(col_vis)

            neologging.info(
                "Migrating Material Slots Overwrite Modifier", indent=1
            )
            self.material_slots_overwrite_modifier.enabled = (
                self.use_material_slots_overwrite_modifier
            )

            self.material_slots_overwrite_modifier.expand = (
                self.expand_material_slots_overwrite_modifier
            )

            overwrites_global_items = (
                self.material_slots_overwrite_modifier.global_items
            )
            overwrites_global_items.clear()

            for overwrite in self.overwrites:
                neologging.info(f"Clonning {str(overwrite)}", indent=2)

                new_obj = overwrites_global_items.add()
                new_obj.copy_from(overwrite)

            neologging.info("Migrating Custom Properties Modifier", indent=1)
            self.custom_properties_modifier.enabled = (
                self.use_custom_properties_modifier
            )
            self.custom_properties_modifier.expand = (
                self.expand_custom_properties_modifier
            )

            cp_global_items = self.custom_properties_modifier.global_items
            cp_global_items.clear()

            for cp in self.custom_properties:
                neologging.info(f"Clonning {str(cp)}", indent=2)
                new_cp = self.custom_properties_modifier.global_items.add()
                new_cp.copy_from(cp)

            neologging.info("Migrating Objects Visibility Modifier", indent=1)
            self.objects_visibility_modifier.enabled = (
                self.use_objects_visibility_modifier
            )
            self.objects_visibility_modifier.expand = (
                self.expand_objects_visibility_modifier
            )
            self.objects_visibility_modifier.sync_selection = (
                self.sync_object_visibility_selection
            )

            obj_viz_global_items = (
                self.objects_visibility_modifier.global_items
            )
            obj_viz_global_items.clear()

            for obj_vis in self.objects_visibility:
                neologging.info(f"Clonning {str(obj_vis)}", indent=2)
                new_obj_vis = obj_viz_global_items.add()
                new_obj_vis.copy_from(obj_vis)

            neologging.info("Migrating Render Region Modifier", indent=1)
            self.render_region_modifier.enabled = (
                self.use_render_region_modifier
            )
            self.render_region_modifier.expand = (
                self.expand_render_region_modifier
            )

            neologging.info("Migrating Simplify Modifier", indent=1)
            self.simplify_modifier.enabled = self.use_simplify_modifier
            self.simplify_modifier.expand = self.expand_simplify_modifier

            neologging.info("Migrating Animation Modifier", indent=1)
            self.animation_modifier.enabled = self.use_animation_modifier
            self.animation_modifier.expand = self.expand_animation_modifier

            # Update Custom Properties
            bpy.ops.easystates.repair_custom_property_categories()

        except Exception:  # pylint: disable=broad-except
            neologging.error(
                "EasyStates: Error converting legacy properties to new structure"
            )
            neologging.exception(traceback.format_exc())
            return False
        return True

    def clear(self):
        """Clear all global properties."""

        # Cleaning old properties
        self.collections_visibility.clear()
        self.objects_visibility.clear()

        for i in self.overwrites:
            i.material_slots.clear()
        self.overwrites.clear()

        self.custom_properties.clear()

        # Cleaning new properties
        for prop in self.__annotations__:
            prop = getattr(self, prop)
            if isinstance(prop, SceneModifierGlobalProps):
                prop.clear()
