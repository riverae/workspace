from typing import Any

import bpy
from bpy.types import Context, UILayout

from .props import get_scene_state_manager


def draw_context_menu_operators(self: Any, context: Context):
    """Draw context menu operators."""
    layout : UILayout = self.layout
    layout.separator()
    
    row = layout.row()
    row.operator(
        "easystates.add_custom_property_context_menu", icon="PROPERTIES"
    )
    row = layout.row()
    row.operator(
        "easystates.repair_custom_property_context_menu", icon="TOOL_SETTINGS"
    )

    manager = get_scene_state_manager(context.scene)

    row = layout.row()
    row.operator(
        "easystates.apply_to_scene_states",
        icon="COPYDOWN",
        text=f"Apply to all Scene States [{len(manager.get_all())}]",
    ).apply_to_selected = False

    row = layout.row()
    row.enabled = bool(manager.get_selected())
    row.operator(
        "easystates.apply_to_scene_states",
        icon="COPYDOWN",
        text=f"Apply to selected Scene States [{len(manager.get_selected())}]",
    ).apply_to_selected = True


def register_context_menu():
    """Register context menu operators."""

    class WM_MT_button_context(bpy.types.Menu):
        """override context menu"""

        bl_label = ""

        def draw(self, context: Context): ...  # type:ignore

    rcmenu = getattr(bpy.types, "WM_MT_button_context", None)

    if rcmenu is None:
        bpy.utils.register_class(WM_MT_button_context)
        rcmenu = WM_MT_button_context

    draw_funcs = (
        rcmenu._dyn_ui_initialize()  # pylint: disable=protected-access
    )
    draw_funcs.append(draw_context_menu_operators)


def unregister_context_menu():
    """Unregister context menu operators."""

    rcmenu = getattr(bpy.types, "WM_MT_button_context", None)

    if rcmenu:
        draw_funcs = (
            rcmenu._dyn_ui_initialize()  # pylint: disable=protected-access
        )
        draw_funcs.remove(draw_context_menu_operators)


def draw_cleanup_easystates_menu_operator(self: Any, context: Context):
    """Draw cleanup menu operator."""

    layout = self.layout
    layout.separator()
    layout.operator("easystates.clean_up")


def draw_export_easystates_menu_operator(self: Any, context: Context):

    layout = self.layout
    layout.operator("easystates.export_scene_states")


def register():
    """Register UI classes."""
    register_context_menu()

    bpy.types.TOPBAR_MT_file_cleanup.append(
        draw_cleanup_easystates_menu_operator
    )
    bpy.types.TOPBAR_MT_file_export.append(
        draw_export_easystates_menu_operator
    )


def unregister():
    """Unregister UI classes."""

    bpy.types.TOPBAR_MT_file_export.remove(
        draw_export_easystates_menu_operator
    )

    bpy.types.TOPBAR_MT_file_cleanup.remove(
        draw_cleanup_easystates_menu_operator
    )
    unregister_context_menu()
