# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

"""Addon main file."""

import bpy
from bpy.types import AddonPreferences, Context, UILayout
from bpy.utils import register_class, unregister_class

from . import addon, manager, render
from .libs import neologging

bl_info = {
    "name": "EasyStates",
    "description": "Scene States and Render Manager",
    "author": "Rodrigo Gama",
    "version": (1, 0, 7, 3),
    "blender": (4, 3, 0),
    "location": "View3D",
    "category": "3D View",
    "doc_url": "https://docs.cgoutset.com/easystates/",
    "tracker_url": "https://help.cgoutset.com/bug-report/",
}

neologging.basicConfig(
    config=neologging.LogConfig(
        level_info=True, module_info=True, auto_indent=True, use_color=True
    ),
    logger_name="easystates",
    level=neologging.DEBUG,
)


modules = (manager, addon)


class RenderPreferences(bpy.types.PropertyGroup):
    """Render preferences."""

    advanced_use_setup_cooldown: bpy.props.BoolProperty(
        default=True,
        name="Use Setup Cooldown",
        description=(
            "When enabled, the addon will wait for the setup cooldown time before "
            "starting the render process for each scene state."
            " This can prevent crashes and unexpected behavior when rendering complex scenes."
        ),
    )  # type: ignore
    advanced_setup_cooldown: bpy.props.IntProperty(
        default=2,
        name="Setup Cooldown Time (s)",
        subtype="TIME_ABSOLUTE",
        description="Cooldown time in seconds",
    )  # type: ignore

    def draw(self, layout: UILayout):
        """Draw render preferences."""

        col = layout.column(align=True)
        col.use_property_decorate = False
        col.use_property_split = True

        box = col.box()
        row = box.row()
        row.label(text="Render (Advanced)", icon="RENDER_RESULT")

        box = col.box()
        row = box.row()
        row.prop(self, "advanced_use_setup_cooldown")
        row = box.row()
        row.prop(self, "advanced_setup_cooldown")


class AddonPref(AddonPreferences):
    """Addon preferences."""

    bl_idname = __package__

    ui_show_scene_cameras: bpy.props.BoolProperty(
        name="Show Scene Cameras",
        description="Show scene cameras in the scene state list.",
        default=False,
    )  # type: ignore

    auto_lock_interface: bpy.props.BoolProperty(
        name="Auto Lock Interface",
        description="Lock the interface when rendering to allocate more memory to the render process.",
        default=False,
    )  # type: ignore

    safe_viewport_state_switch: bpy.props.BoolProperty(
        name="Safe Viewport Scene Switch",
        description="When changing scene states in the viewport, the viewport will automatically switch to solid mode. This can prevent unwanted freezes for complex scenes.",
        default=False,
    )  # type: ignore

    store_camera_loc_roc_by_default: bpy.props.BoolProperty(
        name="Store Camera Location and Rotation by Default",
        description="By default, store the camera location and rotation when creating a new state.",
        default=False,
    )  # type: ignore

    render: bpy.props.PointerProperty(type=RenderPreferences)  # type: ignore

    def _draw_support(self, layout: UILayout, context: Context):

        col = layout.column(align=True)

        box = col.box()
        box.label(text="Support", icon="INFO")

        box = col.box()
        row = box.row()

        row.operator(
            "wm.url_open", text="Add-on Documentation", icon="HELP"
        ).url = "https://docs.cgoutset.com/easystates/"

        row.operator(
            "wm.url_open", text="Join our Discord Server", icon="URL"
        ).url = "https://discord.com/invite/XGeDTUsmb4"

        col = layout.column(align=True)

        box = col.box()
        row = box.row()
        row.label(text="UI", icon="MENU_PANEL")

        box = col.box()
        row = box.row()
        row.prop(self, "ui_show_scene_cameras")

        col = layout.column(align=True)

        box = col.box()
        row = box.row()
        row.label(text="Performance", icon="ERROR")

        box = col.box()
        row = box.row()
        row.prop(self, "auto_lock_interface")
        row = box.row()
        row.prop(self, "safe_viewport_state_switch")

        col = layout.column(align=True)

        box = col.box()
        row = box.row()
        row.label(text="Scene Modifiers", icon="MODIFIER")

        box = col.box()
        row = box.row()
        row.label(text="Camera", icon="CAMERA_DATA")
        row = box.row()
        split = row.split(factor=0.05)
        split.separator()
        split.prop(self, "store_camera_loc_roc_by_default")

    def draw(self, context: Context):
        """Draw addon preferences."""

        layout = self.layout

        self._draw_support(layout, context)
        self.render.draw(layout)


classes = (RenderPreferences, AddonPref)


def register():
    """Register addon."""

    for cls in classes:
        register_class(cls)

    manager.register()
    render.register()
    addon.register()


def unregister():
    """Unregister addon."""

    addon.unregister()
    render.unregister()
    manager.unregister()

    for cls in reversed(classes):
        unregister_class(cls)
