# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import traceback

import bpy
from bpy.app.handlers import persistent
from bpy.types import Scene

from ..constants import (
    DISPLAY_DEVICES_KEY,
    FAILED_TO_LOAD_KEY,
    FAILED_TO_LOAD_REASON_KEY,
    PROPERTIES_VERSION,
    PROPERTIES_VERSION_KEY,
    RENDER_ENGINES_KEY,
)
from ..libs import neologging
from ..manager.props import get_scene_state_manager
from .operators import migrate_to_ver2


def _get_properties_version() -> int:
    """Get the version of the easystates scene structure"""

    try:
        easystate_version = bpy.context.scene[PROPERTIES_VERSION_KEY]
    except KeyError:
        easystate_version = 1

    return easystate_version


def _timer_migrate_previous_properties_version():
    """Migrate from version 1 to 2"""

    try:
        result = migrate_to_ver2(bpy.context)
        if not result:
            neologging.critical("Failed to convert legacy properties")
            bpy.context.scene[FAILED_TO_LOAD_KEY] = True
            return

        bpy.context.scene[FAILED_TO_LOAD_KEY] = False
    except Exception as e:  # pylint: disable=broad-except
        print("Error updating old addon structure")
        print(e)
        traceback.print_exc()

    bpy.context.scene[PROPERTIES_VERSION_KEY] = PROPERTIES_VERSION


@persistent
def _handler_properties_version_check(_: Scene):
    """Check the add-on properties version and migrate if necessary

    If the properties version is only one version behind the current version, it will
    automatically migrate the properties. If it is more than one version behind, it will
    set the FAILED_TO_LOAD_KEY to True and log a critical message.
    """

    bpy.context.scene[FAILED_TO_LOAD_KEY] = False
    current_props_version = _get_properties_version()
    is_file_saved = bpy.data.is_saved

    if not is_file_saved:
        bpy.context.scene[PROPERTIES_VERSION_KEY] = PROPERTIES_VERSION
        neologging.info("File is not saved, skipping properties version check")
        return

    if current_props_version == PROPERTIES_VERSION:
        neologging.info(
            f"Properties version is up to date: {PROPERTIES_VERSION}"
        )
        return

    if current_props_version + 1 == PROPERTIES_VERSION:
        neologging.info(
            f"Migrating from version {current_props_version} to {PROPERTIES_VERSION}"
        )
        bpy.app.timers.register(
            _timer_migrate_previous_properties_version,
            first_interval=1,
        )
        return

    load_fail_reason = f"Cannot migrate from version {current_props_version} to {PROPERTIES_VERSION}"

    neologging.critical(load_fail_reason)
    bpy.context.scene[FAILED_TO_LOAD_KEY] = True
    bpy.context.scene[FAILED_TO_LOAD_REASON_KEY] = load_fail_reason


@persistent
def _load_builtins_enumerator_Props(_: Scene):
    """Load the builtins enumerator properties.

    This is necessary because add-ons can modify the available enum values for these builtins.
    And there is no better way to retrieve them without generating an exception and parsing the message.
    """

    try:
        try:
            bpy.context.scene.render.engine = ""
        except Exception as e:  # pylint: disable=broad-except
            available_engines = str(e).split("'")[1::2]
            neologging.info(f"Available render engines: {available_engines}")
            bpy.context.scene[RENDER_ENGINES_KEY] = available_engines

        # Display devices currently not used
        try:
            bpy.context.scene.display_settings.display_device = ""
        except Exception as e:  # pylint: disable=broad-except
            available_devices = str(e).split("'")[1::2]
            neologging.info(f"Available display devices: {available_devices}")
            bpy.context.scene[DISPLAY_DEVICES_KEY] = available_devices
    except Exception as e:  # pylint: disable=broad-except
        error_message = f"Error loading builtins enumerator properties: {e}"

        neologging.error(error_message)
        neologging.exception(traceback.format_exc())

        bpy.context.scene[FAILED_TO_LOAD_KEY] = True
        bpy.context.scene[FAILED_TO_LOAD_REASON_KEY] = error_message


@persistent
def _handler_load_default_render_output(_: Scene):
    """This handler automatically sets the EasyStates
    render output to the scene output if it is empty"""

    def _timer_load_default_render_output():
        manager = get_scene_state_manager(bpy.context.scene)
        if not manager.render_output:
            neologging.info("Loading default render output path")
            manager.render_output = bpy.context.scene.render.filepath

    bpy.app.timers.register(
        _timer_load_default_render_output,
        first_interval=2,
    )


def register():
    """Register the handler"""

    bpy.app.handlers.load_post.append(_handler_load_default_render_output)
    bpy.app.handlers.load_post.append(_load_builtins_enumerator_Props)
    bpy.app.handlers.load_post.append(_handler_properties_version_check)


def unregister():
    """Unregister the handler"""
    bpy.app.handlers.load_post.remove(_handler_properties_version_check)
    bpy.app.handlers.load_post.remove(_load_builtins_enumerator_Props)
    bpy.app.handlers.load_post.remove(_handler_load_default_render_output)
