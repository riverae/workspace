# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

import os
import traceback

import bpy
from bpy.types import Context

from ..libs import neologging
from ..manager.props.global_properties import GlobalSceneStateProperties


def save_backup_version(context: Context, backup_dir_name: str) -> bool:
    """Save a backup of the version 1 properties"""

    user_path = bpy.utils.resource_path("USER")
    config_path = os.path.join(user_path, "config")
    config_path = os.path.join(config_path, "easystates")
    backup_path = os.path.join(config_path, backup_dir_name)

    if not os.path.exists(backup_path):
        neologging.info("Creating easystates config directory")
        os.makedirs(backup_path)

    current_filepath = bpy.data.filepath
    if not current_filepath:
        neologging.error("Failed to get current blend file path")
        return False
    if not os.path.exists(current_filepath):
        neologging.error("Current blend file path does not exist")
        return False

    final_filename = os.path.join(
        backup_path, os.path.basename(current_filepath)
    )

    try:
        neologging.info(f"Saving backup file to: {final_filename}")
        bpy.ops.wm.save_as_mainfile(filepath=final_filename, copy=True)
    except Exception as e:  # pylint: disable=broad-except
        neologging.error(f"Failed to save backup file: {e}")
        neologging.exception(traceback.format_exc())
        return False

    return True


def migrate_to_ver2(context: Context) -> bool:
    """Migrate from version 1 to 2

    Returns:
        bool: True if the migration was successful, False otherwise
    """

    result = save_backup_version(context, "backup_v1")

    global_properties: GlobalSceneStateProperties = (
        context.scene.easystates_manager.global_properties
    )
    result = global_properties.convert_legacy_properties()
    if not result:
        neologging.critical("Failed to convert legacy properties")
        return False

    return True


class EZS_OT_MigrateToVer2(bpy.types.Operator):
    """Execute the migration from version 1 to 2"""

    bl_idname = "easystates.migrate_ver2"
    bl_label = "Migrate to version 2"
    bl_options = {"REGISTER", "UNDO"}

    def execute(self, context: Context):
        """Execute the operator"""

        result = migrate_to_ver2(context)
        if not result:
            neologging.critical("Failed to convert legacy properties")
            return {"CANCELLED"}

        self.report({"INFO"}, "Migration to version 2 was successful")
        return {"FINISHED"}


classes = (EZS_OT_MigrateToVer2,)


def register():
    """Register operators."""

    from bpy.utils import register_class

    for cls in classes:
        register_class(cls)


def unregister():
    """Unregister operators."""

    from bpy.utils import unregister_class

    for cls in reversed(classes):
        unregister_class(cls)
