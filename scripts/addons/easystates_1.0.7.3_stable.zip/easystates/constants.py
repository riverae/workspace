# "easystates" Blender Addon.
# Copyright (C) 2024, Rodrigo Gama
#
# ##### BEGIN GPL LICENSE BLOCK #####
#
#  This program is free software: you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation, either version 3 of the License, or
#  (at your option) any later version.
#
#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.
#
#  You should have received a copy of the GNU General Public License
#  along with this program.  If not, see <https://www.gnu.org/licenses/>.
#
# ##### END GPL LICENSE BLOCK #####

ADDON_NAME = "easystates"

PROPERTIES_VERSION: int = 2

# SCENE KEYS

# Properties Version
PROPERTIES_VERSION_KEY: str = "easystates_props_version"  # int
FAILED_TO_LOAD_KEY: str = "easystates_load_fail"  # bool
FAILED_TO_LOAD_REASON_KEY: str = "easystates_fail_reason"  # str

# Builtins enumerator props
RENDER_ENGINES_KEY: str = "render_engines"  # str
DISPLAY_DEVICES_KEY: str = "display_devices"  # str
